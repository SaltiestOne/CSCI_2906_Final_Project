package finalProject;

import java.util.Random;

import finalProject.Attempt.AttemptType;

/**
 * Monster/Critter subclass for
 * foes which are mindless or animalistic
 * in nature, but have access to some
 * inherent magic.
 * 
 * @author Kayden Barlow
 */
public class MagiCritter extends Critter implements Caster {

	private ManaGauge mana;
	private Spell spell;
	
	MagiCritter(String name, MonsterFlavor flavor, int level, String spellName) {
		
		this(name, flavor, level);

		addAction(new Spell(spellName, true, 3, (Stat)getAttackingStat(), AllActions.getType(spellName)));
	
		spell.addDamageScaler(a -> {return ((int)(getDamage() * 1.5));});
	}
	
	
	MagiCritter(String name, MonsterFlavor flavor, int level) {
		
		super(name, flavor, level, AttemptType.NEUTRAL);
		
		mana = new ManaGauge(10 * level);
	}

	public Attempt getAttempt(Entity target) {
		
		if (isOnSpecial()) {

			return spell.getAttempt(target);
		} else {
			
			return new Attempt(target, hasAdvantage(target), getCurrentType());
		}
	}
	
	protected int healthScale() {
		
		return Scaler.enemyHealth(getLevel() - 1);
	}
	
	public AttemptType critterSignatureType() {
		
		if (spell == null) {
			
			return AttemptType.NEUTRAL;
		} else {
			
			return (spell.getAttemptType());
		}
	}
	
	protected String handleSuccess(Entity target, boolean advantage) {
		
		if (isOnSpecial()) {
			
			return spell.doAction(target, advantage);
		} else {
			
			return basicAction(target, advantage);
		}
	}

	public String handleFailure(Entity target) {
		
		if (isOnSpecial()) {
			
			return formatMessage(spell.failureString(), target);
		} else {
			
			return formatMessage(getAttackingStat().failureMessage(getCurrentType()), target);
		}
	}
	
	
	protected boolean specialProcedure() {
		
		AttemptType type = Attempt.randomWithNeutral();
		
		if ((type == getRustedType()) ||
				(type == AttemptType.NEUTRAL)) {
			
			if ((critterSignatureType() != getRustedType()) &&
					(spell != null)) {
				
				return setSpecial(true);
			} else {
				
				setAttemptPlan(Attempt.randomNonNeutral());
			}
		} else {
			
			setAttemptPlan(type);
		}
		
		return setSpecial(getCurrentType() == critterSignatureType());
	}
	
	protected String defaultSubTypeImage() {
		
		return "Monsters\\DefaultImages\\MagiCritterDefault.png";
	}


	
	public boolean addAction(Action action) {
		
		if (action instanceof Spell) {
			
			this.spell = (Spell)action;
			
			return true;
		} else {
			return false;
		}
	}


	public Action getAction(String actionName) {
		
		return null;
	}


	public Action getAction(Action action) {
		
		return null;
	}


	public boolean hasAction(String actionName) {
		
		return (spell.getName().equals(actionName));
	}


	public ManaGauge mana() {
		
		return mana;
	}

	@Override
	public int magicScaler() {
		
		return getLevel() * 4;
	}
	
}
