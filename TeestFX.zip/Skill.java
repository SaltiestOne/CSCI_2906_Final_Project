package finalProject;

import finalProject.Attempt.AttemptType;

/**
 * A subclass of Action intended to represent "martial manuevers" that use a 
 * specific armament. 
 * 
 * @author Kayden Barlow
 */
class Skill extends Action {
	
	
	/**
	 * Constructor for instances 
	 * of the Skill object.
	 * 
	 * @param name String of the Skill's name.
	 * @param cooldown Integer for the Skill's cooldown. (This is this
	 * Action's "cost" value.)
	 * @param stat Stat object from which the Skill's scaling is derived.
	 * @param type AttemptType of any Attempt made by this Skill.
	 */
	Skill(String name, int cooldown, Stat stat, AttemptType type) {
		
		super(name, cooldown, stat, "Skill", type);
	}
	

	/**
	 * Constructor for instances 
	 * of the Skill object.
	 * 
	 * @param name String of the Skill's name.
	 * @param addDoer Boolean determining if the name parameter is 
	 * to be used to find and add an ActionDoer to the new Skill.
	 * @param cooldown Integer for the Skill's cooldown. (This is this
	 * Action's "cost" value.)
	 * @param stat Stat object from which the Skill's scaling is derived.
	 * @param type AttemptType of any Attempt made by this Skill.
	 */
	Skill(String name, boolean addDoer, int cooldown, Stat stat, AttemptType type) {
		
		super(name, addDoer, cooldown, stat, "Skill", type);
	}
	
	
	/**
	 * Returns the user of the Stat object
	 * associated with this Skill. Overrides
	 * the superclass method to return a
	 * casted SkillUser object. 
	 */
	public SkillUser getUser() {
		
		return ((SkillUser)getStat().getUser());
	}
	
	
	
	/**
	 * Overrides the abstract superclass method to give the name
	 * of the "armament" (as specified in the associated Gear
	 * object) used by the Skill, rather than a general Stat name.
	 * 
	 * @return String name of the specific "piece" of Gear used by the Skill.
	 */
	String getImplement() {
	
		return this.getStat().getImplement();
	}
	
	
	/**
	 * If this Skill is marked learned, returns
	 * a String containing the Skill's name and 
	 * its either its Cooldown cost or a message
	 * indicating current cooldown. If it
	 * is not learned, returns "[UNLEARNED]".
	 * 
	 * @return String containing the name and 
	 * usage information about this Skill.
	 */
	String menuMessage() {
		
		String message = (getName() + "\n" + getAttemptType() + " (" + this.getImplement() +")\n");
		
		if (isOnCooldown()) {
			
			return (message + "COOLING DOWN");
		} else {
			
			return (message + ((this.getCost() -1) + "-turn CD"));
		}
	}
	
	
	/**
	 * Shortcut method indicating if the
	 * User of this Skill has a positive
	 * Cooldown value.
	 * 
	 * @return True if this Skill's user
	 * is on cooldown, false otherwise.
	 */
	private boolean isOnCooldown() {
		
		return getUser().cooldown().isOnCooldown();
	}
	
	
	/**
	 * Indicates if this Skill can be used.
	 * If Skills are on Cooldown, or if
	 * this instance is unlearned, it is 
	 * not Usable and returns False. Otherwise,
	 * returns True.
	 * 
	 * @return False if this Skill is unlearned or
	 * if its user is on cooldown, True otherwise.
	 */
	boolean isUsable() {
		
		return !isOnCooldown();
	}



	
	/**
	 * Checks usability before setting
	 * user's cooldown to this Skill's
	 * assigned Cost parameter. Returns a
	 * boolean determined based on
	 * usability. 
	 * 
	 * @return True if Skill is usable 
	 * and cooldown was set, False otherwise.
	 */
	public boolean cost() {
		
		return cost(getCost());
	}
	
	
	/**
	 * Checks usability before setting
	 * user's cooldown to the input
	 * value. Returns a boolean determined 
	 * based on usability. 
	 * 
	 * @return True if Skill is usable 
	 * and cooldown was set, False otherwise.
	 */
	public boolean cost(int cost) {
		
		if (!isUsable()) {
			
			return false;
		} else {
			
			getUser().cooldown().set(cost + 1);	
		
			return true;
		} 
	}
	
	
	
	/**
	 * Method used to provide String descriptions
	 * for exceptions thrown as a result of invalid
	 * Skills. Provides messages in the cases that 
	 * the Skill is on cooldown, that it is unlearned,
	 * and a failsafe in case this method gets called
	 * in any other circumstance. 
	 * 
	 * @return String describing the reason the Skill
	 * is unusable.
	 */
	public String errorMessage() {
		
		if (isOnCooldown()) {
			
			return ("Skills on cooldown!");
		} else {
			
			return (getName() + " is unusable for some reason...");
		}
	}
	
	
	
	public String learnMessage() {
		
		return ("[u] learn[s] how to perform a " + getName() + "\n with [pp] " + getImplement() + ".\n");
	}
	
	
	/**
	 * Consolidates the process of a Skill damaging 
	 * an Entity target with an integer input 
	 * and setting its Cooldown. Returns the amount
	 * of damage dealt.
	 * 
	 * @param damage Integer value of damage dealt to
	 * target's health.
	 * @param target Entity targeted by this Skill's effect.
	 */
	protected int quickUse(int damage, Entity target) {
		
		if (this.cost()) {
						
			return target.harm(damage);
		} else {
			
			throw new IllegalArgumentException(errorMessage());
		}
	}
	
	
	/**
	 * Consolidates the process of a Skill damaging 
	 * an Entity target with its Scaler value,
	 * and setting its Cooldown. Returns the amount
	 * of damage dealt.
	 * 
	 * @param damage Integer value of damage dealt to
	 * target's health.
	 * @param target Entity targeted by this Skill's effect.
	 */
	protected int quickUse(Entity target) {
		
		return quickUse(scale(), target);
	}
}
