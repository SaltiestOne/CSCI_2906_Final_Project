package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.Attacking;

public class SkilledMonster extends HumanoidMonster implements SkillUser {

	Cooldown cooldown = new Cooldown();
	Skill skill;
	
	/*SkilledMonster(String name, String flavor, int level, int maxHealth) {
		
		super(name, flavor, level, maxHealth);
	}
	
	SkilledMonster(String name, String flavor, int level, int maxHealth, Skill skill) {
		
		this(name, flavor, level, maxHealth);
		
		setSkill(skill);
	}*/
	
	SkilledMonster(String name, MonsterFlavor flavor, int level, String implementName) {
		
		super(name, flavor, level);
	}
	
	SkilledMonster(String name, MonsterFlavor flavor, int level, String implementName, Skill skill) {
		
		this(name, flavor, level, implementName);
		
		setSkill(skill);
		
		setAttackingStat(subclassStat(implementName));
	}
	
	public void endTurn() {
		
		this.stunned = false;
		//TODO: variant damage formulae for different Monster subtypes
		setDamage(Scaler.enemyDamage(getLevel()));
		
		cooldown.drop();
		
		specialProcedure();
	}
	
	protected String subTypeStatusText() {
		
		return (getName() + "\n Level " + getLevel() + " Skill-using enemy");
	}
	
	protected String defaultSubTypeImage() {
		
		return "Monsters\\DefaultImages\\SkilledMonsterDefault.png";
	}


	
	public void setSkill(Skill skill) {
		
		this.skill = skill;
		
		this.skill.addDamageScaler((e -> {return Scaler.enemyDamage(getLevel() + 1);}));
		
		specialProcedure();
	}

	public Cooldown cooldown() {
		
		return cooldown;
	}
	

	/**
	 * Returns the integer representing
	 * the number of turns remaining until
	 * this Monster can use another Skill. 
	 * 
	 * @return Integer value of cooldown.
	 */
	public int getCooldown() {

		return cooldown.value();
	}

	
	/**
	 * Returns a boolean indicating if
	 * cooldown is a positive value, 
	 * and therefor that Skills are on 
	 * cooldown.
	 * 
	 * @return True if cooldown is greater than
	 * zero, False if it is zero (or less, somehow).
	 */
	public boolean isOnCooldown() {

		return (cooldown.value() > 0);
	}

	/**
	 * Sets Cooldown to the specified value.
	 * Cooldown cannot be negative.
	 * 
	 * @param cooldown Integer new Cooldown.
	 */
	public void setCooldown(int cooldown) {

		this.cooldown.set(Math.max(cooldown, 0));
	}

	/**
	 * Invokes its sister method to drop
	 * Cooldown by 1. Intended to be invoked at
	 * the end of every turn.
	 *
	public void dropCooldown() {
	
		if (isOnCooldown()) {
			
			cooldown--;
		} else {}		
	}*/


	/**
	 * Reduces Cooldown value by the input
	 * amount. Cooldown cannot be negative.
	 * 
	 * @param decrement Integer amount to reduce
	 * Cooldown.
	 *
	public void dropCooldown(int decrement) {

		if (decrement < cooldown) {
		
			cooldown = (cooldown - decrement);
		} else {
			
			cooldown = 0;
		}
	}*/
	
	
	protected boolean specialProcedure() {
		
		try {

			AttemptType plan = Attempt.randomWithNeutral();
			
			if ((plan == AttemptType.NEUTRAL) || 
					(plan == getRustedType())) {
				
				if (trySkill()) {
					
					setAttemptPlan(skill.getAttemptType());

			
				} else {
					
					setAttemptPlan(Attempt.randomNonNeutral());
				}
			} else {
				
				setAttemptPlan(plan);
			}	
			
			return isOnSpecial();
			
		} catch (NullPointerException ex) {
			//in case the Skill has not been set yet.
			return false;
		}
	}
	
	private boolean trySkill() {
		
		if (skill.isUsable()) {
			
			if ((getHealth() <= (getMaxHealth() / 3))) {
			
				return setSpecial(true);
			} else {
				
				return setSpecial(new java.util.Random().nextBoolean());
			}
		} else {
			
			return setSpecial(false);
		}
	}

	
	protected Attacking subclassStat(String key) {
		
		try {
			
			return fetchImplement(this, key);
		} catch (NullPointerException ex) {
			//TODO: better default implement for skilled monsters
			return new EnemyImplement(this, "test implement", AttemptType.NEUTRAL,
					new String[] {"a", "b", "c", "d", "e"}, new String[] {"f", "g", "h", "i", "j"},
					new String[] {null, "l", "m", "n", "o"});	
		}
	}

	
	protected boolean subAfflict(Affliction affliction) {
		
		switch (affliction.name) {
		
		case ("disable"): {
			
			if (isOnCooldown()) {
				
				setCooldown(getCooldown() * 2);
			} else {
				
				setCooldown(Math.min(1, affliction.potency));
			}
		}
		
		default: {
			
			return false;
		}
		}
	}
	
	public String action(Entity target) {
		
		if (isStunned()) {
			
			return stunnedMessage(target);
		} else if (isOnSpecial()) {
			
			if(isOnCooldown()) {
				
				return (getPerspectiveName() + " is unable to use thier technique.\n\n");
			} else {
				
				return skill.doAction(target, false);
			}
		} else {
			
			return doBasic(target);
		}	
	}
/*
	@Override
	protected Behavior getBehavior(String name) {

		return null;
	}*/

	@Override
	public boolean addAction(Action action) {

		return false;
	}

	@Override
	public Action getAction(String actionName) {

		return null;
	}

	@Override
	public Action getAction(Action action) {

		return null;
	}

	@Override
	public boolean hasAction(String actionName) {

		return (skill.getName().equals(actionName));
	}


	public Attempt getAttempt(Entity target) {
		
		if (isOnSpecial()) {
			
			return skill.getAttempt(target);
		} else if (hasAdvantage(target)) {
			
			return new Attempt(this, hasAdvantage(target), getCurrentType());
		} else {
			
			return new Attempt(this, getCurrentType(), getBreaker());
		}
	}
	

	public String handleFailure(Entity target) {

		if (isOnSpecial()) {
			
			return formatMessage(skill.failureString(), target);
		} else {
			
			return formatMessage(getAttackingStat().failureMessage(getCurrentType()), target);
		}
	}


	public boolean getBreaker() {

		return (getCurrentType() == getAttackingStat().signatureType());
	}

	protected int defaultDamageScaling() {

		return Scaler.enemyDamage(getLevel());
	}
	
	
}
