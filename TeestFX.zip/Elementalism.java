package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.Attacking;

/**
 * Magic subclass representing
 * a school of Magic based on
 * manipulation of the four basic
 * elements. Has low scaling, but
 * can Attack natively and has 
 * powerful spells.
 * 
 * @author Kayden Barlow
 */
public class Elementalism extends Magic implements Attacking {

	
	/**
	 * Constructor for new Elementalism Stats.
	 * Like all Magic subclasses, requires 
	 * a Caster user.
	 * 
	 * @param user Caster to which this
	 * Elementalism Stat will be assigned. 
	 * @param level Integer value of this
	 * Stat's initial relative power.
	 */
	Elementalism(Caster user, int level) {
		
		super(user, "Elementalism", level, 2);
	}
	
	

	public String attackMessage(AttemptType attemptType) {
		//TODO: finish elementalism attack strings
		switch (attemptType) {
			
		case NEUTRAL: {
			
			throw new IllegalArgumentException("Can't attack with a Neutral.");
		}
		
		case QUICK: {
			
			return ("before [f], [u] throw[s] a bolt of Fire magic and a buring plasma bolt singes [t].\n");
		}
		
		case WIDE: {
			
			return ("[u] launch[es] an elemental blast at [pp] target. Right as [f], [ps] throw[s] a second which catches [t] off guard.\n");
		}
		
		case TRICK: {
			
			return ("[u] subtly channel[s] magic into the ground as [f]. After a moment, a rising chunk of Earth hits [t].\n");
		}
		
		case EVADE: {
			
			return ("[u] form[s] a wall of Water, distorting [pp] image to cover [pp] escape before [f].\n");
		}
		
		case BLOCK: {
			
			return ("[f], but [u] blast[s] [to] back and off balance with a focused blast of Air.\n");
		}
		
		default:
			
			return getUser().defaultSuccessStrings(attemptType);
		}
		
	}
	
	
	
	public String advantagedMessage(AttemptType type) {
		//TODO: finish strings for advantaged elementalism
		String mix = "seizing [pp] advantage, [u] combine[s] elemental spells. ";
		//fire/earth: metal
		//earth/water: ice
		//water/air: mist
		switch(type) {

		case NEUTRAL: {
			
			throw new IllegalArgumentException("Can't attack with a Neutral.");
		}
		
		case TRICK: {
			
			return (mix + "Fire and Air form a Lightning bolt before [f] and fry [to].\n");
		}
		
		case BLOCK: {
			
			return ("seizing [pp] advantage, [u] calls on the fifth element. " + 
			Formatter.capitalize("[f], only to meet a material-piercing ray of magic.\n"));
		}
		
		case EVADE: {
			
			return "";
		}
		
		default: {
			
			return ("letting out a shout, " + attackMessage(type));
		}
		}
	}
	
	public String failureMessage(AttemptType type) {
		//TODO: better failure messages for elementalism
		return "[u] channel[s] the elements";
	}
	
	public AttemptType signatureType() {
		
		return AttemptType.TRICK;
	}
	
	
	public int manaScale() {
		
		return ((int)(getLevel() * 1.5));
	}
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Caster's list of stats, this is intended
	 * to be used to quickly add a new, generic Arcanism
	 * Stat to the input Caster.
	 * 
	 * @param user Caster to receive a new instance
	 * of this object.
	 * @return String describing the aquisition of the 
	 * new Stat.
	 */
	public static String add(Caster user) {
		
		return user.formatMessage("[u] learn[s] the basics of " + 
				new Elementalism(user, 0).getName() + ".\n");
	}
}
