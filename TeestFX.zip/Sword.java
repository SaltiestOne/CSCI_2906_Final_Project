package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Gear.GearPiece;


/**
 * Weapon subclass representing
 * the quintessential fantasy
 * symbol. 
 * 
 * @author Kayden Barlow
 */
public class Sword extends Weapon {


	/**
	 * Constructor for instances of the Sword
	 * class. Must be assigned to an 
	 * instance of the Fighter class, and will
	 * be added to that Fighter's ArrayList
	 * of stats. The name parameter will be fixed
	 * as "Sword".
	 * 
	 * @param user Fighter to which the Stat
	 * is assigned.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Sword(Fighter user, int level) {
		
		super(user, "Sword", level, 2, 2);
	}
	

	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Fighter's list of stats, this is intended
	 * to be used to quickly add a new, generic Shield
	 * Gear Stat to the input Fighter.
	 * 
	 * @param user Fighter to receive a new instance
	 * of this object.
	 * @return String describing the aquisition of this
	 * Stat.
	 */
	public static String add(Fighter user) {

		return user.formatMessage("[u] obtain[s] a new " + 
				new Sword(user, 0).getName() + ".\n");
	}
	
	/*
	protected GearPiece getNamedPiece(String pieceName) {
		//TODO: implement variant gear names
		return defaultPieces();
	}*/
	
	protected GearPiece defaultPiece() {
		
		return pieceTemplate("Shortsword");
	}
	
	//placeholder lol
	private GearPiece pieceTemplate(String name) {
		
		return new GearPiece(name, "Metal", 
				"[u] sell[s] [pp] [op] to help pay for ", "[pp] new [np].");
	}
	
	
	
	protected GearPiece upPiece() {
		
		if (getImplement().equals("Shortsword")) {
			
			return pieceTemplate("Longsword");
		} else if (getImplement().equals("Longsword")) {
			
			return pieceTemplate("Katana");
		} else {
			
			return pieceTemplate("Shortsword");
		}
	}
	

	
	
	protected Action[] buildActions() {
		
		Action[] result = new Action[getTotalActions()];
		
		int[] cooldowns = {3, 1};

		String[] name = {"Spin Attack", "Mana Burst"};
		
		DamageScaler[] scalers = {(e -> {return Scaler.damage(e.getUser().getLevel(), 
				((int)(getModdedLevel()* 1.5)));}),
				(e -> {return (Scaler.damage(((int)(getModdedLevel() * 1.5)), getModdedLevel()));})};
	
		for (int s = 0; s < result.length; s++) {
			
			result[s] = new Skill(name[s], true, cooldowns[s], this, AllActions.getType(name[s]));
			
			result[s].addDamageScaler(scalers[s]);
		}
		
		return result;
	}

	
	public String attackMessage(AttemptType attemptType) {
		
		switch (attemptType) {
			
		case QUICK: {
			
			return ("[u] thrust[s] [pp] " + getImplement() + " foward. Though [f], it was too late.\n");
		}
		
		case WIDE: {
			
			return ("[f], but [u] intercept[s] by swinging [pp] " + getImplement() + " in a wide arc.\n");
		}
		
		case TRICK: {
			
			return ("[u] slash[es] with [pp] " + getImplement()+ ". As [f], [ps] moulinet[s] and strike[s] a weak spot.\n");
		}
		
		case BLOCK: {
			
			return getUser().defaultSuccessStrings(attemptType);
		}
		
		case EVADE: {
			
			return getUser().defaultSuccessStrings(attemptType);
		}
		default:
			
			throw new IllegalArgumentException("Can't attack with a Neutral.");
		}
	}
	
	
	
	public String advantagedMessage(AttemptType type) {
		
		switch(type) {
		
		case BLOCK: {
			
			return "[f], but [u] drop[s] [pp] " + getImplement() + " in an inexorible overhead swing.\n";
		}
		
		case EVADE: {
			
			return "[f], but [u] roll[s] behind and drive[s] [pp] " + getImplement() + "into them.\n";
		}
		
		default: {
			
			return ("letting out a shout, " + attackMessage(type));
		}
		}
	}
	
	
	public String failureMessage(AttemptType type) throws NullPointerException {
		
		String base = "[u] start[s] ";
		String end = (" [pp] " + getImplement());
		switch (type) {
		
		case QUICK: {
			
			return base + "thrusting" + end;
		}
		
		case WIDE: {
			
			return base + "swinging" + end;
		}
		
		case TRICK: {
			
			return base + "to slash with" + end;
		}
		
		default: {
			
			return getUser().defaultFailureStrings(type);
		}
		}
	}
	

	
	public AttemptType signatureType() {
		
		return AttemptType.TRICK;
	}
}
