package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Gear.GearPiece;


/**
 * A Weapon subclass representing
 * that most timeless of armaments:
 * the pointy stick.
 * 
 * @author Kayden Barlow
 */
public class Spear extends Weapon {

	/**
	 * Constructor for instances of the Spear
	 * class. Must be assigned to an 
	 * instance of the Fighter class, and will
	 * be added to that Fighter's ArrayList
	 * of stats. The name parameter will be fixed
	 * as "Spear".
	 * 
	 * @param user Fighter to which the Stat
	 * is assigned.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Spear(Fighter user, int level) {
		
		super(user, "Spear", level, 2, 3);
	}
	
	/**
	 * Internal method used to consolidate
	 * and standardize certain Strings used
	 * for successful, failed, and advantaged
	 * Attempts. Returns specific substrings
	 * for QUICK, WIDE, and TRICK Attempts, 
	 * and null for other types.
	 * 
	 * @param type AttemptType of desired
	 * subString.
	 * @return String used to build other
	 * Strings.
	 */
	private String baseMessage(AttemptType type) {
		
		switch (type) {
		
		case QUICK: {
			
			return ("[f], but can't reach [u] before ");
		}
		
		case WIDE: {
			
			return ("[u] swing[s] [pp] " + getImplement() + ". Though [f], the [x] of [pp] weapon stops [to].\n");
		}
		
		case TRICK: {
			
			return ("[u] jab with [pp] " + getImplement() + ". As [f] in reponse, [u] whip[s] the butt around into them.\n");
		}
		
		default:
			
			return null;
		}
		
	}
	
	
	public String attackMessage(AttemptType attemptType) {
		
		switch (attemptType) {
			
		case QUICK: {
			
			return baseMessage(attemptType) + "the tip of [pp] " + getImplement() + " pierces them.\n";
		}
		
		case WIDE: {
			
			return baseMessage(attemptType).replace("[x]", "shaft");
		}
		
		case TRICK: {
			
			return ("[u] jab with [pp] " + getImplement()+ ". As [f] in reponse, [u] whip[s] the butt around into them.\n");
		}
		default:
			
			return getUser().defaultSuccessStrings(attemptType);
		}
		
	}
	
	
	
	public String advantagedMessage(AttemptType type) {
		
		switch(type) {
		
		case QUICK: {
			
			return baseMessage(type) + "a flurry of quick jabs pierce [to]";
		}
		
		case WIDE: {
			
			return baseMessage(type).replace("[x]", "tip");
		}
		
		case TRICK: {
			
			return ("[u] pole vault[s] over [t] while [f], then thrust [pp] " + getImplement() + ".\n");
		}
		
		case BLOCK: {
			
			return "As [f], [u] leap[s] high and drop[s] [pp] " + getImplement() + " directly into [t].\n";
		}
		
		case EVADE: {
			
			return "[u] lunge[s] into [t] with [pp] " + getImplement() + " before jumping back as [f].\n";
		}
		
		default: {
			
			return null;
		}
		}
	}
	
	public String failureMessage(AttemptType type) throws NullPointerException {
		
		String base = "[u] start[s] ";
		String end = (" [pp] " + getImplement());
		switch (type) {
		
		case QUICK: {
			
			return base + "thrusting" + end;
		}
		
		case WIDE: {
			
			return base + "swinging" + end;
		}
		
		case TRICK: {
			
			return base + "to jab with" + end;
		}
		
		default: {
			
			return null;
		}
		}
	}
	
	public AttemptType signatureType() {
		
		return AttemptType.QUICK;
	}


	protected GearPiece defaultPiece() {
		
		return pieceTemplate("Staff");
	}
	
	
	//placeholder lol
	private GearPiece pieceTemplate(String name) {
		
		return new GearPiece(name, "Metal", 
				"[u] sell[s] [pp] [op] to help pay for ", "[pp] new [np].");
	}
	
	protected GearPiece upPiece() {
		
		if (getImplement().equals("Staff")) {
			
			return pieceTemplate("Spear");
		} else if (getImplement().equals("Spear")) {
			
			return pieceTemplate("Lance");
		} else {
			
			return pieceTemplate("Staff");
		}
	}



	
	protected Action[] buildActions() {

		Action[] result = new Action[getTotalActions()];
		
		int[] cooldowns = {3, 3};

		String[] name = {"Throw", "Heavenpierce"};
		
		DamageScaler[] scalers = {(e -> {return Scaler.damage(getModdedLevel());}),
				(e -> {return (Scaler.damage((int)(getModdedLevel() * 1.5)));})};
	
		for (int s = 0; s < result.length; s++) {
			
			result[s] = new Skill(name[s], true, cooldowns[s], this, AllActions.getType(name[s]));
			
			result[s].addDamageScaler(scalers[s]);
		}
		
		return result;
	}
	
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Fighter's list of stats, this is intended
	 * to be used to quickly add a new, generic Shield
	 * Gear Stat to the input Fighter.
	 * 
	 * @param user Fighter to receive a new instance
	 * of this object.
	 * @return String describing the aquisition of this
	 * Stat.
	 */
	public static String add(Fighter user) {

		return user.formatMessage("[u] obtain[s] a new " + 
				new Spear(user, 0).getName() + ".\n");
	}
}
