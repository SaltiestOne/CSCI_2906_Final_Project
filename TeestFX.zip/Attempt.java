package finalProject;

import java.util.Random;

import finalProject.Attempt.AttemptType;

/**
 * Class for creating a representing
 * a potential action, in the context
 * of it opposed by another action.
 * 
 * @author Kayden Barlow
 */
public class Attempt {

	public static enum AttemptType {QUICK, WIDE, TRICK, BLOCK, EVADE, NEUTRAL};

	private Entity attempter;
	private boolean advantage = false;
	private AttemptType type;
	private boolean breaks = false;
	
	/**
	 * Creates a new Attempt that is neither
	 * a Tiebreaker nor Advantaged.
	 * 
	 * @param Attempter Entity making
	 * this Attempt.
	 * @param type AttemptType of this
	 * Attempt.
	 */
	Attempt(Entity Attempter, AttemptType type) {
		
		this(Attempter, false, type);
	}
	
	/**
	 * Creates a new Attempt that may
	 * have Advantage.
	 * 
	 * @param attempter Entity making this
	 * Attempt.
	 * @param advantage Boolean indicating
	 * if this Attempt was made with 
	 * Advantage.
	 * @param type AttemptType of this 
	 * Attempt.
	 */
	Attempt(Entity attempter, boolean advantage, AttemptType type) {
		
		this.attempter = attempter;
		this.type = type;
		this.advantage = advantage;
	}
	
	/**
	 * Creates a new Attempt that may
	 * be a Tiebreaker (without Advantage).
	 * 
	 * @param Attempter Entity making this
	 * Attempt. 
	 * @param type AttemptType of this 
	 * Attempt.
	 * @param breaks Boolean indicating if
	 * this Attempt breaks ties.
	 */
	Attempt(Entity Attempter, AttemptType type, boolean breaks) {
		
		this(Attempter, false, type);
		this.breaks = (breaks || (type == AttemptType.NEUTRAL));
	}
	
	
	/**
	 * Returns the Entity that 
	 * made this Attempt.
	 * 
	 * @return Entity maker of 
	 * this Attempt.
	 */
	Entity getAttempter() {
		
		return attempter;
	}
	
	
	/**
	 * Indicates which of the 
	 * six types of Attempts
	 * this one belongs to.
	 * 
	 * @return AttemptType of 
	 * this Attempt.
	 */
	AttemptType getType() {
		
		return type;
	}
	
	/**
	 * Indicates if this 
	 * Attempt was made with 
	 * Advantage.
	 * 
	 * @return True if this
	 * Attempt has Advantage,
	 * False otherwise.
	 */
	boolean hasAdvantage() {
		
		return advantage;
	}
	
	/**
	 * Indicates if this
	 * Attempt breaks ties.
	 * This is determined by 
	 * a few factors: Rusted
	 * types never break, and
	 * non-Rusted Attempts 
	 * with the Tiebreaker trait
	 * or ones made with Advantage
	 * always do.
	 * 
	 * @return True if this Attempt
	 * breaks ties, False if it does
	 * not.
	 */
	boolean breaksTies() {
		
		return ((hasAdvantage() || (breaks)) && (attempter.getRustedType() != getType()));
	}
	
	
	/**
	 * Indicates if this Attempt's
	 * type beats the input AttemptType. 
	 * 
	 * @param opposingType AttemptType to
	 * be compared against this Attempt's
	 * type.
	 * @return True if this Attempt beats 
	 * the input type, False if it loses
	 * or ties with it or if either are
	 * Neutral.
	 */
	public boolean beats(AttemptType opposingType) {
		
		return Attempt.beats(type, opposingType);
	}
	
	/**
	 * Indicates if this Attempt beats
	 * the input attempt based on their
	 * types.
	 * 
	 * @param defender Attempt whose type
	 * will be compared against this one's.
	 * @return True if this Attempt beats 
	 * the input Attempt, False if it 
	 * loses, draws, or if either are
	 * Neutral.
	 */
	public boolean beats(Attempt defender) {
		
		return beats(defender.getType());
	}
	
	/**
	 * Compares various parameters of 
	 * attempts made by two entities
	 * according to a set of rules.
	 * Returns a String describing
	 * the consequences of the clash,
	 * including its winner, if any.
	 * The order of parameters is 
	 * arbitrary, and the position
	 * is randomized before any 
	 * protocol takes place.
	 * 
	 * @param a Entity clashing with
	 * Entity "b."
	 * @param b Entity clashing with
	 * Entity "a."
	 * @return String describing the
	 * result of the clash.
	 */
	public static String clash(Entity a, Entity b) {
		
		String output = clash(a.getAttempt(b), b.getAttempt(a));
		
		System.out.println(output);
		
		return output;
	}
	
	/**
	 * Compares various parameters of 
	 * attempts made by two entities
	 * according to a set of rules.
	 * Returns a String describing
	 * the consequences of the clash,
	 * including its winner, if any.
	 * The order of parameters is 
	 * arbitrary, and the position
	 * is randomized before any 
	 * protocol takes place.
	 * 
	 * @param a Attempt clashing with
	 * Attempt "b."
	 * @param b Attempt clashing with
	 * Attempts "a."
	 * @return String describing the
	 * result of the clash.
	 */
	public static String clash(Attempt a, Attempt b) {
		
		if (new java.util.Random().nextBoolean()) {
			
			return neutralSortProtocol(a, b);
		} else {
			
			return neutralSortProtocol(b, a);
		}
	}
	
	/**
	 * Sends the input Attempts to different
	 * sub-protocol based on whether either,
	 * neither, or both of the Attempts 
	 * are of the Neutral type.
	 * 
	 * @param a Attempt clashing with
	 * Attempt "b."
	 * @param b Attempt clashing with
	 * Attempts "a."
	 * @return String describing the result
	 * of the clash to be sent back up
	 * this protocol hierarchy.
	 */
	private static String neutralSortProtocol(Attempt a, Attempt b) {
		
		if ((a.getType() == AttemptType.NEUTRAL) &&
				(b.getType() == AttemptType.NEUTRAL)) {
			//if both are neutral, go to double neutral
			return doubleNeutralProtocol(a, b);
		} else if ((a.getType() == AttemptType.NEUTRAL) ||
				(b.getType() == AttemptType.NEUTRAL)) {
			//if both are not neutral, but one is, go to single neutral
			if (a.getType() == AttemptType.NEUTRAL) {
				//if a is neutral, it is the first parameter
				return singleNeutralProtocol(a, b);
			} else {
				//if a is not netural, b must be (heh)
				return singleNeutralProtocol(b, a);
			}
		} else {
			//otherwise, go to non neutral protocol
			//TODO: Remove sysouts for Attempt clashes (3)
			System.out.println(a.attempter.getName() + " attempted " + a.getType() +
					", " + b.attempter.getName() + " attempted " + b.type);
			return nonNeutralProtocol(a, b);
		}
	}
	
	/**
	 * Protocol for when neither clashing
	 * Attempt is of the Neutral type.
	 * Sends the Attempts to the tied
	 * protocol if they are of the same 
	 * type, otherwise, compares their
	 * types to see who beats whom before 
	 * sending them to the winning 
	 * protocol.
	 * 
	 * @param a Attempt clashing with
	 * Attempt "b."
	 * @param b Attempt clashing with
	 * Attempts "a."
	 * @return String describing the result
	 * of the clash to be sent back up
	 * this protocol hierarchy.
	 */
	private static String nonNeutralProtocol(Attempt a, Attempt b) {
		
		if (a.getType() == b.getType()) {
		
			return tiedProtocol(a, b);
		} else {
			
			if (a.beats(b)) {
				
				return winningProtocol(a.attempter, b.attempter);
			} else {
				
				return winningProtocol(b.attempter, a.attempter);
			}
		}
	}
	

	/**
	 * Protocol for when one Attempt
	 * in the clash is Neutral, and 
	 * the other is not. Unlike other 
	 * protocols, the order is not 
	 * arbitrary. If the non-Neutral
	 * has Advantage, or if the
	 * Neutral is Rusted, the non-Neutal
	 * beats the Neutral and the 
	 * winning protocol is invoked.
	 * Otherwise, the Neutral's effect
	 * takes place without the other
	 * Attempt failing, per se.
	 * 
	 * @param neutral Attempt with the
	 * Neutral type.
	 * @param non Attempt without the
	 * Neutral type.
	 * @return String describing the result
	 * of the clash to be sent back up
	 * this protocol hierarchy.
	 */
	private static String singleNeutralProtocol(Attempt neutral, Attempt non) {
		
		if (non.hasAdvantage() || (!neutral.breaksTies())) {
			/*if non neutral has advantage, or neutral doesn't break ties (i.e. is rusted), do standard
			victory for the non neutral*/
			return winningProtocol(non.attempter, neutral.attempter);

		} else {
			//otherwise, neutrals always beat nons (but do not cause nons to "lose", per se)
			return (Formatter.capitalize(neutral.attempter.successfulAttempt(non.attempter)));
		}
	}
	
	/**
	 * Protocol for when both clashing
	 * Attempts are of the Neutral type.
	 * Checks to see if either party
	 * is either Advantaged or Rusted;
	 * Any Attempt that is will automatically
	 * win or lose respectively. Two
	 * Rusted Neutrals will result in the
	 * rare Neutral stalemate. If both
	 * lack either Advantage or Rust,
	 * then the "a" Attempt (which was 
	 * randomized at the highest protocol)
	 * wins and does its effect.
	 * 
	 * @param a Attempt clashing with
	 * Attempt "b."
	 * @param b Attempt clashing with
	 * Attempts "a."
	 * @return String describing the result
	 * of the clash to be sent back up
	 * this protocol hierarchy.
	 */
	private static String doubleNeutralProtocol(Attempt a, Attempt b) {
		
		if (!b.breaksTies() && !a.breaksTies()) {
			//if both are Rusted, stalemate occurs.
			return tiedProtocol(a, b);
			
		} else if (b.hasAdvantage() || (!a.breaksTies())) {
			//if "b" has advantage or "a" is rusted, "b" wins
			return (Formatter.capitalize(b.attempter.successfulAttempt(a.attempter)));
		} else {
			//likewise for "a". if neither are adv. or rusted, "a" wins by randomizer
			//since this covers all cases (crossies), extra ifs are not necessary
			return (Formatter.capitalize(a.attempter.successfulAttempt(b.attempter)));
		} 		
	}
	
	/**
	 * Protocol for when two
	 * non-Neutral Attempts of 
	 * the same type clash. If 
	 * either has Advantage, it
	 * wins. If one is a Tiebreaker
	 * while the other is not,
	 * it wins. In these cases,
	 * both are sent to the winning
	 * protocol. If both Attempts 
	 * are Tiebreakers, both are 
	 * non-Tiebreakers, or both are
	 * Rusted, than the Attempts
	 * stalemate and neither effect
	 * happens.
	 * 
	 * @param a Attempt clashing with
	 * Attempt "b."
	 * @param b Attempt clashing with
	 * Attempts "a."
	 * @return String describing the result
	 * of the clash to be sent back up
	 * this protocol hierarchy.
	 */
	private static String tiedProtocol(Attempt a, Attempt b) {
		
		if (a.hasAdvantage()) {
			
			return winningProtocol(a.attempter, b.attempter);
			
		} else if (b.hasAdvantage()) {
			
			return winningProtocol(b.attempter, a.attempter); 
		} else if (b.breaksTies() && !a.breaksTies()) {
			
			return winningProtocol(b.attempter, a.attempter);
		} else if (a.breaksTies() && !b.breaksTies()) {
			
			return winningProtocol(a.attempter, b.attempter);
		} else {
			//TODO: Remove sysouts for Attempt clashes (1)
			System.out.println(b.type + "s tied");
			return (Formatter.capitalize(b.attempter.failedAttempt(a.attempter)) +
					", and at the same time, " + (a.attempter.failedAttempt(b.attempter)) +
					". It's a stalemate.");
			
		}
	}
	
	/**
	 * Protocol for handling victory
	 * when it has been determined 
	 * by other protocol. Invokes the
	 * successfulAttempt method from 
	 * the winning Entity, which should
	 * both facilitate the effect of 
	 * winning and provide a String
	 * describing such. The loser's 
	 * counterpart method, failedAttempt,
	 * is also invoked. Any "[f]" 
	 * placeholders in the former String
	 * will be replaced by the latter.
	 * 
	 * @param winner Entity whose Attempt
	 * won the clash.
	 * @param loser Entity whose Attempt
	 * lost the clash.
	 * @return String describing the 
	 * effect of the clash, to be sent back
	 * up the protocol hierarchy.
	 */
	private static String winningProtocol(Entity winner, Entity loser) {
		//TODO: Remove sysouts for Attempt clashes (2)
		System.out.println(winner.getName() +" beat " + loser.getName());
		return (Formatter.capitalize(winner.successfulAttempt(loser).replace("[f]",
				loser.failedAttempt(winner))));
	}
	
	/**
	 * Returns an AttemptType enum
	 * from its name represented as
	 * a String. Input String is not
	 * case-sensitive, but must contain
	 * the exact name of an AttemptType.
	 * 
	 * @param name String name of a 
	 * desired AttemptType.
	 * @return AttemptType sharing its
	 * name with the input String.
	 */
	public static AttemptType typeFromName(String name) {
		
		switch(name.toLowerCase()) {
		
		case ("quick"): {
			
			return AttemptType.QUICK;
		}
		
		case ("wide"): {
			
			return AttemptType.WIDE;
		}

		case ("trick"): {
			
			return AttemptType.TRICK;
		}
		
		case ("evade"): {
			
			return AttemptType.EVADE;
		}
		
		case ("block"): {
			
			return AttemptType.BLOCK;
		}
		
		case ("neutral"): {
			
			return AttemptType.NEUTRAL;
		}

		default: {
			
			throw new IllegalArgumentException("\"" + name + "\" is not an AttemptType.");
		}
		}
	}
	
	/**
	 * Convenience method that returns
	 * an AttemptType represented by a 
	 * particular id number. Each is
	 * identical to the type that returns a
	 * specific id via the idFromType method.
	 * QUICK is 0, WIDE is 1, TRICK is 2,
	 * EVADE is 3, BLOCK is 4, NEUTRAL is 5.
	 * 
	 * @param id Integer id corresponding
	 * to a desired AttemptType.
	 * @return AttemptType corresponding to
	 * the input id.
	 */
	public static AttemptType typeFromId(int id) {
		
		switch (id) {
		
		case (0): {
			
			return AttemptType.QUICK;
		}
		
		case (1): {
			
			return AttemptType.WIDE;
		}
		
		case (2): {
			
			return AttemptType.TRICK;
		}
		
		case (3): {
			
			return AttemptType.EVADE;
		}

		case (4): {
			
			return AttemptType.BLOCK;
		}
		
		default: {
			
			return AttemptType.NEUTRAL;
		}
		}
	}
	
	/**
	 * Randomly returns one of the
	 * five non-NEUTRAL AttemptTypes
	 * (QUICK, WIDE, TRICK, EVADE, or
	 * BLOCK).
	 *  
	 * @return AttemptType randomly 
	 * pulled from a list of the 
	 * non-NEUTRAL types.
	 */
	public static AttemptType randomNonNeutral() {
		
		return typeFromId(new Random().nextInt(5));
	}
	
	/**
	 * Randomly returns one of the
	 * six possible AttemptTypes
	 * (QUICK, WIDE, TRICK, EVADE,
	 * BLOCK, or NEUTRAL).
	 * 
	 * @return AttemptType randomly
	 * selected from all types.
	 */
	public static AttemptType randomWithNeutral() {
		
		return typeFromId(new Random().nextInt(6));
	}
	
	/**
	 * Randomly returns one of the 
	 * AttemptTypes that do damage
	 * in basic Attempts (QUICK, 
	 * WIDE, or TRICK).
	 * 
	 * @return AttemptType randomly
	 * selected from the three attacking
	 * types.
	 */
	public static AttemptType randomAttack() {
		
		return typeFromId(new Random().nextInt(3));
	}

	/**
	 * Randomly returns one of the 
	 * AttemptTypes that grant advantage
	 * in lieu of doing damage in
	 * basic Attempts (EVADE or BLOCK).
	 * 
	 * @return Attempt randomly 
	 * selected between the two defensive
	 * types.
	 */
	public static AttemptType randomDefensive() {
	
		return typeFromId(new Random().nextInt(2) + 3);
	}	
	
	/**
	 * Convenience method that returns
	 * an integer id representing a 
	 * particular AttemptType. Each is
	 * identical to the id used to get an
	 * AttemptType via the typeFromId method.
	 * QUICK is 0, WIDE is 1, TRICK is 2,
	 * EVADE is 3, BLOCK is 4, NEUTRAL is 5.
	 * 
	 * @param type AttemptType to converted
	 * to an id number.
	 * @return Integer id number of the 
	 * input AttemptType.
	 */
	public static int idFromType(AttemptType type) {
		
		switch (type) {
		
		case QUICK: {
			
			return 0;
		}
		
		case WIDE: {
			
			return 1;
		}
		
		case TRICK: {
			
			return 2;
		}
		
		case EVADE: {
			
			return 3;
		}

		case BLOCK: {
			
			return 4;
		}
		
		default: {
			
			return 5;
		}
		}
		
	}

	/**
	 * Returns a boolean indicating 
	 * if one AttemptType beats 
	 * another. If a tie occurs,
	 * or if either is Neutral, 
	 * than False is returned as
	 * if the "attacker" parameter
	 * lost.
	 * 
	 * @param attacker AttemptType
	 * clashing with the "defender."
	 * @param defender AttemptType
	 * clashing with the "attacker."
	 * @return True if attacker beats
	 * defender, False otherwise.
	 */
	public static boolean beats(AttemptType attacker, AttemptType defender) {

		if (defender == AttemptType.NEUTRAL) {
			
			return false;
		} else {
		
			switch (attacker) {
			
			case WIDE: {
				
				return ((defender == AttemptType.TRICK) || 
						(defender == AttemptType.EVADE));
			}
			
			case TRICK: {
				
				return ((defender == AttemptType.BLOCK) ||
						(defender == AttemptType.EVADE));
			}
			
			case QUICK: {
				
				return ((defender == AttemptType.TRICK) ||
						(defender == AttemptType.WIDE));
			}
			
			case EVADE: {
				
				return ((defender == AttemptType.QUICK) ||
						(defender == AttemptType.BLOCK));
			}
			
			case BLOCK: {
				
				return ((defender == AttemptType.WIDE) ||
						(defender == AttemptType.QUICK));
			}
			
			default: {
				
				return false;
			}
			}
		}
	}

}


