package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.Attacking;

public class Shadow extends Monster {
	
	Shadow(Hero original) {
		
		super((original.getPossesiveName() + " Shadow"), shadowFlavor(original), original.getLevel());
		
		setPronouns(PronounSet.neutralPronouns());
		
		setAttackingStat(new ShadowStat(this, original));

	}
	
	public String getPerspectiveName() {
		
		return getName();
	}

	/**
	 * Returns a special MonsterFlavor
	 * built around the PronounSet
	 * of the "original" Hero for
	 * its flavor text.
	 * 
	 * @param original Hero building 
	 * this Shadow.
	 * @return MonsterFlavor formatted
	 * around the "original" hero.
	 */
	private static MonsterFlavor shadowFlavor(Hero original) {
		
		MonsterFlavor result = new MonsterFlavor();

		result.setStatusText(original.formatMessage("Is it [pp] own guilt and sins? A demon mocking such?\n" +
		"The ghost of a previous hero? If " + original.getPerspectiveName() + " survive[s], maybe [ps] can guess."));
		//result.setImage("Monsters\\Images\\Shadow.png");
		
		return result;
	}
	
	
	/**
	 * The Shadow's Attempts always break
	 * ties so long as they do not make
	 * an Attempt with their rusted type. 
	 */
	public boolean getBreaker() {
		
		return (getRustedType() != getCurrentType());
	}
	

	public String defaultSuccessStrings(AttemptType type) {
		
		return null;
	}


	public String defaultFailureStrings(AttemptType type) {

		return "[u] loom[s]";
	}


	protected int healthScale() {

		return Scaler.enemyHealth(getLevel() + 1);
	}



	protected boolean specialProcedure() {
		
		do {
			
			setAttemptPlan(Attempt.randomNonNeutral());
			
		} while (getRustedType() == getCurrentType());
	
		return false;
	}


	boolean subAfflict(Affliction affliction) {

		return false;
	}


	protected String subTypeStatusText() {
		
		return (getName() + "\nLevel " + getLevel() + "\n" + getFlavor().getStatusText());
	}

	protected Attacking subclassStat(String key) {
		
		return null;
	}


	protected String handleFailure(Entity target) {
		
		return getAttackingStat().failureMessage(getCurrentType());
	}

	
	private class ShadowStat extends Stat implements Attacking {
		
		private String[] imitations = new String[5];
		
		ShadowStat(Shadow user, Hero original) {
			
			super(user, "ShadowStat", Stat.getMaxLevel(), 0);
			
			setImitations(original);
		}
		
		private void setImitations(Hero original) {
			
			for (int a = 0; a < 5; a++) {
				
				try {
				
					Action[] actions =
							original.getActionList().allOfAttemptType(Attempt.typeFromId(a));
					
					imitations[a] = ("[u] imitate[s] [tp] " + 
							actions[new java.util.Random().nextInt(actions.length)].getName() + ".\n");
				
				} catch (IllegalArgumentException ex) {
					
					imitations[a] = "[u] imitate[s] [to] exactly.\n";
				}
			}
		}
		
		public String attackMessage(AttemptType type) {
			
			return ("[f], but at the same moment, " + imitations[Attempt.idFromType(type)]);
		}
		
		public String advantagedMessage(AttemptType type) {
			
			return ("before [t] can even consider [tp] move, " + imitations[Attempt.idFromType(type)]);
		}
		
		
		public String failureMessage(AttemptType type) {
			
			return "[u] loom[s]";
		}


		public AttemptType signatureType() {
			//all of the shadown's actions are tiebreakers anyway
			return AttemptType.NEUTRAL;
		}

		@Override
		protected Action[] buildActions() {
			
			return null;
		}

		@Override
		protected String upgrade() {
			
			return null;
		}
		
	}


	protected String defaultSubTypeImage() {

		return "Monsters\\Images\\Shadow.png";
	}




	
}
