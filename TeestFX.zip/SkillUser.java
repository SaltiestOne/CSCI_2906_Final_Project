package finalProject;


/**
 * Interface marking that this ActionUser
 * Entity uses Skills. 
 * 
 * @author Kayden Barlow
 */
interface SkillUser extends ActionUser {

	
	/**
	 * Returns the integer representing
	 * the number of turns remaining until
	 * this ActionUser can use another Skill.
	 * (If the user can use other types of
	 * Actions, they will be unaffected by
	 * this restriction).
	 * 
	 * @return Integer value of cooldown.
	 */
	Cooldown cooldown();
	
	/**
	 * Returns a boolean indicating if
	 * cooldown is a positive value, 
	 * and therefor that Skills are on 
	 * cooldown.
	 * 
	 * @return True if cooldown is greater than
	 * zero, False if it is zero (or less, somehow).
	 */
	//boolean isOnCooldown();
	
	/**
	 * Sets Cooldown to the specified value.
	 * Cooldown should not be negative.
	 * 
	 * @param cooldown Integer new Cooldown.
	 */
	//void setCooldown(int cooldown);
	
	/**
	 * Drops Cooldown by 1. Intended to be 
	 * invoked at the end of every turn.
	 */
	//public void dropCooldown();
	
	/**
	 * Reduces Cooldown value by the input
	 * amount. Cooldown cannot be negative.
	 * 
	 * @param decrement Integer amount to reduce
	 * Cooldown.
	 */
	//void dropCooldown(int decrement);

	
	//protected class Disarm extends Affliction {
		
		
	//}
	
	public class Cooldown {
		
		private int cooldown = 0;
		
		Cooldown() {}
		
		
		/**
		 * Returns the integer representing
		 * the number of turns remaining until
		 * this ActionUser can use another Skill.
		 * (If the user can use other types of
		 * Actions, they will be unaffected by
		 * this restriction).
		 * 
		 * @return Integer value of cooldown.
		 */
		int value() {
			
			return cooldown;
		}
		
		/**
		 * Returns a boolean indicating if
		 * cooldown is a positive value, 
		 * and therefor that Skills are on 
		 * cooldown.
		 * 
		 * @return True if cooldown is greater than
		 * zero, False if it is zero (or less, somehow).
		 */
		boolean isOnCooldown() {
			
			return (cooldown > 0);
		}
		
		/**
		 * Sets Cooldown to the specified value.
		 * Cooldown should not be negative.
		 * 
		 * @param cooldown Integer new Cooldown.
		 */
		public void set(int cooldown) {
			
			this.cooldown = (Math.max(0, cooldown));
		}
		
		/**
		 * Drops Cooldown by 1. Intended to be 
		 * invoked at the end of every turn.
		 */
		public void drop() {
			
			drop(1);
		}
		
		/**
		 * Reduces Cooldown value by the input
		 * amount. Cooldown cannot be negative.
		 * 
		 * @param decrement Integer amount to reduce
		 * Cooldown.
		 */
		public void drop(int decrement) {

			cooldown -= (Math.min(decrement, cooldown));	
		}
	}
}
