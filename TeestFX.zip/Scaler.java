package finalProject;
import java.util.Random;

/**
 * Abstract class which stores static
 * methods used to scale various parts
 * of Teest. This is more a convenience
 * than anything; it shortens the code
 * that calls it and allows all scaling
 * formulae to be found in one place. 
 * 
 * @author Kayden Barlow
 */
abstract public class Scaler {

	static private int round = 1;	
	
	
	/**
	 * Returns the value of the 
	 * static round parameter.
	 * 
	 * @return Integer value of 
	 * the round parameter.
	 */
	public static int getRound() {
		
		return round;
	}
	
	
	/**
	 * Increments the value of the 
	 * static round parameter. 
	 */
	public static void upRound() {
		
		round++;
	}
	
	
	/**
	 * Returns a random integer generated
	 * according to two factors, intended to
	 * be used for Action scaling. The first,
	 * the "floor" integer, is the mimimum
	 * output value. The second, the
	 * "fluctuation" value, adds one-fourth
	 * of itself (rounded down) to the fixed
	 * number 6 to determine the range of
	 * the random numbers possible. Fluctuation 
	 * is determined in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. For this reason,
	 * the fluctuation value should just be 
	 * the Hero's level in most cases.
	 * 
	 * @param floor Integer minimum output.
	 * @param fluctuation Integer used to adjust
	 * range of outputs.
	 * @return Random integer, scaled according 
	 * to above formula.
	 */
	static int damage(int floor, int fluctuation) {
		
		return ((new Random().nextInt(6 + (int)(fluctuation * 0.25))) + floor);
	}
	
	
	/**
	 * Returns a random integer generated
	 * according to the input integer, intended 
	 * to be used for Action scaling. The
	 * "floor" of the output, equal to the input, 
	 * is the mimimum output value. The 
	 * "fluctuation" value, adds one-fourth
	 * the input (rounded down) to the fixed
	 * number 6 to determine the range of
	 * the random numbers possible. Fluctuation
	 * is determined in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. This method is 
	 * used in cases where the floor and 
	 * fluctuation are equal.
	 * 
	 * @param mod Integer minimum of the output.
	 * @return Random integer, scaled according 
	 * to above formula.
	 */
	static int damage(int mod) {
		
		return damage(mod, mod);
	}
	
	
	/**
	 * Returns a random integer generated
	 * according to the static "round" parameter
	 * of this class, which is intended to be used 
	 * for Action scaling. The "floor" of the output, 
	 * equal to the round parameter, is the mimimum 
	 * output value. The "fluctuation" value adds 
	 * one-fourth the round parameter (rounded down) 
	 * to the fixed number 6 to determine the range of
	 * the random numbers possible. Fluctuation
	 * is determined in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. This method is 
	 * used in cases where the round parameter
	 * is satisfactory for scaling.
	 * 
	 *@return Random integer, scaled according 
	 * to above formula.
	 */
	static int damage() {
		
		return damage(round);
	}
	
	
	/**
	 * Returns a random integer derived from the
	 * input Stat object, which is intended to be used 
	 * for Action scaling. The "floor" of the output, 
	 * equal to the level parameter of the Fighter
	 * associated with the input Stat object, is the 
	 * mimimum output value. The "fluctuation" value adds 
	 * one-fourth the modded level value of the Stat
	 * (rounded down) to the fixed number 6 to determine 
	 * the range of the random numbers possible. Fluctuation
	 * is determined in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. This method is 
	 * used in cases where this particular set of derived
	 * variables is used for scaling. 
	 * 
	 * @param stat Stat object used for scaling.
	 * @return Random integer, scaled according to the 
	 * above formula.
	 */
	static int damage(Stat stat) {
		
		return Scaler.damage((stat.getModdedLevel()), stat.getUser().getLevel());
	}
	
	
	/**
	 * Returns a random integer to
	 * be used for an enemy's health
	 * parameter, scaled from an input
	 * integer.
	 * 
	 * @param level Integer value used to
	 * scale output, intended to be the
	 * enemy's level parameter.
	 * @return Integer used to determine
	 * the enemy's starting health.
	 */
	public static int enemyHealth(int level) {
		
		return ((7 * level) + 5);
	}
	
	/**
	 * Returns a random integer to
	 * be used for an enemy's health
	 * parameter, scaled from the static
	 * round parameter.
	 * 	
	 * @return Integer used to determine
	 * the enemy's starting health.
	 */
	public static int enemyHealth() {
		
		return enemyHealth(round);
	}
	
	/**
	 * Returns an integer used to determine 
	 * the value to be set to a Monster's damage 
	 * parameter, scaled from the Monster's 
	 * level parameter. This value has a low floor
	 * but a ceiling that scales faster than
	 * the Hero's damage scalers. 
	 * 
	 * @param level Integer value of the 
	 * Monster's level parameter.
	 * @return Integer scaled from input.
	 */
	static int enemyDamage(int level) {
		
		return (new Random().nextInt(2 + (int)(3.2 * (level))) + 1);
	}
	
	
	/**
	 * Returns an integer used to determine 
	 * the value to be set to a Monster's damage 
	 * parameter, scaled from the current round
	 * parameter. This value has a low floor
	 * but a ceiling that scales faster than
	 * the Hero's damage scalers. 
	 * 
	 * @return Integer scaled from the current
	 * round parameter.
	 */
	static int enemyDamage() {
		
		return (enemyDamage(Scaler.round));
	}
	
	
	/**
	 * Returns an integer used to determine
	 * the Hero's maximum health paramter.
	 * Value is scaled from the Hero's level,
	 * with an extra parameter added linearly
	 * (intended to be the sum collected from
	 * the HealthScale interface).
	 * 
	 * @param level Integer of the number used
	 * to scale the output.
	 * @param statScaler Integer added to the 
	 * scaled input.
	 * @return Integer intended to be used for
	 * a Fighter's maximum health parameter.
	 */
	static int maxHealth(int level, int statScaler) {
		
		return ((int)(7 * level) + 3 + statScaler);
	}
	
	/**
	 * Returns an integer derived from the 
	 * Scaler formula for maximum health, using
	 * the static round parameter in lieu of
	 * a Fighter level.
	 * 
	 * @return Integer intended to be used for
	 * a Fighter's maximum health parameter.
	 */
	static int maxHealth() {
		
		return maxHealth(Scaler.round, 0);
	}
	
	
	/**
	 * Returns an integer used to determine
	 * the Hero's maximum Mana paramter.
	 * Value is scaled from the Hero's level,
	 * with an extra parameter added linearly
	 * (intended to be the sum collected from
	 * the ManaScale interface).
	 * 
	 * @param level Integer of the number used
	 * to scale the output.
	 * @param statScaler Integer added to the 
	 * scaled input.
	 * @return Integer intended to be used for
	 * a Fighter's maximum Mana parameter.
	 */
	static int maxMana(int level, int statScaler) {
		
		return (2 + (level * 2) + statScaler);
	}
	
	
	/**
	 * Returns an integer derived from the 
	 * Scaler formula for maximum Mana, using
	 * the static round parameter in lieu of
	 * a Fighter level.
	 * 
	 * @return Integer intended to be used for
	 * a Fighter's maximum Mana parameter.
	 */
	static int maxMana() {
		
		return maxMana(Scaler.round, 0);
	}
}


