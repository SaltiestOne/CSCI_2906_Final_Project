package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.*;

/**
 * Magic subclass for a school
 * of Magic involving summoning
 * phantoms and arcane objects.
 * Has lower Mana/Caster scaling,
 * but can natively Attack and Block.
 * 
 * @author Kayden Barlow
 */
public class Conjuration extends Magic implements Attacking, Blocking {

	/**
	 * Constructor for new Conjuration Stats.
	 * Like all Magic subclasses, requires 
	 * a Caster user.
	 * 
	 * @param user Caster to which this
	 * Conjuration Stat will be assigned. 
	 * @param level Integer value of this
	 * Stat's initial relative power.
	 */
	Conjuration(Caster user, int level) {
		
		super(user, "Conjuration", level, 2);
	}
	
	/**
	 * Returns a String for Attempts
	 * of a few different types, in 
	 * order to consolidate and 
	 * standardize certain sentences
	 * between the successful, failed,
	 * and advantaged basic Attempts.
	 * Returns these Strings for 
	 * QUICK, WIDE, and TRICK types,
	 * and null for others. The "[i]"
	 * ("implement") and "[v]" ("verb")
	 * placeholders should be replaced
	 * by calling methods before being
	 * sent to other objects or printed.
	 * 
	 * @param type AttemptType of desired
	 * String. 
	 * @return String forming part of a 
	 * sentence describing an Attempt.
	 */
	private String baseString(AttemptType type) {
		
		switch (type) {
		
		case QUICK: {
			
			return ("[u] summon[s] [i] while [f] and [v].\n");
		}
		
		case WIDE: {
			
			return ("as [f], [u] call[s] upon [i]. It coalesces, and rushes [to] down.\n");
		}
		
		case TRICK: {
			
			return ("As [f], [u] summon[s] [i] to grip [to]. Once secured, [ps] [v].\n");
		}
		
		default:
			
			return null;
		}
	}

	public String attackMessage(AttemptType attemptType) {
		
		
		try {
			
			switch (attemptType) {
				
			case QUICK: {
				
				return (baseString(AttemptType.QUICK).replace("[i]", "a phantom weapon")).
						replace("[v]", "strike[s] [to]");
			}
			
			case WIDE: {
				
				return (baseString(AttemptType.WIDE).replace("[i]", "a phantom double"));
			}
			
			case TRICK: {
				
				return (baseString(AttemptType.TRICK).replace("[i]", "a chain")).
						replace("[v]", "slam[s] [t] into the ground");
			}

			default:
				
				return getUser().defaultSuccessStrings(attemptType);
			}
			
		} catch (NullPointerException ex) {
			
			return getUser().defaultSuccessStrings(attemptType);
		}
	}
	
	
	
	public String advantagedMessage(AttemptType type) {
			
		switch(type) {

		case QUICK: {
			
			return (baseString(AttemptType.QUICK).replace("[i]", "an arsenal of weapons")).
					replace("[v]", "barrage[s] [to]");
		}
		
		case WIDE: {
			
			return (baseString(AttemptType.WIDE).replace("[i]", "the image of a beast"));
		}
		
		case TRICK: {
			
			return (baseString(AttemptType.TRICK).replace("[i]", "chains")).
					replace("[v]", "strangle[s] [t]");
		}
		
		case BLOCK: {
			
			return ("[u] open[s] portals behind [pf] and [t]. Jumping back, [ps] strikes [to] from behind as [f].\n");
		}
		
		case EVADE: {
			
			return ("[u] create[s] illusory doubles of [pf]. As [f], [ps] strike[s] [t] from behind.\n");
		}
		
		default: {
			
			return attackMessage(type);
		}
		}
	}
	
	public String failureMessage(AttemptType type) {
		//TODO: better failure messages for conjuration
		return "[u] begin[s] summoning a phantom";
	}
	
	public AttemptType signatureType() {
		
		return AttemptType.WIDE;
	}
	
	
	public int blockPotency() {

		return 1;
	}

	public int blockStringPriority() {

		return 20;
	}


	public String successfulBlockString() {

		return "[u] summons[s] an arcane barrier. Though [f], the shield deflects the blow.\n";
	}


	public String failedBlockString() {
		
		return "[u] summons[s] an arcane barrier";
	}
	
	public int manaScale() {
		
		return getLevel() * 2;
	}
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Caster's list of stats, this is intended
	 * to be used to quickly add a new, generic Arcanism
	 * Stat to the input Caster.
	 * 
	 * @param user Caster to receive a new instance
	 * of this object.
	 * @return String describing the aquisition of the 
	 * new Stat.
	 */
	public static String add(Caster user) {
		
		return user.formatMessage("[u] learn[s] the basics of " + 
				new Conjuration(user, 0).getName() + ".\n");
	}
}
