package finalProject;

import java.util.Random;

import finalProject.Attempt.AttemptType;
import finalProject.HumanoidMonster.EnemyImplement;


/**
 * Subclass of HumanoidMonster that
 * is able to cast Spells.
 * 
 * @author Kayden Barlow
 */
public class Spellcaster extends HumanoidMonster implements Caster {
	
	private Spell mainSpell;
	private Spell subSpell;
	private boolean silenced;
	private ManaGauge mana;

	
	Spellcaster(String name, MonsterFlavor flavor, int level, Spell spell) {
		
		this(name, flavor, level);
		
		this.mainSpell = spell;
	}
	
	
	
	Spellcaster(String name, MonsterFlavor flavor, int level) {
		
		super(name, flavor, level);
		
		mana = new ManaGauge(getLevel() * 6);
		
		setAttackingStat(subclassStat(""));
	}
	
	
	
	protected String subTypeStatusText() {
		
		return (getName() + "\nLevel " + getLevel() + " Spellcaster");
	}
	
	protected String defaultSubTypeImage() {
		
		return "Monsters\\DefaultImages\\SpellMonsterDefault.png";
	}


	protected Stat.Attacking subclassStat(String key) {
		
		if (key.equals("Conjuration")) {
			
			return new Conjuration(this, Stat.getMaxLevel());
		} else if (key.equals("Elementalism")) {
			
			return new Elementalism(this, Stat.getMaxLevel());
		} else {

			return fetchImplement(this, key);
		}
	}
	
	
	
	public void setMainSpell(Spell spell) {
		
		this.mainSpell = spell;
		
		this.mainSpell.addDamageScaler((e -> {return Scaler.enemyDamage(getLevel() + 1);}));
		
		specialProcedure();
	}
	
	
	public void setSubSpell(Spell spell) {
		
		this.subSpell = spell;
		
		this.subSpell.addDamageScaler((e -> {return Scaler.enemyDamage(getLevel() + 1);}));
		
		specialProcedure();
	}
	
	
	
	public String disable(int potency) {
		
		potency = ((potency * mana.getMax()) / getMaxHealth());
		
		mana.adjust(-potency);
		
		silenced = true;
		
		return (potency + " Mana");
	}
	
	/*
	public boolean isDisabled() {
		
		if (mana.getCurrent() < spell.getCost()) {
			
			return true;
		} else {
			
			return false;
		}
	}*/
	
	public Attempt getAttempt(Entity target) {
		
		if (isOnSpecial()) {
			
			return mainSpell.getAttempt(target);
		} else if (hasAdvantage(target)) {
			
			return new Attempt(this, hasAdvantage(target), getCurrentType());
		} else {
			
			return new Attempt(this, getCurrentType(), getBreaker());
		}
	}
	
	
	
	protected boolean specialProcedure() {
		
		try {
		
			if ((getHealth() <= (getMaxHealth() / 5))
					&& (mainSpell.isUsable())) {
				
				return setSpecial(true);
			
			} else {
			
				AttemptType plan = Attempt.randomWithNeutral();
				
				if ((plan == AttemptType.NEUTRAL) || 
						(plan == getRustedType())) {
					
					if (trySpell()) {

						setAttemptPlan(mainSpell.getAttemptType());
				
					} else {
						
						setAttemptPlan(Attempt.randomNonNeutral());
					}
				} else {
					
					setAttemptPlan(plan);
				}	
			}
			
			return isOnSpecial();
			
		} catch (NullPointerException ex) {
			//in case the Spell has not been set yet.
			return false;
		}
	}
	
	
	
	private boolean trySpell() {
		
		try {
			
			if (mainSpell.isUsable()) {
			
				if (getHealth() < ((getMaxHealth() / 4))) {
					//"desperation" attack
					return setSpecial(true);
				} else if (mana.getCurrent() < (mainSpell.getCost() * 2)) {
					//saves a spell for the desperation attack
					return setSpecial(false);
				} else 
					
					return setSpecial(true);
			} else {
				
				return setSpecial(false);
			}
		} catch (NullPointerException ex) {
			//in case the Spell has not been set.
			return false;
		}
	}
	
	protected boolean subAfflict(Affliction affliction) {

		switch (affliction.name) {
		
		case ("collapse"): {
			
			if (getMana() > 0) {
				
				setMana(getMana() - Math.min(1, affliction.potency));
				return true;
			} else {
				
				return false;
			}
		}
		
		default: {
			
			return false;
		}
		}
	}
	
	
	public String action(Entity target) {
		
		if (isStunned()) {
			
			return stunnedMessage(target);
			
		} else if (isOnSpecial() && !isDead()) {
			
			if (mainSpell.isUsable()) {

				return mainSpell.doAction(target, false);
			} else {
				
				return (getPerspectiveName() + " is unable to cast spells...\n\n");
			}
		} else {
			
			return doBasic(target);
		}
	}

	
	
	public void setMaxMana(int maxMana, boolean maximize) {

		mana.setMax(maxMana, maximize);
	}


	public int getMaxMana() {
		
		return mana.getMax();
	}

	
	public void setMana(int mana) {

		this.mana.setCurrent(mana);
	}

	public void adjustMana(int mana) {

		this.mana.adjust(mana);
	}

	
	public int getMana() {
	
		return mana.getCurrent();
	}

/*
	protected Behavior getBehavior(String name) {
		
		switch (name) {
		
		case ("reserve"): {
		
			return (m -> {
				
				try {
					
					if (mainSpell.isUsable()) {
					
						if (getHealth() < ((getMaxHealth() / 5))) {
							//"desperation" attack
							return setSpecial(true);
						} else if (mana.getMana() < (mainSpell.getCost() * 2)) {
							//saves a spell for the desperation attack
							return setSpecial(false);
						} else 
							//otherwise, uses it
							return setSpecial(true);						
					} else {
						
						return setSpecial(false);
					}
				} catch (NullPointerException ex) {
					//in case the Spell has not been set.
					return false;
				}});
			
		}
		
		/*case ("turret"): {
			
			setSubSpell(new Spell("Ascend", true, 0, getStats()[0], false));
			
			return (m -> {

				
				try {
					
					
					if (mainSpell.isUsable()) {
					
						if (getHealth() < ((getMaxHealth() / 5))) {
							//"desperation" attack
							return setSpecial(true);
						} else if (mana.getMana() < (mainSpell.getCost() * 2)) {
							//saves a spell for the desperation attack
							return setSpecial(false);
						} else 
							//otherwise, uses it
							return setSpecial(true);						
					} else {
						
						return setSpecial(false);
					}
				} catch (NullPointerException ex) {
					//in case the Spell has not been set.
					return false;
				}});
		}
		
		default: {
			
			return null;
		}
		}
	}*/

	public ManaGauge mana() {
	
		return mana;
	}

	@Override
	public boolean addAction(Action action) {

		return false;
	}

	@Override
	public Action getAction(String actionName) {

		return null;
	}


	public Action getAction(Action action) {

		return null;
	}


	public boolean hasAction(String actionName) {

		return false;
	}


	public String handleFailure(Entity target) {

		if (isOnSpecial()) {
			
			return formatMessage(mainSpell.failureString(), target);
		} else {
			
			return formatMessage(getAttackingStat().failureMessage(getCurrentType()), target);
		}
	}
	

	protected int defaultDamageScaling() {

		return Scaler.enemyDamage(getLevel());
	}


	public int magicScaler() {

		return getLevel() * 4;
	}

	/**
	 * Attempts to reduce current Mana by
	 * the input amount. Returns a Boolean
	 * indicating if Mana was spent.
	 * 
	 * @param amount Integer reduction in current Mana.
	 * @return Boolean True if Mana was sufficient and
	 * was spent, False otherwise.
	 *
	public boolean spendMana(int amount) {

		if (amount > getMana()) {
			
			return false;
		} else {
			
			mana.adjust(-amount);
			
			return true;
		}
	}*/
}