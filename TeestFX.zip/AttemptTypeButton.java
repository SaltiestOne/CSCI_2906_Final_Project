package finalProject;

import finalProject.Attempt.AttemptType;

/**
 * FormattedButton that displays 
 * the name of one of the AttemptTypes,
 * as well its status as a Tiebreaker 
 * or Rusted type, depending on the
 * circumstances of an assigned Fighter.
 * 
 * @author Kayden Barlow
 */
public class AttemptTypeButton extends FormattedButton implements PaintableButton {

	Fighter user;
	AttemptType type;
	
	/**
	 * Creates a new AttemptTypeButton 
	 * with the input Fighter user
	 * for one of the six AttemptTypes.
	 * Will be painted on construction.
	 * Has not OnAction set by default.
	 * 
	 * @param user Fighter user of this
	 * button, i dunno
	 * @param type AttemptType displayed
	 * by this button.
	 */
	AttemptTypeButton(Fighter user, AttemptType type) {
		
		this.user = user;
		this.type = type;
		
		this.setFont(Formatter.getItalicFont(14));
		
		paint();
	}
	
	
	/**
	 * Returns the AttemptType
	 * assigned to this Button.
	 * 
	 * @return AttemptType 
	 * assigned to this button.
	 */
	public AttemptType getType() {
		
		return type;
	}
	
	/**
	 * Displays the String name
	 * of the AttemptType assigned
	 * to this Button, along with
	 * extra text indicating if 
	 * the assigned Fighter makes
	 * said type a Tiebreaker, if
	 * the type is Rusted for them,
	 * and if the Fighter is 
	 * set to use the type. Color
	 * is also adjusted based on this 
	 * information. Color and Font
	 * are defined by the static
	 * Formatter class, as with all
	 * FormattedButtons. 
	 */
	public void paint() {
		
		String base = ("\n" + type.name() + "\n ");
		
		if (user.getCurrentType() == type) {
			
			base = ("  SET  " + base);
			setTextFill(Formatter.getMainColor());
		} else {
			
			setTextFill(Formatter.getFadeColor());
		}
		
		if (user.getRustedType() == type) {
			
			setText(base + "  (Rusted)");
			setTextFill(Formatter.getWarnColor());
		} else if (user.getAttackingStat().signatureType() == type) {
			
			setText(base + "(Tiebreaker)");
		} else {
			
			setText(base);
		}	
	}
}
