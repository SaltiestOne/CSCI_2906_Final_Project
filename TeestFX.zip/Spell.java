package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Caster.ManaGauge;

/**
 * A subclass of Action intended to represent
 * the various magical spells that the Hero can
 * cast. Uses a classic "Mana" system, where
 * an amount of resource is available at the
 * start of a fight, with different Spell
 * objects costing a specified amount of it.
 * 
 * @author Kayden Barlow
 */
class Spell extends Action {
	
	
	
	/**
	 * Constructor for  instances of a Spell object.
	 * 
	 * @param name String of the Spell's name.
	 * @param manaCost Integer of the amount of Mana spent by the Spell.
	 * @param gear The Stat object from which the Spell's scaling is derived.
	 * @param type AttemptType of any Attempt made by this Spell.
	 */
	Spell(String name, int manaCost, Stat stat, AttemptType type) {
		
		super(name, manaCost, stat, "Spell", type);
	}
	
	
	/**
	 * Constructor for instances of a Spell object.
	 * 
	 * @param name String of the Spell's name.
	 * @param addDoer Boolean determining if the name parameter is 
	 * to be used to find and add an ActionDoer to the new Spell.
	 * @param manaCost Integer of the amount of Mana spent by the Spell.
	 * @param gear The Stat object from which the Spell's scaling is derived.
	 * @param type AttemptType of any Attempt made by this Spell.
	 */
	Spell(String name, boolean addDoer, int manaCost, Stat stat, AttemptType type) {
		
		super(name, addDoer, manaCost, stat, "Spell", type);
	}
	
	
	/**
	 * Returns the user of the Stat object
	 * associated with this Skill. Overrides
	 * the superclass method to return a
	 * casted Caster object. 
	 */
	public Caster getUser() {
		
		return ((Caster)(getStat().getUser()));
	}
	
	/**
	 * Shortcut method that retrieves
	 * the user's ManaGauge.
	 * 
	 * @return ManaGauge as per the 
	 * method required by Casters.
	 */
	private ManaGauge getMana() {
		
		return getUser().mana();
	}


	/**
	 * Returns a String containing the Spell's 
	 * name and, AttemptType, and Mana cost. 
	 * 
	 * @return String containing name and usage
	 * information about this Spell.
	 */
	String menuMessage() {

		return (this.getName() + "\n" + 
		getAttemptType() + "\n" +
		getCost() + " Mana");

	}
	
	
	/**
	 * Indicates if this Spell can be used, based
	 * its learned parameter and available Mana
	 * in relation to its cost.	 
	 * 
	 * @return False if this Spell costs more mana than is 
	 * available. Otherwise, returns True.
	 */
	boolean isUsable() {
		
		return ((currentMana() >= getCost()));
	}
	
	
	/**
	 * Returns the value indicating
	 * the Caster's maximum Mana.
	 * 
	 * @return Integer maximum Mana.
	 */
	int getMaxMana() {
		
		return getMana().getMax();
	}
	
	
	
	/**
	 * Returns the integer value of the
	 * Hero's available Mana.
	 * 
	 * @return Integer of available Mana.
	 */
	int currentMana() {
		
		return getMana().getMana();
	}
	
	
	/**
	 * Attempts to spend this Spell's cost
	 * in Mana from the amount available to the 
	 * User. If not enough is available, returns
	 * False; otherwise, the cost is spent 
	 * and True is returned.
	 * 
	 * @param True if Mana was spent, False
	 * otherwise.
	 */
	public boolean cost() {
		
		return cost(getCost());
	}
	
	
	
	/**
	 * Attempts to spend an input amount
	 * of Mana from the amount available to the 
	 * User. If not enough is available, returns
	 * False; otherwise, the cost is spent 
	 * and True is returned.
	 * 
	 * @param True if Mana was spent, False
	 * otherwise.
	 */
	public boolean cost(int cost) {
		
		if (currentMana() < cost) {
			
			return false;
		} else {
			
			getMana().adjust(-cost);
			
			return true;
		}
	}
	
	
	/**
	 * Method used to provide String descriptions
	 * for exceptions thrown as a result of invalid
	 * Spells. Provides messages in the cases that 
	 * the Mana cost exceeds what is available,
	 * that it is unlearned, and a failsafe in case 
	 * this method gets called in any other 
	 * circumstance. 
	 * 
	 * @return String describing the reason the Spell
	 * is unusable.
	 */
	public String errorMessage() {
		
		if (currentMana() < getCost()) {
			
			return ("Insufficient Mana.");
		} else  {
			
			return (getName() + " is unusable for some reason...");
		}
	}

	public String learnMessage() {
		
		return ("[u] further stud[ies] " + getStat().getName() + 
				",\n and [ps] learn[s] how to cast " + getName() + ".\n");
	}
	
	public String failureString() {
		
		return ("[u] tr[ies] to cast " + getName());
	}
	
	
	/**
	 * Consolidates a Spell damaging an Entity target with 
	 * an integer damage value and spending 
	 * its Mana cost. Returns the amount of damage dealt.
	 * 
	 * @param damage Integer value of damage dealt to
	 * target's health.
	 * @param target Entity targeted by this Spell's effect.
	 */
	protected int quickUse(int damage, Entity target) {
	
		if (this.cost()) {
			
			return target.harm(damage);
		} else {
			
			throw new IllegalArgumentException(errorMessage());
		}
	}
	
	/**
	 * Consolidates a Spell damaging an Entity target with 
	 * its default scaling value and spending 
	 * its Mana cost. Returns the amount of damage dealt.
	 * 
	 * @param target Entity targeted by this Spell's effect.
	 */
	protected int quickUse(Entity target) {
		
		return quickUse(scale(), target);
	}
}