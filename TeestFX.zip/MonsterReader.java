package finalProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public abstract class MonsterReader {

	private static int level;
	private static String builder;
	private static int maxRank = 3;
	
	public static Monster make(int rank, int level, boolean promoted) {
		
		MonsterReader.level = level;
		MonsterReader.builder = "";

		rank = Math.min((Math.max(rank, 1)), MonsterReader.maxRank);
		
		String[] monsters = new File(
				"Monsters\\Tier" + rank).list();
			
		for (int m = 0; m < monsters.length; m++) {
			
			System.out.println(m + " " + monsters[m]);
		}
		
		String marker = monsters[new java.util.Random().nextInt(monsters.length - 1)];
		
		System.out.println(marker);
		
		try {
			
			FileInputStream input = new FileInputStream("Monsters\\Tier" + rank + "\\" + marker);
			//FileInputStream input = new FileInputStream("Monsters\\Tier" + rank + "\\" + marker);
			int length = input.available();
			
			for (int i = 0; i < length; i++) {
				
				builder += ((char)input.read());
			}
		} catch (IOException e) {

			e.printStackTrace();
		}
		
		/*if (promoted) {
			
			return promotedProtocol();
		} else {*/
		
			return buildFromString();
		//}
	}
	
	
	
	private static Monster promotedProtocol() {
		//the name of this method sounds like a modern Square Enix game lol
		String promoName = fromKey(builder, "PROMO:");
		
		if (promoName.equals("Multi")) {
			
			return MultiMonster.makeMulti(buildFromString());
		} else {
			
			String desc = "";
				
			try {
				
				FileInputStream input = new FileInputStream("SortedMonsters\\Promoted\\" + promoName);
				
				int length = input.available();
				
				for (int i = 0; i < length; i++) {
					
					desc += ((char)input.read());
				}
			} catch (IOException e) {

				e.printStackTrace();
			}
			
			builder = (desc + builder);
			
			return buildFromString();
		}
		
	}
		
	
	private static Monster buildFromString() {
		
		System.out.println(builder);
		//TODO: remove sysout after testing
		PronounSet pronouns; 
		String imageKey = fromKey(builder, "NAME:");
		
		switch (fromKey(builder, "GENDER:")) {
		
		case ("m"): {
			
			pronouns = PronounSet.malePronouns();
			break;
		}
		
		case ("f"): {
			
			pronouns = PronounSet.femalePronouns();
			break;
		}
		
		case ("e"): {
			
			pronouns = PronounSet.randomGenderPronouns();
			
			if (pronouns.objectPronoun().equals("her")) {
				//you have to do it this way because i didnt want to mess with hashcodes
				imageKey += "F";
			} else {}
			break;
		}
		
		case ("p"): {
			
			pronouns = PronounSet.pluralPronouns();
			break;
		}
		
		default: {
			
			pronouns = PronounSet.neutralPronouns();
		}
		}
		
		MonsterFlavor flavor = new MonsterFlavor();
		
		
		flavor.setStatusText(fromKey(builder, "FLAVOR:"));
		imageKey = ("Monsters/Images/" + imageKey + ".png");
		try {
			new FileInputStream(imageKey);
		} catch (FileNotFoundException e) {
			
			imageKey = null;
		}
		flavor.setImage(imageKey);
		
		Monster testMon;
		
		try {
			
			switch (fromKey(builder, "TYPE:")) {
			
			case ("Critter"): {
				
				flavor.setAttackVerb(fromKey(builder, "ATTACK:"));
				flavor.setSpecial(fromKey(builder, "SPECIAL:"));
				
				
				Critter output = new Critter(fromKey(builder, "NAME:"), flavor, level, fromKey(builder, "SIGNATURE:"));
				
				output.setPronouns(pronouns);
				
				testMon = output;
				
				break;
			}
			
			case ("MagiCritter"): {
				
				flavor.setAttackVerb(fromKey(builder, "ATTACK:"));
				flavor.setSpecial(fromKey(builder, "SPECIAL:"));
				
				MagiCritter output = new MagiCritter(fromKey(builder, "NAME:"), flavor, level, fromKey(builder, "SIGNATURE:"));
				
				output.setPronouns(pronouns);
				
				testMon = output;
				
				break;
			}
			
			case ("Skilled"): {
				
				SkilledMonster output = new SkilledMonster(fromKey(builder, "NAME:"), flavor, level, "dummyimp");
	
				String skillName = fromKey(builder, "ACTION:");
				output.setSkill(new Skill(skillName, true, 1, 
						(Stat)output.getAttackingStat(), AllActions.getType(skillName)));
				output.setPronouns(pronouns);
				
				testMon = output;
				break;
			}
			
			case ("Caster"): {
				
				Spellcaster output = new Spellcaster(fromKey(builder, "NAME:"), flavor, level);
				
				String spellName = fromKey(builder, "ACTION:");
				output.setMainSpell(new Spell(fromKey(builder, "ACTION:"), true, 2,
						(Stat)output.getAttackingStat(), AllActions.getType(spellName)));
				output.setPronouns(pronouns);
				
				testMon = output;		
				break;
			}
				
			default: {
				
				throw new IllegalArgumentException("too lazy");
			}
				
			}
		} catch (IllegalArgumentException ex) {
			
			System.out.print(ex.getLocalizedMessage());

			Critter output = new Critter(fromKey(builder, "NAME:"), flavor, level, "neutral");
			
			output.setPronouns(pronouns);
			
			testMon = output;
		}
		
		builder = "";
		System.out.println(testMon.getName());
		System.out.println(testMon.statusMessage());
		
		return testMon;
	}

	
	/**
	 * Retrieves a substring starting from
	 * a desired marker, and ending with two
	 * hashes. Neither the marker nor hashes
	 * are included in the output.
	 * 
	 * @param base String from which a potential
	 * substring is exracted.
	 * @param key String which will mark the 
	 * start of substring.
	 * @return String extracted according to 
	 * above rules.
	 */
	public static String fromKey(String base, String key) {
		
		try {
			
			int subStart = base.indexOf(key);
			
			return base.substring((subStart + key.length()), base.indexOf("##", subStart));
		} catch (IndexOutOfBoundsException ex) {
			
			return null;
		}
	}
}
