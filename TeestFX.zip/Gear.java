package finalProject;

/**
 * A abstract subclass of Stat representing more
 * tangible traits of a Fighter, namely
 * specific tools (or categories of tools)
 * at the Fighter's disposal.
 * 
 * @author Kayden Barlow
 */
abstract class Gear extends Stat {
	
	private GearPiece piece;
	private Gauge numPieces;
	
	/**
	 * Constructor for instances of the Gear
	 * class. Must be assigned to an 
	 * instance of the Fighter class.
	 * May be used to define instances of the
	 * Action class, with some potentially 
	 * requiring concrete subclasses of this 
	 * specific Stat subclass. Requires a String
	 * array of one or more "implements" which 
	 * the Gear object is meant to represent.
	 * 
	 * @param user Fighter to which the Gear
	 * is assigned.
	 * @param name String name.
	 * @param level Integer value of the Gear's
	 * relative power.
	 * @param numSkills	Integer equal to the number
	 * of Actions built from this Gear Stat.
	 * @param numPieces Integer equal to the number
	 * of Pieces (names of specific implements) that
	 * this Gear has.
	 */
	Gear(Entity user, String name, int level, int numSkills, int numPieces) {
		
		super(user, name, level, numSkills);
		this.numPieces = new Gauge(0, (numPieces - 1));
		this.piece = defaultPiece();
	}
	/*
	Gear(Entity user, String name, int level, int numSkills, String pieceName) {
		
		super(user, name, level, numSkills);
		this.pieces = getNamedPiece(pieceName);
	}*/

	
	/**
	 * Overrides the Stat implement method
	 * to instead return the name of the current
	 * Piece parameter.
	 */
	public String getImplement() {
		
		return piece.getName();
	}

	
	
	
	protected String upgrade() {
		
		String emptyLevel = ("[u] hone[s] [pf] further with [pp] " + getImplement() + ".\n");

		if ((getLevel() % 2) == 0) {
		
			try {
				
				if (upActions()) {
					
					addActions();
					
					return getUser().formatMessage(getAction(getCurrentActions()).learnMessage());
				} else {
					
					throw new IllegalArgumentException("shortcut");
				}
			} catch (IllegalArgumentException ex) {
				
				return emptyLevel;
			}
		} else {
			
			if (!numPieces.isFull()) {
				
				piece = upPiece();
				
				return ("[u] seek[s] out a new " + getName() + 
						",\n and procure[s] a " + getImplement() + ".\n");
			} else {
				
				return emptyLevel;
			}
		}
	}
	
	
	
	/**
	 * Returns a GearPiece as defined by
	 * subclass to change the implement name
	 * to something new. Returns a boolean value
	 * based on whether or not the a new Piece
	 * was made, which should always be false
	 * when a Gear has already reached its 
	 * maximum numPiece parameter value.
	 * 
	 * @return True if a new Piece was created,
	 * False otherwise.
	 */
	abstract protected GearPiece upPiece();
	
	
	/**
	 * Outputs a String containing the Gear's
	 * name parameter, its levelname method
	 * (which therefore includes its current item name),
	 * as well as the Gauge representing its current and max
	 * level parameter. The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the implement name and level data. 
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Gear's
	 * name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
			
			return (this.getImplement() + "\n(" + this.getName() + " " 
				+ this.getLevelString() + ")");
		
		} else {
			return (this.getImplement() + " (" + this.getName() + " " 
				+ this.getLevelString() + ")");
		}
	}
	
	//abstract protected String getUpItemString();
	
	//abstract protected GearPiece getNewPiece(String oldPieceName);
	
	/**
	 * Returns the GearPiece usually 
	 * assigned to this Gear on creation;
	 * can also be used as a safety method.
	 * 
	 * @return GearPiece assigned by default.
	 */
	abstract protected GearPiece defaultPiece();
	
	/**
	 * Inner class used to facilitate
	 * implements described by the 
	 * Gear. Has vestigial structure
	 * for the dummied Traits/Materials
	 * mechanic. Too lazy to remove that 
	 * stuff so
	 * 
	 */
	protected class GearPiece {
		
		String name;
		//icon/sprite parameter go here
		String mainTrait;
		String subTrait;
		String fromPiece;
		String toPiece;
		
	
		GearPiece(String name, String mainTrait, String subTrait, String toPiece, String fromPiece) {
			
			this.name = name;
			this.mainTrait = mainTrait;
			this.subTrait = subTrait;
			this.fromPiece = fromPiece;
			this.toPiece = toPiece;
		}
		
		GearPiece(String name, String mainTrait, String toPiece, String fromPiece) {
			
			this.name = name;
			this.mainTrait = mainTrait;
			this.subTrait = "None";
			this.fromPiece = fromPiece;
			this.toPiece = toPiece;
		}
		
		/**
		 * Returns the name of this
		 * GearPiece.
		 * 
		 * @return String name of this
		 * GearPiece.
		 */
		public String getName() {
			
			return name;
		}
		
		/*
		public String newPiece(GearPiece newPiece) {
		//THE NEW PIECE! THE NEW PIECE IS REAAAAAAAAL!!!
			String output = newPiece.fromPiece;
			output = output.replace("[tp]", toPiece);
			output = output.replace("[op]", name);
			output = output.replace("[np]", newPiece.name);
			return output;
		}*/
		

	}
}
