package finalProject;

import java.util.Random;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.Attacking;

/**
 * Monster subclass for those
 * foes that can't do much
 * besides run around and attack
 * wildly.
 * 
 * @author Kayden Barlow
 */
public class Critter extends Monster {

	private AttemptType signatureType;
	
	/**
	 * Constructor for new Critters.
	 * 
	 * @param name String name of the
	 * Critter.
	 * @param flavor MonsterFlavor 
	 * containing flavor Text for this 
	 * Critter.
	 * @param level Integer initial
	 * level parameter of this Critter.
	 * @param signatureType String name
	 * of an AttemptType
	 * which will be a Tiebreaker when
	 * made by this Critter.
	 */
	Critter(String name, MonsterFlavor flavor, int level, String signatureType) {
		
		this(name, flavor, level, Attempt.typeFromName(signatureType));
	}
	
	/**
	 * Constructor for new Critters.
	 * 
	 * @param name String name of the
	 * Critter.
	 * @param flavor MonsterFlavor 
	 * containing flavor Text for this 
	 * Critter.
	 * @param level Integer initial
	 * level parameter of this Critter.
	 * @param signatureType AttemptType
	 * which will be a Tiebreaker when
	 * made by this Critter.
	 */
	Critter(String name, MonsterFlavor flavor, int level, AttemptType signatureType) {
		
		super(name, flavor, level);
		
		this.signatureType = signatureType;
		
		setAttackingStat(subclassStat(""));
	}
	
	protected String subTypeStatusText() {
		
		return (getName() + "\nLevel " + getLevel() + " Critter");
	}
	
	protected int healthScale() {
		
		return Scaler.enemyHealth(getLevel());
	}
	
	protected boolean specialProcedure() {
		
		AttemptType type = Attempt.randomNonNeutral();
		
		if (type == getRustedType()) {
			
			if (critterSignatureType() != getRustedType()) {
				
				setAttemptPlan(critterSignatureType());
			} else {
				
				setAttemptPlan(Attempt.randomNonNeutral());
			}
		} else {
			
			setAttemptPlan(type);
		}
		
		return false;
	}


	boolean subAfflict(Affliction affliction) {
		
		return false;
	}

	/*
	protected Behavior getBehavior(String name) {
		
		return (m -> {
			
			AttemptType type = Attempt.typeFromId(new Random().nextInt(5));
			
			if (type == previousType()) {
				
				if (signatureType() != previousType()) {
					
					setAttemptPlan(signatureType());
				} else {
					
					setAttemptPlan(Attempt.typeFromId(new Random().nextInt(5)));
				}
			} else {
				
				setAttemptPlan(type);
			}
			
			return true;});
	}*/

	
	public String defaultSuccessStrings(AttemptType type) {
		
		String output = "";
		
		switch (type) {
		
		case QUICK: {
			
			output = "while [f], [u] [v] [t] in an instant.\n";
			break;
		}
		
		case WIDE: {
			
			output = "[u] read[ies] as [f], and then [v] [t].\n";
			break;
		}
		
		case TRICK: {
			
			output = "[f], but [u] come[s] from the side and [v] [to].\n"; 
			break;
		}
		
		case EVADE: {
			
			output = "as [f], [u] run[s] around to the side.\n";
			break;
		}
		
		case BLOCK: {
			
			output = ("[u] quickly back[s] off. [f], but [ps] is out of reach.\n");
			break;
		}
		
		default: {
			
			throw new IllegalArgumentException("Can't attack with Neutral.");
		}
		}
		
		return output.replace("[v]", getAttackVerb());
	}
	
	
	
	
	public String handleFailure(Entity target) {
		
		if (getCurrentType() == critterSignatureType()) {
			
			return formatMessage("[u] tr[ies] to " + getFlavor().getSpecial().replace("[s]", ""), target);
		} else {
			
			return formatMessage(getAttackingStat().failureMessage(getCurrentType()), target);
		}
	}

	
	public String defaultFailureStrings(AttemptType type) {

		if (type == critterSignatureType()) {
			
			return ("[u] tr[ies] to " + getFlavor().getSpecial()
					.replace("[s]", "").replace("[es]", "").replace("[ies]", "y"));
		} else {
			
			switch (type) {
		
			case EVADE: {
				
				return ("[u] tr[ies] to run around");
			}
			
			case BLOCK: {
				
				return ("[u] tr[ies] to back off");
			}
			
			default: {
				
				return ("[u] tr[ies] to " + (getAttackVerb().replace("[s]", "").replace("[es]", "")) + " [t]");
			}
				
			}
		}
	}
	
	/**
	 * Returns the "special" String
	 * assigned to this Critter's 
	 * MonsterFlavor.
	 * 
	 * @return
	 */
	protected String getCritterSpecial() {
		
		return getFlavor().getSpecial();
	}
	
	protected int defaultDamageScaling() {
		
		return Scaler.enemyDamage(getLevel());
	}


	protected Attacking subclassStat(String key) {

		return new CritterStat(this);
	}
	
	protected String defaultSubTypeImage() {
		
		return "Monsters\\DefaultImages\\CritterDefault.png";
	}


	protected AttemptType critterSignatureType() {
		
		return signatureType;
	}

	
	public boolean getBreaker() {

		return ((getType() == critterSignatureType()) && (!isRusted()));
	}
	
	
	public class CritterStat extends Stat implements Attacking {

		CritterStat(Critter user) {
			
			super(user, "Critter stat", Stat.getMaxLevel(), 0);
		}

		public String attackMessage(AttemptType attemptType) {
			
			if (attemptType == AttemptType.NEUTRAL) {
				
				throw new IllegalArgumentException("Cannot attack in Neutral.");
			} else if (attemptType == signatureType) {
				
				return ("[u] " + getCritterSpecial() + " as [f].");
			} else {
				
				return getUser().defaultSuccessStrings(attemptType);
			}
		}


		public String advantagedMessage(AttemptType attemptType) {

			return "critical Hit: " + attackMessage(attemptType).replace("[t]", "a weak spot");
		}



		public String failureMessage(AttemptType attemptType) {

			return getUser().defaultFailureStrings(attemptType);				
		}


		public AttemptType signatureType() {
			
			return critterSignatureType();
		}

	
		/**
		 * Unneeded, returns null
		 */
		public Action[] buildActions() {
			
			return null;
		}

		/**
		 * 
		 * Unneeded, returns null
		 */
		protected String upgrade() {
	
			return null;
		}
	}
}
