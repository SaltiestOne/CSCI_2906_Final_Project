package finalProject;

import finalProject.Attempt.AttemptType;

/**
 * Magic subclass for a school of Magic
 * based around the study of Magic itself.
 * Cannot inherently Attack, but provides
 * useful Spells and high Mana/Caster scaling.
 * 
 * @author Kayden Barlow
 */
public class Arcanism extends Magic {

	/**
	 * Constructor for new Arcanism Stats.
	 * Like all Magic subclasses, requires 
	 * a Caster user.
	 * 
	 * @param user Caster to which this
	 * Arcanism Stat will be assigned. 
	 * @param level Integer value of this
	 * Stat's initial relative power.
	 */
	Arcanism(Caster user, int level) {
		
		super(user, "Arcanism", level, 2);
	}
	
	
	
	public int manaScale() {
		
		return getLevel() * 4;
	}
	
	
	
	protected Spell[] buildActions() {
		
		Spell[] result = new Spell[getTotalActions()];
		
		int[] costs = {0, 5};
		
		String[] name = {"Ascend", "Drain"};
			
		DamageScaler[] scalers = {(e -> {return Scaler.damage(e.getUser().getLevel());}),
				(e -> {return Scaler.damage(e.getStat().getModdedLevel());}),
				(e -> {return Scaler.damage(e.getUser().getLevel());}),
				(e -> {return Scaler.damage((e.getStat().getLevel() + e.getStat().getLevel()), 
							e.getUser().getLevel());}),
				(e -> {return Scaler.damage(1, (int)(e.getStat().getLevel() * 2.5));})};
		
		
		for (int a = 0; a < result.length; a++) {
			
			result[a] = new Spell(name[a], true, costs[a], this, AttemptType.NEUTRAL);
			
			result[a].addDamageScaler(scalers[a]);
		}
		
		return result;
	}
	
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Caster's list of stats, this is intended
	 * to be used to quickly add a new, generic Arcanism
	 * Stat to the input Caster.
	 * 
	 * @param user Caster to receive a new instance
	 * of this object.
	 * @return String describing the aquisition of the 
	 * new Stat.
	 */
	public static String add(Caster user) {
		
		return user.formatMessage("[u] learn[s] the basics of " + 
				new Arcanism(user, 0).getName() + ".\n");
	}

}
