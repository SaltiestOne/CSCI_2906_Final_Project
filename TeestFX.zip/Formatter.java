package finalProject;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 * Abstract class used to store commonly used
 * formatting objects. These can be called upon
 * by other objects to ensure consistency in style.
 * Currently, stores three color objects as 
 * parameters, a String parameter representing
 * the name of a Font object, and default Font size. 
 * 
 * @author Kayden Barlow
 */
abstract public class Formatter {
	
	private static String font;
	private static double size;
	private static Color mainColor;
	private static Color warnColor;
	private static Color fadeColor;
	

	/**
	 * Captitalizes the first lowercase character
	 * in an input String.
	 * 
	 * @param string String to be capitalized.
	 * @return String but capitalized.
	 */
	public static String capitalize(String string) {
		
		if (string.length() <= 1) {
			
			return string.toUpperCase();
		} else {
			
			for (int c = 0; c < string.length(); c++) {
				
				char check = string.charAt(c);
				if ((check >= 65) && (check <= 90)) {
					//i.e., the first letter in the String is already capital
					return string;
				} else if ((check >= 97) && (check <= 122)) {
					
					return string.substring(0, c) + 
							string.substring(c, c + 1).toUpperCase() +
							string.substring(c + 1);
				} else {}
			}
			
			return string;
			//in case there weren't any letters in the String
		}
	}
	
	/**
	 * Returns a String formatted according
	 * to plural tense rules. Input String should
	 * have the placeholder "[ns]" in front of 
	 * the noun(s) whose quantity is equal to the input
	 * integer, the placeholder "[vs]" in front
	 * of any verb(s) done by said noun(s), and "[num]" in
	 * any places that the input integer should be inserted.
	 * If the input integer is equal to one, the noun(s) will not be
	 * plural, and the verb(s) will be conjugated with
	 * and "s". (As a side effect, this method WILL NOT properly 
	 * pluralize nouns with irregular plurals.) Other wise, 
	 * the noun(s) will be pluralized with an "s", and the verb(s) 
	 * will remained unconjugated. In either case, the input 
	 * integer will be replace any "[num]" placeholders as a 
	 * convenience.
	 * 
	 * @param string String to be formatted (see above for
	 * proper placeholders).
	 * @param number Integer quantity of certain noun(s) in
	 * the String.
	 * @return String formatted according to English plural
	 * rules.
	 */
	public static String pluralTense(String string, int number) {
		
		string = string.replace("[num]", Integer.toString(number));
		
		if (number == 1) {
			
			return ((string.replace("[ns]", "")).replace("[vs]", "s"));
		} else {
			
			return ((string.replace("[ns]", "s")).replace("[vs]", ""));
		}
	}
	
	
	/**
	 * A safety/convenience method used to ensure 
	 * that a null String is not output. If the first 
	 * parameter is null, the "default" second 
	 * parameter is used instead. The second parameter
	 * should always be set to a fixed String 
	 * per method, and not a variable or call,
	 * to prevent a "double-null".
	 * 
	 * @param override String that would be 
	 * preferred to be output, but which cannot
	 * be garanteed to exist.
	 * @param def String to be output if the 
	 * first parameter is null.
	 * @return String according to parameters.
	 */
	public static String defaultString(String override, String def) {
		
		if (override == null) {
			
			return def;
		} else {
			
			return override;
		}
	}
	
	
	
	/**
	 * Sets the static value of the "main"
	 * Color parameter.
	 * 
	 * @param mainColor Color to be used for
	 * most nodes.
	 */
	static void setMainColor(Color mainColor) {
		
		Formatter.mainColor = mainColor;
	}
	
	
	/**
	 * Returns the static value of the "main"
	 * Color parameter.
	 * 
	 * @return Color object to be used for most
	 * nodes.
	 */
	static Color getMainColor() {
		
		return Formatter.mainColor;
	}
	
	
	/**
	 * Sets the static value of the "warning"
	 * Color parameter.
	 * 
	 * @param warnColor Color to be used for
	 * nodes inidicating a warning or submaximal value.
	 */
	static void setWarnColor(Color warnColor) {
		
		Formatter.warnColor = warnColor;
	}
	
	
	/**
	 * Returns the static value of the "warning"
	 * Color parameter.
	 * 
	 * @return Color object to be used for
	 * nodes inidicating a warning or submaximal value.
	 */
	static Color getWarnColor() {
		
		return Formatter.warnColor;
	}
	
	
	/**
	 * Sets the static value of the "fade"
	 * Color parameter.
	 * 
	 * @param fadeColor Color to be used for
	 * unavailable nodes or empty information.
	 */
	static void setFadeColor(Color fadeColor) {
		
		Formatter.fadeColor = fadeColor;
	}
	
	
	/**
	 * Returns the static value of the "fade"
	 * Color parameter.
	 * 
	 * @return Color object to be used for
	 * unavailable nodes or empty information.
	 */
	static Color getFadeColor() {
		
		return Formatter.fadeColor;
	}
	
	
	/**
	 * Sets the static name corresponding
	 * to a Font object to be used by formatted
	 * nodes.
	 * 
	 * @param font Name of static Font.
	 */
	static void setFont(String font) {
		
		Formatter.font = font;
	}
	
	
	/**
	 * Sets the default font size for
	 * the Font retrieved by this class.
	 * 
	 * @param size Double value of the
	 * default Font size.
	 */
	static void setSize(double size) {
		
		Formatter.size = size;
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with a size determined by the input double.
	 * 
	 * @param size Double of the Font's size.
	 * @return Font statically set to this class.
	 */
	static Font getFont(double size) {

		return (Font.font((Formatter.font),size));
	}
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the default size also determined
	 * statically by this class.
	 * 
	 * @return Font statically set to this class.
	 */
	static Font getFont() {
		
		return getFont(Formatter.size);
	}
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the BOLD FontWeight and a size 
	 * determined by the input double.
	 * 
	 * @param size Double of the Font's size.
	 * @return Font statically set to this class.
	 */
	static Font getBoldFont(double size) {
		
		return (Font.font((Formatter.font), FontWeight.BOLD, size));
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the BOLD FontWeight and the default 
	 * size determined statically by this class.
	 * 
	 * @return Font statically set to this class.
	 */
	static Font getBoldFont() {
		
		return getBoldFont(Formatter.size);
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the ITALIC FontPosture and a size 
	 * determined by the input double.
	 * 
	 * @param size Double of the Font's size.
	 * @return Font statically set to this class.
	 */
	static Font getItalicFont(double size) {
		
		return (Font.font((Formatter.font), FontPosture.ITALIC, size));
	}
	
	
	/**
	 * Returns the Font object corresponding to
	 * the static String name set to this class,
	 * with the ITALIC FontPosture and the default 
	 * size determined statically by this class.
	 * 
	 * @return Font statically set to this class.
	 */
	static Font getItalicFont() {
		
		return getItalicFont(Formatter.size);
	}
	
}
