package finalProject;

/**
 * Class containing the various
 * Strings needed to properly 
 * "bring a Monster to life," as
 * it were.  
 * 
 * @author Kayden Barlow
 */
public class MonsterFlavor {

	private String[] flavors = new String[5];
	
	/**
	 * Constructs a new instance of
	 * MonsterFlavor. 
	 */
	MonsterFlavor() {}
	
	/**
	 * Sets a String to be called for
	 * when outputing status text.
	 * Should be about two lines in length,
	 * but is not required to be. 
	 * 
	 * @param flavor String to be used as 
	 * the "status message" flavor text.
	 */
	public void setStatusText(String flavor) {
		
		flavors[3] = flavor;
	}
	
	
	/**
	 * Returns the String set to be the flavor
	 * text status message. Defaults to a 
	 * different message if none has been set.
	 * 
	 * @return String status text.
	 */
	public String getStatusText() {
		
		return Formatter.defaultString((flavors[3]), 
				("You don't know what this is.\nNeither does Kayden."));
	}
	
	
	/**
	 * Sets the word to be used
	 * when describing the Monster's
	 * basic attack. Should be a verb
	 * fitting the syntax "x [String] y,"
	 * including conjugation.
	 * 
	 * @param verb String of the word(s)
	 * describing an attack.
	 */
	public void setAttackVerb(String verb) {
		
		flavors[1] = verb;
	}
	
	/**
	 * Returns the word describing a 
	 * basic attack. Defaults to a simple
	 * "attacks" if no attack verb has
	 * been set.
	 * 
	 * @return String describing an 
	 * attack.
	 */
	public String getAttackVerb() {
		
		return Formatter.defaultString(flavors[1], "attack[s]");
	}
	
	/**
	 * Sets the "special" word. The usage 
	 * (and part of speech) may vary with
	 * subclass.
	 * 
	 * @param special String used in
	 * describing the Monster's special
	 * attack.
	 */
	public void setSpecial(String special) {
		
		flavors[2] = special;
	}
	
	/**
	 * Returns the String used in
	 * describing the Monster's special
	 * attack. Defaults to the attack 
	 * verb if none has been set.
	 * 
	 * @return String used in
	 * describing the Monster's special
	 * attack.
	 */
	public String getSpecial() {
		
		return Formatter.defaultString(flavors[2], getAttackVerb());
	}
	
	/**
	 * Sets the name of the 
	 * location of a File
	 * used to display an
	 * image of the Monster.
	 * 
	 * @param location String
	 * name of a valid File-
	 * making image.
	 */
	public void setImage(String location) {
		
		flavors[4] = location;
	}
	
	/**
	 * Returns the name of the
	 * location of a File used
	 * to display an image of the
	 * Monster.
	 * 
	 * @return String
	 * name of a valid File-making 
	 * image.
	 */
	public String getImage() {
		
		return flavors[4];
	}
	 
}
