package finalProject;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import finalProject.Stat.Attacking;


/**
 * Subclass of Fighter representing the enemies that the
 * Hero will fight. Requires a String array for its constructor,
 * which includes its name, attack verbs, and a flavorful decription.
 * (How "monstrous" some of these enemies are will be left for the 
 * reader's ideology to determine). The Gauge class is required, as
 * with all Fighter subclasses, as is the Scaler class.
 * 
 * @author Kayden Barlow
 */
abstract class Monster extends Fighter {
	
	private MonsterFlavor flavor;
	private int damage;
	protected boolean stunned = false;
	private boolean special = false;
	//private Behavior behavior;
	private BasicAttack basicAttack;
	private Attacking stat;

	
	/**
	 * Constructor for instances of the Monster
	 * class. This includes a String for 
	 * the name and flavor text of the Monster, 
	 * as well it's level and initial health.
	 * 
	 * @param name String of the Monster's name.
	 * @param flavor String with the Monster's flavor
	 * text.
	 * @param level Integer value of the 
	 * Monster's relative power.
	 * @param maxHealth Integer value of the 
	 * Monster's maximum health points.
	 *
	Monster(String name, String flavor, int level, int maxHealth) {
		
		
		super(name, level, maxHealth);
		
		this.flavor = new MonsterFlavor();
		
		this.flavor.setStatusText(flavor);
		
		addStat(new MonsterStat(this));
		
		setBasic();
		
		setPronouns(PronounSet.neutralPronouns());
		
		prepare();
	}*/
	
	
	/**
	 * Constructor for instances of the Monster
	 * class. This includes a String for 
	 * the name and flavor text of the Monster, 
	 * as well it's level and initial health.
	 * 
	 * @param name String of the Monster's name.
	 * @param flavor MonsterFlavor containing
	 * the Monster's String information.
	 * @param level Integer value of the 
	 * Monster's relative power.
	 * @param maxHealth Integer value of the 
	 * Monster's maximum health points.
	 */
	Monster(String name, MonsterFlavor flavor, int level) {
		
		super(name, level, 1);
		
		this.flavor = flavor;
		
		setMaxHealth(healthScale(), true);

		setBasic();
		
		setPronouns(PronounSet.neutralPronouns());
	}
	
	
	/**
	 * Returns the MonsterFlavor object
	 * assigned to this Monster. 
	 * 
	 * @return MonsterFlavor assigned to
	 * this Monster.
	 */
	protected MonsterFlavor getFlavor() {
		
		return flavor;
	}
	
	
	/**
	 * Returns a String containing the
	 * Monster's name, level, and flavor
	 * text.
	 * 
	 * @return String containing end-user
	 * information about the Monster.
	 */
	public String statusMessage() {
		
		return formatMessage(subTypeStatusText() + "\n" + flavor.getStatusText());
	}
	
	

	
	
	/**
	 * Outputs the verb used in the Monster's
	 * basic attack.
	 * 
	 * @return String of the verb used to
	 * describe a basic attack.
	 */
	public String getAttackVerb() {
		
		return flavor.getAttackVerb();
	}
	
	
	
	/**
	 * Returns the word used for the Monster's
	 * "special", whose usage and tense may
	 * vary in subclass. 
	 * 
	 * @return String of the "special" word.
	 */
	protected String getSpecialWord() {
		
		return flavor.getSpecial();
	}
	
	
	/**
	 * Indicates if the Monster is set
	 * to try their special attack this 
	 * turn.
	 * 
	 * @return Boolean equal to the 
	 * Special parameter.
	 */
	protected boolean isOnSpecial() {
		
		return special;
	}
	
	/**
	 * Indicates if the Monster is
	 * unable to act.
	 * 
	 * @return Boolean equal to the 
	 * Stunned parameter.
	 */
	protected boolean isStunned() {
		
		return stunned;
	}
	
	
	/**
	 * Returns the current Damage value
	 * for this Monster.
	 * 
	 * @return Integer damage parameter.
	 */
	int getDamage() {
		
		return this.damage;
	}
	
	/**
	 * Returns an integer value for the
	 * Monster's initial maximum health,
	 * as determined by its subclass.
	 * 
	 * @return Integer value of initial
	 * maximum health.
	 */
	abstract protected int healthScale();
	
	/**
	 * Constructs and sets the BasicAttack
	 * used for the eponymous parameter.  
	 */
	protected void setBasic() {
		
		//basicAttack = new BasicAttack((Attacking)getStat("MonsterStat"));
		
		//basicAttack.addDamageScaler(e -> {return getDamage();});
	}

	
	/**
	 * Sets the user's special parameter to
	 * the input boolean. Returns the 
	 * Boolean state that was set.
	 * 
	 * @param special Boolean used to set 
	 * the special parameter.
	 * @return True if special was set 
	 * True, False otherwise.
	 */
	protected boolean setSpecial(boolean special) {
		
		this.special = special;
		return this.special;
	}
	
	
	/**
	 * Determines if the Monster will
	 * attempt their special attack this
	 * turn. Returns the result of this
	 * operation.
	 * 
	 * @return True if special was set to
	 * True, False if not.
	 */
	abstract protected boolean specialProcedure();
	
	
	/**
	 * Sets the integer damage parameter to an int value 
	 * to a random number scaling based on the monster's level. 
	 * This number has a floor of one, and a ceiling 
	 * which scales faster than the player's normal damage
	 * number should. This is to create a more "random"
	 * damage amount for enemies. This method also randomly 
	 * determines if the monster currently has its special
	 * parameter set to True, with the percentage chance equaling
	 * eight plus twice its level.
	 * 
	 */
	public void endTurn() {
		
		this.stunned = false;
		
		setDamage(Scaler.enemyDamage(getLevel()));
		
		specialProcedure();
	}
	
	
	
	/**
	 * Sets the Monster's damage parameter to the
	 * input value. Damage cannot be negative.
	 * If it is set to zero, Monster is stunned,
	 * and damage is recalculated as if normal 
	 * (in case a special overrides the stun).
	 * 
	 * @param damage Integer value of the
	 * Monster's new damage parameter.
	 * @return True if the Monster was 
	 * stunned by this reduction, False 
	 * otherwise.
	 */
	protected boolean setDamage(int damage) {
		
		if (damage <= 0) {
			
			this.damage = Scaler.enemyDamage();
			
			this.stun();
			
			return true;
		} else {
		
			this.damage = damage;
		
			return false;
		}
	}
	
	/**
	 * Returns the integer "damage"
	 * parameter set by other methods.
	 * 
	 */
	protected int defaultDamageScaling() {
		
		return damage;
	}
	
	/**
	 * Since the base Monster class
	 * is not terribly complex, disabling
	 * one simply causes it to be stunned. 
	 */
	/*public String disable(int potency) {
		
		stun();
		
		return "stun";
	}*/
	
	
	/**
	 * Reduces the Monster's upcoming
	 * damage. Returns True if this
	 * caused a stun by reducing that
	 * value to below zero.
	 *
	public boolean weaken(int potency) {
		
		return setDamage(getDamage() - potency);
	}*/
	
	
	/**
	 * Indicates if the Monster has
	 * been stunned by some process
	 * or another.
	 * 
	 * @return True if the Monster is
	 * stunned, False otherwise.
	 */
	public boolean isDisabled() {
		
		return stunned;
	}
	
	
	/**
	 * Causes the monster to be stunned, negating one
	 * turn: either the monster will be unable to take
	 * its next normal attack, or it will "downgrade" a 
	 * special hit to a normal attack.
	 */
	public void stun() {
		
		this.stunned = true;
	}
	
	/**
	 * Returns a message explaining
	 * that the Monster cannot
	 * harm its target this turn.
	 * 
	 * @return String describing the
	 * lack of a proper Action this 
	 * turn.
	 */
	protected String stunnedMessage(Entity target) {
		
		return formatMessage("[u] cannot harm " +
				target.getPerspectiveName() + "...\n\n");
	}
	
	
	public boolean afflict(Affliction affliction) {
		
		if (subAfflict(affliction)) {
			
			return true;
		} else {
		
			switch (affliction.name) {
			
			case ("stun"): {
				
				stun();
				return true;
			}
			
			case ("weaken"): {
				
				setDamage(getDamage() - affliction.potency);
				return true;
			}
			
			default: {
				
				return false;
			}
			}
		}
	}
	
	
	abstract boolean subAfflict(Affliction affliction);
	
	/**
	 * Performs the Monster's BasicAttack
	 * and returns a String describing the
	 * results. 
	 * 
	 * @return String describing the effects
	 * of the BasicAttack.
	 */
	public String doBasic(Entity target) {
		
		return basicAttack.doAction(target, hasAdvantage(target));
	}
	
	
	/**
	 * DUMMIED, KEPT FOR SAFETY FOR NOW
	 * Facilitates the effects of the monster's action
	 * and outputs a message indicating such. Note that 
	 * the stunned and special parameters are not reset 
	 * by this method, on the assumption that they will 
	 * be prepared before the next invocation of this method.
	 * 
	 * @param target Fighter targeted by the Monster.
	 * @return String of the message describing the 
	 * Monster's action.
	 */
	public String action(Entity target) {
		
		if (stunned && (!special)) {
		
			return stunnedMessage(target);	
		} else if (special && (!stunned)) {

			return formatMessage("Critical hit: [u] " + flavor.getSpecial() +
					" " + target.getPerspectiveName() + 
					".\n " + target.damageMessage(target.harm(2 * damage)));
		} else {
			//applies if neither stunned nor special, OR if both are true; special "overrides" stun.
			return doBasic(target);
		}
	}
	
	/**
	 * Returns a status message which
	 * may vary among subclasses. Most
	 * will incorporate the Monster's 
	 * name, level, subtype, and its
	 * MonsterFlavor's flavor text.
	 * 
	 * @return String describing this
	 * Monster.
	 */
	protected abstract String subTypeStatusText();
	
	/**
	 * Outputs a String containing a 
	 * URL or resource path to an 
	 * image File displaying this 
	 * Monster.
	 * 
	 * @return String path to an
	 * image.
	 */
	public String getImagePath() {

		return Formatter.defaultString(flavor.getImage(),  defaultSubTypeImage());
	}
	
	
	/**
	 * Returns the String URL or resource
	 * path to an image File sought in the 
	 * event that the Monster's 
	 * MonsterFlavor cannot find or has not
	 * been assigned one.
	 * 
	 * @return String name of a location of 
	 * a valid Image-creating File.
	 */
	protected abstract String defaultSubTypeImage();
	
	/**
	 * Assigns the input Attacking Stat
	 * to the eponymous parameter which
	 * is used to make basic Attempts.
	 * 
	 * @param attackingStat Attacking Stat
	 * that this Monster will use.
	 */
	protected void setAttackingStat(Attacking attackingStat) {
		
		stat = attackingStat;
	}
	
	/**
	 * Returns the Attacking Stat used by
	 * this Monster to make basic Attempts.
	 */
	public Attacking getAttackingStat() {
		
		return stat;
	}
	
	/*
	 * Dummied interface designed to facilitate
	 * different enemy behaviors, didn't have time
	 * to implement
	 *
	protected interface Behavior {

		boolean act(Monster actor);
	}
	
	public void setBehavior(String name) {
		
		behavior = getBehavior(name);
	}

	abstract protected Behavior getBehavior(String name); /* {
		
		switch (name) {
			
		default: {
			
			return (m -> {
				
				if ((new Random().nextInt(100)) < (8 + (2 * m.getLevel()))) {
					
					return true;
				} else {
					
					return false;
				}
			});
		}
		} 
	}*/
	
	/*
	static String defaultString(String override, String def) {
		
		if (override == null) {
			
			return def;
		} else {
			
			return override;
		}
	}*/


	/**
	 * Action-adding method required by
	 * superclass. Currently unneeded
	 * and unused. 
	 */
	//public boolean addAction(Action action) {
		
	//	return false;
	//}


	/**
	 * Action-finding method required by
	 * superclass. Currently unneeded and
	 * unused.
	 */
	//public Action getAction(String actionName) {

	//	return null;
//	}


	/**
	 * Action-finding method required by
	 * superclass. Currently unneeded and
	 * unused.
	 */
	//public Action getAction(Action action) {

	//	return null;
	//}
	
	
	/**
	 * Returns an Attacking Stat
	 * to be used by this Monster.
	 * Procedures (and the necessity
	 * of the "key" parameter) will
	 * vary by subclass.
	 * 
	 * @param key String name of desired
	 * Stat, if subclass procedures require
	 * it.
	 * @return Attacking Stat to be used
	 * by this Monster.
	 */
	protected abstract Attacking subclassStat(String key);
	
	//protected abstract MonsterStat subclassStat();
	
	/**
	 * Stat subclass used exclusively
	 * by Monsters, primarily to construct
	 * their BasicAttack. Is not used for 
	 * any scaling in current implementation. 
	 *
	public abstract class MonsterStat extends Stat implements Attacking {

		/**
		 * Constructs a new instance of
		 * MonsterStat. As other parameters
		 * are fixed, the only input needed
		 * is the reference of the Monster
		 * using this Stat.
		 * 
		 * @param user Monster object to 
		 * which this MonsterStat is 
		 * assigned.
		 *
		MonsterStat(Monster user, String name) {
			
			super(user, name, Stat.getMaxLevel(), 1);
		}

		
		/**
		 * Returns the Monster's "special" attack
		 * String. This is intended to allow 
		 * Action-using Monster subclasses to 
		 * have their Action texts use this String
		 * for their "implement." 
		 */
		//public String getImplement() {
			
		//	return ((Monster)getUser()).getSpecialWord();
		//}

	


		/**
		 * Returns zero, as this Stat
		 * does not compete with any
		 * others when setting up a 
		 * BasicAttack within the 
		 * current processes of the 
		 * Monster classes. 
		 *
		public int attackPriority() {
			
			return 0;
		}



		public String attackMessage() {
			
			return ("[u] " + ((Monster)getUser()).getAttackVerb() + " [t].\n");
		}


		public BasicAttack getBasicAttack() {

			return new BasicAttack(this);
		}

		/**
		 * Required by superclass but
		 * currently unused, as no 
		 * Monster should have any
		 * procedure to upgrade their
		 * Stat mid-fight (not to 
		 * mention the fact that this
		 * Stat is always constructed
		 * at max level). 
		 *
		protected String upgrade() {

			return null;
		}
	}*/
}