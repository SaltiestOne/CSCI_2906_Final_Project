package finalProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import finalProject.Attempt.AttemptType;

public class MonsterWriter {

	public static void main(String[] args) throws FileNotFoundException {
		
		String[][] monsters = {
			{"Rat", "i", "bite[s]", "scurr[ies] around [t]", "Critter", "evade",
				"Not even a big one. It's, like, a foot from nose to tail.",
				"It's only trouble because it's so hard to hit."}, 
			{"Tree Snake", "i", "bite[s] [t]", "lunge[s] at [t]", "Critter", "quick",
				"Mostly eats small animals. Lays on treetops for warmth.",
				"Attacks in self-defense if knocked off the branches."}, 
			{"Half-Skeleton", "i", "tackle[s]", "strangle[s] [t]", "Critter", "trick",
				"Shambles around missing an arm, its feet, and some ribs.",
				"Crawls on 'all threes' and throws itself at threats."},
			{"Lone Wolf", "i", "bite[s]", "leap[s] back", "Critter", "block",
				"Usually, the lone wolves are that way for a reason.",
				"This one MIGHT just be misunderstood. But I doubt it."},
			{"Wolfrat", "i", "bite[s]", "gouge[s] [t]", "Critter", "quick",
				"Despite the name, they're a carnivorous cousin of rabbits.",
				"But a layman could assume them to be wolf-rat hybrids."},
			{"Baby Chimera", "i", "ram[s] into", "pin[s] [t]", "Critter", "trick",
				"Chimeras born in the wild start off relatively weak.",
				"Coordinating all their different parts takes practice."},
			{"Poacher", "e", "shoot[s] at", "man-catcher", "Skilled", "Lunge",
				"\"Poacher\" is used here euphamistically.",
				"Illegal hunting is a lesser crime than others."},
			{"Dozentalon", "i", "slash[es]", "pounce[s] on [t]", "Critter", "evade",
				"Bird of prey with large wings and two pairs of clawed limbs.",
				"A famous poem asks, 'Be a dragon, or a gryphon, that bird?'"},
			{"Ice-Mote", "i", "chill[s]", "ice", "MagiCritter", "Drain",
				"Is it an Air or Water Elemental? Both? Neither?",
				"Many arcanologists have lost friendships over this debate."},
			{"Amalgnomes", "p", "punch[es]", "reinforced shell", "Skilled", "Counter",
				"A number of gnomes operating a humanoid construct.",
				"Which of its body parts are \"piloted\" may vary."},
			{"Bandette", "f", "chop[s]", "axe", "Skilled", "Eviscerate",
				"Has many cheap romance novels hidden under her loot stash.",
				"A hostage nobleman falls for his captor in most of them."},
			{"Green Slime", "i", "splash[es]", "corrode[s] [t]", "Critter", "trick",
				"Orcs love these, and eat them raw like in the stories.",
				"Half-orcs hate these, because of stereotypes."},
			{"Catalin Daerg", "i", "stab[s]", "arms", "Skilled", "Lunge",
				"This fae warrior appears as a green knight with spears for arms.",
				"Having no mouth, it's easily the most trustworthy type of fairy."},
			{"Swordist", "e", "counter[s]", "shield", "Skilled", "Shield Bash",
				"A catch-all term for proficient users of a sword and shield.",
				"A mercenary, bandit, guard... whichever happens to be fighting you."},
			{"Alchemist", "e", "", "Elementalism", "Caster", "Ascend",
				"One who studies the arcane and mundane rules of the universe.",
				"Many of them find it reductionist to be called a \"mage.\""},
			/*{"Paladin", "e", "shield-bash[es]", "shield", "Caster", "Astra",
				"One who uses a shield and magic to defend... something.",
				"Sanctioned holy warriors are called this only as an insult."},*/
			{"Sharpstaff", "e", "strike[s]", "spear", "Caster", "Mana Burst(Sp)",
				"Student of both martial and arcane arts, out to prove something.",
				"[pp] eponymous staff-polearm hybrid can channel various spells."},
			{"Refuse Golem", "i", "toss[es]", "lay[s] [t] to waste", "Critter", "wide",
				"One can really get their mana's worth out of one of these.",
				"They're not only cheaper than other golems, but scarier too."},
			{"Earth Angel", "i", "dust[s]", "bur[ies]", "MagiCritter", "wide",
				"A lizard that hosts special Earth Elementals on its skin.",
				"These envelop the creature in a mass of soil, sand, or clay."},
			{"Haunted Blade", "p", "slash[es] at", "own body", "Caster", "Mana Burst(Sp)", 
				"A worn, discarded sword possessed by a resentful spirit.",
				"Perhaps they, too, felt like an unwanted weapon."},
			{"Edge-Lord", "m", "cut[s]", "razor", "Skilled", "Eviscerate",
				"Some are mockingly called \"Lords\" of the \"Edge\" of society.",
				"Most are people who traded their morals for power of some kind."},
			{"Blue Wyvern", "i", "snatch[es]", "take[s] off", "Critter", "evade",
				"This subspecies's breath \"weapon\" isn't harmful; it regulates heat.",
				"This lets it survive in more enviornments than any of its cousins."},
			{"Megatherium", "i", "slash[es]", "crush[es] [t]", "Critter", "block",
				"A giant sloth.", "Aren't you scared?"},
			/*{"[multiple swordists]", "engage", "surround",
				"A group of swordists trained to coordinate in combat.",
				"Members typically use different, complimenting styles."},*/
			/*{"Gungnir", "e", "Mana-Burst[s]", "sharpstaff", "Caster", "Astra", 
				"A title given to those who harmonize their bodies with the arcane.",
				"Many adopt the use of a hybrid staff-spear in combat."},*/
			{"False Phoenix", "p", "singe[s]", "ashes", "MagiCritter", "Bolt",
				"A bird that creates fire to assist with flight, hunting, and defense.",
				"Known by other names in places without a concept of a \"phoenix.\""},
			/*{"Wheelchair Drake", "m", "roll[s] into", "yuhs [t]", "Critter", "trick",
				"Congrats. You're clearly strong enough and lucky enough.",
				"You've earned the right to fight the token joke enemy."},*/
			/*{"Hero's Shadow", "p", "mimic[s]", "nullif[ies]", "Critter", "quick",
				"None can deafeat their own shadow, only hold it back.",
				"And sometimes, it becomes more well-known than its original."}*/};

		String names = "";
		for (int m = 0; m < monsters.length; m++) {
			
			String[] current = monsters[m];
			int tier = ((m + 7)/ 6);
			/*FileOutputStream output = 
					new FileOutputStream(("SortedMonsters\\Tier" + tier + "\\" + current[0] + ".txt"));*/
			FileOutputStream output = 
					new FileOutputStream(("Monsters\\Tier" + tier + "\\" + current[0] + ".dat"));
			String info = ("NAME:" + current[0] + 
					"##TYPE:" + current[4] + "##GENDER:" + current[1] + 
					"##FLAVOR:" + current[6] + "\n" + current[7] + "##");
			
			
			
			switch (current[4]) {
			
			case ("Critter"): {
				
				info += ("ATTACK:" + current[2] + 
						"##SPECIAL:" + current[3] + 
						"##SIGNATURE:" + current[5] + "##");
				break;
			}
			
			case ("Skilled"): {
				
				//does the same thing as Caster
			}
			
			case ("Caster"): {
				
				info += ("IMPLEMENT:" + current[3] + "##ACTION:" + current[5] + "##");
				break;
			}
			
			case ("MagiCritter"): {
				
				info += ("ACTION:" + current[5] + "##");
				break;
			}
			}
			
			try {
				
				output.write(info.getBytes());
				names += ((current[0] + " (" + current[4] + ") \tsuper: \n"));
			
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
			try {
				
				new FileInputStream("Monsters\\Images\\" + current[0] + ".png").available();
			} catch (IOException ex) {
				
				System.out.println(current[0] + " does not have a valid image.");
			}

		}
		
		FileOutputStream output = new FileOutputStream("SortedMonsters\\allnames2.txt");
		try {
			output.write(names.getBytes());
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		//TODO: hey don't forget to actually write the implement text to file
		buildImplements();
			
	}

	
	public static void buildImplements() {
		
		Sword sampleSword = new Sword(new Hero(1), 1);
		Shield sampleShield = new Shield(new Hero(1), 1);
		Spear sampleSpear = new Spear(new Hero(1), 1);
		
		String[] names = {"Sword"};
		//I am meddling with forces beyond my control
		String[][][] implementStrings = 
			{{{(sampleSword.attackMessage(AttemptType.QUICK).replace("Shortsword", "sword")), 
				(sampleSword.attackMessage(AttemptType.WIDE).replace("Shortsword", "sword")),
				(sampleSword.attackMessage(AttemptType.TRICK).replace("Shortsword", "sword")), 
				null, (sampleShield.successfulBlockString().replace("Buckler", "shield"))}, 
			{(sampleSword.advantagedMessage(AttemptType.QUICK).replace("Shortsword", "sword")), 
				(sampleSword.advantagedMessage(AttemptType.WIDE).replace("Shortsword", "sword")), 
				(sampleSword.advantagedMessage(AttemptType.TRICK).replace("Shortsword", "sword")),
				(sampleSword.advantagedMessage(AttemptType.EVADE).replace("Shortsword", "sword")), 
				(sampleSword.advantagedMessage(AttemptType.BLOCK).replace("Shortsword", "sword"))}, 
			{(sampleSword.failureMessage(AttemptType.QUICK).replace("Shortsword", "sword")), 
				(sampleSword.failureMessage(AttemptType.WIDE).replace("Shortsword", "sword")),
				(sampleSword.failureMessage(AttemptType.TRICK).replace("Shortsword", "sword")), 
				null, (sampleShield.failedBlockString().replace("Buckler", "shield"))}}};		
		
		try {

			for (int i = 0; i < implementStrings.length; i++) {
	
				new ObjectOutputStream(new FileOutputStream((
						"SortedMonsters\\Implements\\" + names[i] + ".dat")))
						.writeObject(implementStrings[i]);
			}	
			
		} catch (IOException e) {

			e.printStackTrace();
		}
		
		
		
		
	}
}
