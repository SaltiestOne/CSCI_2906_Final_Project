package finalProject;
import java.util.ArrayList;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.Attacking;
import javafx.scene.control.TabPane;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Tooltip;


import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Pane used to facilitate most of the 
 * stuff in Teest. I'll be honest, this
 * IS just the text-based Teest as a 
 * JavaFX object, more or less.
 * 
 * @author Kayden Barlow
 */
final public class ConsolePane extends Pane {

	private Text message = new Text("\n\tWelcome to Teest!");
	private Text shadow = new Text();
	private Text desc = new Text();
	private Hero hero;
	private Monster enemy;
	//private BattlePane bPane;
	private PentaPane penta;
	private FighterPane heroPane;
	private FighterPane enemyPane;
	private PhantomPane menu;
	private Timeline endTurn;
	private boolean fastmode = false;//TODO: implement fast mode/options
	private ArrayList<PaintableButton> paintableButtons = new ArrayList<PaintableButton>();
	
	
	/**
	 * Constructor for a new instance of 
	 * the ConsolePane class. As this is
	 * intended to be a self-contained
	 * facilitator for all functions of
	 * TeestFX, it defines all parameters
	 * for itself and thus has no inputs. 
	 */
	ConsolePane() {
		
		super();
		
		this.hero = new Hero(1);
		
		this.enemy = new Critter("dud", new MonsterFlavor(), 1, AttemptType.NEUTRAL);
		
		this.heroPane = new FighterPane(hero);
		heroPane.setLayoutX(550);
		heroPane.setLayoutY(20);
		
		this.enemyPane = new FighterPane(enemy);
		enemyPane.setLayoutX(10);
		enemyPane.setLayoutY(20);

		message.setFont(Formatter.getFont(19));
		message.setFill(Formatter.getMainColor());

		message.setWrappingWidth(600);
		
		
		this.desc = new Text();
		desc.setY(420);
		desc.setX(21);
		desc.setFont(Formatter.getFont(16));
		desc.setFill(Formatter.getMainColor());
		
		message.setX(14);
		message.setY(600);
		shadow.xProperty().bind(message.xProperty().add(1));
		shadow.yProperty().bind(message.yProperty().add(1));
		shadow.textProperty().bind(message.textProperty());
		shadow.fontProperty().bind(message.fontProperty());
		shadow.wrappingWidthProperty().bind(message.wrappingWidthProperty());
		shadow.setOpacity(.2);
		shadow.setFill(javafx.scene.paint.Color.BLACK);
		
		startBuilder();
		//menuBuilder();
		buildEndTurn();
		
		
		this.setBackground(null);
		
		//this.getChildren().addAll(message, bPane, desc, menu);
	}
	
	
	/**
	 * Sets the text of the "console" object
	 * (the text at the top of the window)
	 * to the input String. 
	 * 
	 * @param text String of the text to be 
	 * set to the console.
	 */
	public void setConsole(String text) {
		
		message.setText(Formatter.capitalize(text));
	}
	
	
	/**
	 * Adds the input to the "console" object
	 * (the text at the top of the window)
	 * without clearing what is already there. 
	 * 
	 * @param text String of the text to be
	 * added to the console.
	 */
	public void addConsole(String text) {
		
		message.setText(((message.getText()) + Formatter.capitalize(text)));
	}
	
	
	/**
	 * Sets the text of the "desc"
	 * parameter (the text between
	 * the BattlePane and the menu
	 * Buttons) to the input String. 
	 * 
	 * @param text String of text to
	 * be set to the "desc" parameter.
	 */
	public void setDesc(String text) {
		
		setDesc(text, false);
	}
	
	
	/**
	 * Sets the text of the "desc"
	 * parameter (the text between
	 * the BattlePane and the menu
	 * Buttons) to the input String. 
	 * A "true" value on the input
	 * boolean will cause the text to
	 * be painted in the "warn" color
	 * defined in the Formatter class,
	 * while a "false" will paint it
	 * in the "main" color.
	 * 
	 * @param text String of text to
	 * be set to the "desc" parameter.
	 * @param warn Boolean determining 
	 * if the "warn" color is used.
	 */
	public void setDesc(String text, boolean warn) {
		
		desc.setText(text);
		
		if (warn) {
			
			desc.setFill(Formatter.getWarnColor());
		} else {
			
			desc.setFill(Formatter.getMainColor());
		}
	}
	
	
	/**
	 * Sets the text in the "desc"
	 * parameter to empty, effectively
	 * "clearing" it.
	 */
	public void clearDesc() {
		
		desc.setText("");
	}
	
	
	/**
	 * Sets the enemy parameter (as well
	 * as the leftFighter parameter of
	 * the BattlePane) to the input 
	 * Monster object. Automatically sets
	 * it as the static target parameter
	 * of the Action class, and displays 
	 * a message on the console indicating
	 * that a new enemy has been encountered.
	 * 
	 * @param enemy Monster to be set as the
	 * enemy parameter.
	 */
	public void setEnemy(Monster enemy) {
		
		this.enemy = enemy;
		enemyPane.setFighter(enemy);
		penta.setImage(this.enemy.getImagePath());
		addConsole(Formatter.capitalize(hero.formatMessage("\n [u] encounter[s] a ") + 
				enemy.getName() + "!\n  Prepare for battle!"));
	}
	
	
	/**
	 * Sets the enemy parameter (as well
	 * as the leftFighter parameter of
	 * the BattlePane) to a new Monster 
	 * object generated by the MonsterReader
	 * class. Automatically sets this new
 	 * Monster as the static target parameter
	 * of the Action class, and displays 
	 * a message on the console indicating
	 * that a new enemy has been encountered.
	 */
	public void setEnemy() {
		
		if (Scaler.getRound() < 14) {

			//TODO: this formula is kinda ghetto and I'll need to redo it	
			int maxRank = ((Scaler.getRound() + 5) / 4);
			
			int minRank = Math.max(1, maxRank - 2);
			
			maxRank = Math.min(4, maxRank);
			
			int rank = new java.util.Random().nextInt(maxRank - minRank + 1) + minRank;
			setEnemy(MonsterReader.make(rank, Scaler.getRound(), false));
		} else {
			
			setEnemy(new Shadow(hero));
		}
	}
	
	
	/**
	 * Consolidates methods used at the
	 * start of a new round, including
	 * leveling up the Hero and creating 
	 * and setting a new Enemy. Paintable
	 * Buttons are then updated and the
	 * main menu is displayed. 
	 */
	public void startRound() {
		
		hero.levelUp();
		
		if (!hero.statsAtMax()) {
			
			skillListBuilder();
			spellListBuilder();
			setEnemy();
			paintButtons();
			menu.mainPane();
		} else {
			
			finalScreen();
		}
	}

	/**
	 * Builds the buttons used to 
	 * determine starting Stat and 
	 * gender before the first round.
	 */
	private void startBuilder() {
		
		GridPane choices = new GridPane();
		choices.setLayoutY(150);
		choices.setLayoutX(40);
		choices.setHgap(70);
		choices.setVgap(40);
		PronounSet[] pronouns = {PronounSet.secondPersonPronouns()};
		int[] starterStat = {0};
		//apparently this is how you trick lambdas?
		
		Text prompt1 = new Text("The Hero is:");
		prompt1.setFill(Formatter.getMainColor());
		choices.add(prompt1, 0, 0);
		
		FormattedButton second = new FormattedButton("You");	
		choices.add(second, 0, 1);
		
		FormattedButton male = new FormattedButton("A Male");
		choices.add(male, 0, 2);
		
		FormattedButton female = new FormattedButton("A Female");
		choices.add(female, 0, 3);
		
		String weaponPrompt = "And [ps] fight[s] with:";
		
		Text prompt2 = new Text();
		prompt2.setFill(Formatter.getMainColor());
		choices.add(prompt2, 1, 0);
		
		FormattedButton swordButton = new FormattedButton("A Sword");
		choices.add(swordButton, 1, 1);
		
		FormattedButton spearButton = new FormattedButton("A Spear");
		choices.add(spearButton, 1, 2);
		
		FormattedButton conjButton = new FormattedButton("Conjuration\nMagic");
		choices.add(conjButton, 1, 3);
		
		FormattedButton elemButton = new FormattedButton("Elemental\nMagic");
		choices.add(elemButton, 1, 4);
		
		swordButton.setOnAction(e -> {

			swordButton.setTextFill(Formatter.getMainColor());
			spearButton.setTextFill(Formatter.getFadeColor());
			conjButton.setTextFill(Formatter.getFadeColor());
			elemButton.setTextFill(Formatter.getFadeColor());
			starterStat[0] = 0;});
		
		spearButton.setOnAction(e -> {

			swordButton.setTextFill(Formatter.getFadeColor());
			spearButton.setTextFill(Formatter.getMainColor());
			conjButton.setTextFill(Formatter.getFadeColor());
			elemButton.setTextFill(Formatter.getFadeColor());
			starterStat[0] = 1;});
		
		conjButton.setOnAction(e -> {

			swordButton.setTextFill(Formatter.getFadeColor());
			spearButton.setTextFill(Formatter.getFadeColor());
			conjButton.setTextFill(Formatter.getMainColor());
			elemButton.setTextFill(Formatter.getFadeColor());
			starterStat[0] = 2;});
		
		elemButton.setOnAction(e -> {

			swordButton.setTextFill(Formatter.getFadeColor());
			spearButton.setTextFill(Formatter.getFadeColor());
			conjButton.setTextFill(Formatter.getFadeColor());
			elemButton.setTextFill(Formatter.getMainColor());
			starterStat[0] = 3;});
		
		second.setOnAction(e -> {

			male.setTextFill(Formatter.getFadeColor());
			female.setTextFill(Formatter.getFadeColor());
			second.setTextFill(Formatter.getMainColor());
			pronouns[0] = PronounSet.secondPersonPronouns();
			prompt2.setText(pronouns[0].formatPronouns(weaponPrompt));});
		
		male.setOnAction(e -> {

			male.setTextFill(Formatter.getMainColor());
			female.setTextFill(Formatter.getFadeColor());
			second.setTextFill(Formatter.getFadeColor());
			pronouns[0] = PronounSet.malePronouns();
			prompt2.setText(pronouns[0].formatPronouns(weaponPrompt));});
		
		female.setOnAction(e -> {

			male.setTextFill(Formatter.getFadeColor());
			female.setTextFill(Formatter.getMainColor());
			second.setTextFill(Formatter.getFadeColor());
			pronouns[0] = PronounSet.femalePronouns();
			prompt2.setText(pronouns[0].formatPronouns(weaponPrompt));});
		
		second.fire();
		swordButton.fire();
		
		
		FormattedButton confirm = new FormattedButton("Head out!");
		confirm.setOnAction(e -> {
				
				
				switch (starterStat[0]) {
				
				case (0): {
					
					Sword.add(hero);
					break;
				}
				
				case(1): {
					
					Spear.add(hero);
					break;
				}
				
				case(2): {
					
					Conjuration.add(hero);
					break;
				}
				
				case(3): {
					
					Elementalism.add(hero);
					break;
				}
				
				}
				
				 
				hero.setPronouns(pronouns[0]);
				menuBuilder();
				setEnemy();
				this.getChildren().clear();
				this.getChildren().addAll(penta, shadow, message, desc, menu, heroPane, enemyPane);
				menu.changePane("main");
				startRound();
			
		});
		choices.add(confirm, 2, 5);
		
		this.getChildren().addAll(shadow, message, choices);
	}
	
	
	//I may or may not roll this into one of the other builders
	private void pentaBuilder() {
		
		AttemptTypeButton[] buttons = new AttemptTypeButton[5];

		for (int b = 0; b < buttons.length; b++) {
			
			AttemptType type = Attempt.typeFromId(b);
			buttons[b] = new AttemptTypeButton(hero, type);
			
			buttons[b].setOnAction(e -> {
				
				hero.setAttemptPlan(type);
				
				buttons[0].paint();
				buttons[1].paint();
				buttons[2].paint();
				buttons[3].paint();
				buttons[4].paint();
				//TODO: implement clicking on enemy to attempt
				if (fastmode) {
					
					startTurn();
				} else {}
			});
		}
		
	}
	
	/**
	 * Constructs the PhantomPane used
	 * for the main menu of the game,
	 * with all of the buttons and 
	 * sub-Pane menus needed for all
	 * currently implemented features. 
	 */
	private void menuBuilder() {
		
		//no this isn't part of the menu
		penta = new PentaPane();
		penta.setLayoutX(50);
		penta.setLayoutY(10);
		
		
		GridPane main = new GridPane();

		this.menu = new PhantomPane(main);
		menu.setLayoutY(450);
		
		skillListBuilder();
		spellListBuilder();
		upgradeBuilder();
		switchAttackBuilder();
		
		main.setHgap(22);
		main.setVgap(35);
		main.setMaxWidth(450);
		main.setPrefWidth(450);
		/**
		AttemptTypeButton[] buttons = new AttemptTypeButton[5];

		for (int b = 0; b < buttons.length; b++) {
			
			AttemptType type = Attempt.typeFromId(b);
			buttons[b] = new AttemptTypeButton(hero, type);
			
			paintableButtons.add(buttons[b]);
			
			buttons[b].setOnAction(e -> {
				
				hero.setAttemptPlan(type);
				
				paintButtons();
				//TODO: implement clicking on enemy to attempt
				startTurn();
			});
			
			main.add(buttons[b], (b % 3), (b / 3));
		}
		
		/*FormattedButton basic = new FormattedButton("Attack");
		
		basic.setOnAction(e -> {
			menu.getChildren().clear();
			clearDesc();
			setConsole(Attempt.clash(hero, enemy));
			bPane.update();
			endTurn.play();});
		
		main.add(basic, 0, 0);*/
		/*
		FormattedButton hstatus = new FormattedButton("Hero's Status");
		
		hstatus.setOnAction(e -> {
			setConsole(hero.statusMessage());});
		
		main.add(hstatus, 3, 0);

		
		FormattedButton estatus = new FormattedButton("Enemy's Status");
		
		estatus.setOnAction(e -> {
			setConsole(enemy.statusMessage());});
		
		main.add(estatus, 3, 1);
		*/
		FormattedButton skills = new FormattedButton("Skills");
		
		skills.setOnAction(e -> {		
			menu.changePane("skills");
			penta.hideButtons();
			if (hero.cooldown().isOnCooldown()) {
			
				setDesc(("Skills on cooldown for " + hero.cooldown().value() +
				" turns."), true);
			} else {
				
				setDesc("Skills available:");}});
		
		main.add(skills, 0, 0);
			
		
		FormattedButton spells = new FormattedButton("Spells");
		
		spells.setOnAction(e -> {
			menu.changePane("spells");
			penta.hideButtons();
			setDesc("Mana: " + hero.mana().getGauge());});
		
		main.add(spells, 2, 0);
		
		
		FormattedButton switchStat = new FormattedButton("Switch Attacking Stat");
		
		switchStat.setOnAction(e -> {		
			menu.changePane("switch");
			penta.hideButtons();
			setDesc("Choose a Stat to Attack with:", false);});
		
		main.add(switchStat, 3, 0);
	}

	
	
	/**
	 * Constructs ActionButtons for all 
	 * currently-implemented Skills, each
	 * of which is set to invoke the turn()
	 * method with its associated Skill. A
	 * "cancel" Button that returns to the 
	 * main menu is added at the end. All of 
	 * these are added to a GridPane intended 
	 * to be added to the main menu.
	 * 
	 * @return GridPane containing 
	 * ActionButtons for all potential Skills.
	 */
	private void skillListBuilder() {
			
		GridPane result = new GridPane();
		int count = 0;
		result.setPrefWidth(450);
		result.setHgap(10);
		result.setVgap(10);
		
		try {
			Action[] skills = hero.getActionList().getActionType("Skill");
		
			for (int s = 0; s < skills.length; s++) {
				
				ActionButton newButton = new ActionButton(skills[s], 12);
				
				paintableButtons.add(newButton);
				
				newButton.setOnAction(e -> {
					try {
						
						hero.prepAction(newButton.getAction());
						startTurn();
						
					} catch(IllegalArgumentException ex) {
						
						setDesc(ex.getLocalizedMessage(), true);
						
						menu.mainPane();
					}});
					
				result.add(newButton,
						(s % 3), (s / 3));
				
				count++;
			}
		} catch (IllegalArgumentException ex) {
			
			result.add(new FormattedText("No Skills learned."), (count % 3), (count / 3));
			count++;
		}
		
		FormattedButton cancel = new FormattedButton("Cancel");
		cancel.setOnAction(e -> {
			menu.mainPane();
			penta.showButtons();
			clearDesc();});

		result.add(cancel, (count % 3), (count / 3));
		
		menu.addPane(result, "skills");
	}
	

	/**
	 * Constructs ActionButtons for all 
	 * currently-implemented Spells, each
	 * of which is set to invoke the turn()
	 * method with its associated Spell. A
	 * "cancel" Button that returns to the 
	 * main menu is added at the end. All of 
	 * these are added to a FlowPane intended 
	 * to be added to the main menu.
	 * 
	 * @return FlowPane containing 
	 * ActionButtons for all potential Spells.
	 */
	private void spellListBuilder() {
		
		GridPane result = new GridPane();
		int count = 0;
		result.setPrefWidth(450);
		result.setHgap(10);
		result.setVgap(10);
		
		try {
			Action[] spells = hero.getActionList().getActionType("Spell");
		
			for (int s = 0; s < spells.length; s++) {
				
				ActionButton newButton = new ActionButton(spells[s], 12);
				
				paintableButtons.add(newButton);
				
				newButton.setOnAction(e -> {
					try {
						
						hero.prepAction(newButton.getAction());
						startTurn();
						
					} catch(IllegalArgumentException ex) {
						
						setDesc(ex.getLocalizedMessage(), true);
						
						menu.mainPane();
					}});
					
				result.add(newButton,
						(s % 3), (s / 3));
				
				count++;
			}
		} catch (IllegalArgumentException ex) {
			
			result.add(new FormattedText("No Spells learned."), (count % 3), (count / 3));
			count++;
		}
		
		FormattedButton cancel = new FormattedButton("Cancel");
		cancel.setOnAction(e -> {
			menu.mainPane();
			penta.showButtons();
			clearDesc();});

		result.add(cancel, (count % 3), (count / 3));
		
		menu.addPane(result, "spells");
	}
	
	/*
	private void itemListBuilder() {
		//TODO: if you ever implement items, please update the buttons made here
		Action[] items = hero.getActionList().getActionType("Item");
		
		Tab tab = new Tab("Items");
		
		if (items.length <= 0) {
			
			throw new NullPointerException("No items found");
		} else if (items.length > 6) {
			
			//multiple-page procedure
		} else {
			
			GridPane result = new GridPane();
			result.setPrefWidth(450);
			result.setHgap(10);
			result.setVgap(10);
			
			for (int s = 0; s < items.length; s++) {
				
				ActionButton newButton = new ActionButton(items[s], 12);
		
				//REMOVE AFTER TESTING
				//newButton.getAction().learn();
				
				paintableButtons.add(newButton);
				
				newButton.setOnAction(e -> {
					try {
						
						menu.getChildren().clear();
						clearDesc();
						//setConsole(hero.doAction(newButton.getAction(), enemy));
						heroPane.paint();
						enemyPane.paint();
						endTurn.play();
					} catch(IllegalArgumentException ex) {
						
						setDesc(ex.getLocalizedMessage(), true);
						
						menu.mainPane();
					}});
					
				result.add(newButton,
						(s % 2), (s / 2));
			}
			
			tab.setClosable(false);
			tab.setContent(result);
		}
		
		return tab;
		
	}
	
	
	
	/**
	 * Constructs and sets UpgradeButtons for
	 * each of the Hero's stats, set to
	 * increment any stats not at max 
	 * and give a message to the player
	 * about the results of this upgrade. 
	 */
	private void upgradeBuilder() {
		
		GridPane result = new GridPane();
		result.setHgap(20);
		result.setVgap(20);
		
		
		Stat[] stats = hero.getStats();
		
		for (int s = 0; s < stats.length; s++) {
			
			UpgradeButton newButton = new UpgradeButton(stats[s]);
			newButton.setFont(Formatter.getBoldFont());
			
			newButton.setOnAction(e -> {
				if (!newButton.getStat().isAtMax()) {
					
					setConsole(newButton.getStat().upLevel());
					
					clearDesc();
					
					startRound();
				} else {}});
			
			paintableButtons.add(newButton);
		
			result.add(newButton, (s % 4), (s / 4));
		}
		
		if (!hero.maxNumOfStats()) {
			
			int ups = stats.length;
	
			FormattedButton[] newButtons = newStatButtons();
			
			for (int n = 0; n < newButtons.length; n++) {
				
				result.add(newButtons[n], ((ups + n) % 4), ((ups + n) / 4));
			}
		} else {}
		
		menu.addPane(result, "upgrade");
	}
	
	
	/**
	 * Builds and sets the buttons 
	 * responsible for switching the 
	 * Hero's currently active Attacking
	 * Stat. 
	 */
	private void switchAttackBuilder() {
		
		GridPane result = new GridPane();
		result.setHgap(25);
		result.setVgap(20);
		int count = 1;
		
		Stat[] stats = hero.getStats();
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] instanceof Attacking) {
				
				Attacking stat = (Attacking)(stats[s]);
				
				SwitchAttackButton newButton = new SwitchAttackButton(stat);
				
				newButton.setOnAction(e -> {
					if (!hero.getAttackingStat().equals(stat)) {
						
						hero.switchAttackingStat(stat);
						paintButtons();
						clearDesc();
						penta.showButtons();
						menu.changePane("main");
					} else {
						
						setDesc(((Stat) stat).getName() + " is already set to attack.");}});
				
				paintableButtons.add(newButton);
			
				result.add(newButton, (s % 4), (s / 4));
				count++;
			}
		}
		
		FormattedButton cancel = new FormattedButton("Cancel");
		cancel.setOnAction(e -> {
			menu.mainPane();
			penta.showButtons();
			clearDesc();});

		result.add(cancel, (count % 3), (count / 3));
		
		menu.addPane(result, "switch");
	}
	
	
	
	private FormattedButton[] newStatButtons() {
		
		FormattedButton[] buttons = new FormattedButton[6];
		int count = 0;
		
		try {
			
			hero.getStat("Sword");
		} catch (NullPointerException ex) {
			
			FormattedButton addStat = new FormattedButton("Gain a Sword\n(Attacking Stat)");

			addStat.setOnAction(e -> {
			
				setConsole(Sword.add(hero));
				upgradeBuilder();
				switchAttackBuilder();
				clearDesc();
				startRound();});
			
			buttons[count++] = addStat;
		}
		
		try {
			
			hero.getStat("Spear");
		} catch (NullPointerException ex){
			
			FormattedButton addStat = new FormattedButton("Gain a Spear\n(Attacking Stat)");

			addStat.setOnAction(e -> {
			
				setConsole(Spear.add(hero));
				upgradeBuilder();
				switchAttackBuilder();
				clearDesc();
				startRound();});
			
			buttons[count++] = addStat;
		}
		
		try {
			
			hero.getStat("Shield");
		} catch (NullPointerException ex){
			
			FormattedButton addStat = new FormattedButton("Gain a Shield\n(non-Attacking Stat)");

			addStat.setOnAction(e -> {
			
				setConsole(Shield.add(hero));
				upgradeBuilder();
				clearDesc();
				startRound();});
			
			buttons[count++] = addStat;
		}
		
		try {
			
			hero.getStat("Conjuration");
		} catch (NullPointerException ex){
			
			FormattedButton addStat = new FormattedButton("Learn Conjuration\n(Attacking Stat)");

			addStat.setOnAction(e -> {
			
				setConsole(Conjuration.add(hero));
				upgradeBuilder();
				switchAttackBuilder();
				clearDesc();
				startRound();});
			
			buttons[count++] = addStat;
		}
		
		try {
			
			hero.getStat("Arcanism");
		} catch (NullPointerException ex){
			
			FormattedButton addStat = new FormattedButton("Learn Arcanism\n(non-Attacking Stat)");

			addStat.setOnAction(e -> {
			
				setConsole(Arcanism.add(hero));
				upgradeBuilder();
				clearDesc();
				startRound();});
			
			buttons[count++] = addStat;
		}
		
		try {
			
			hero.getStat("Elementalism");
		} catch (NullPointerException ex){
			
			FormattedButton addStat = new FormattedButton("Learn Elementalism\n(Attacking Stat)");

			addStat.setOnAction(e -> {
			
				setConsole(Elementalism.add(hero));
				upgradeBuilder();
				switchAttackBuilder();
				clearDesc();
				startRound();});
			
			buttons[count++] = addStat;
		}
		
		FormattedButton[] output = new FormattedButton[count];
		
		System.arraycopy(buttons, 0, output, 0, count);
		
		return output;
	}
	
	/**
	 * Protocol to be handled at the 
	 * start of a turn once the player
	 * makes an Attempt. Resolves the 
	 * clash of their Attempt against 
	 * the enemy's, and paints panes
	 * before starting the Endturn 
	 * Timeline. 
	 */
	private void startTurn() {
		
		try {
			
			menu.clear();
			clearDesc();
			setConsole(Attempt.clash(hero, enemy));
			heroPane.paint();
			enemyPane.paint();
			endTurn.play();
		} catch (IllegalArgumentException ex) {
			
			this.setDesc(ex.getLocalizedMessage(), true);
			paintButtons();
			menu.mainPane();
		}
	}
	
	/**
	 * Constructs the Timeline object that
	 * facilitates the enemy's turn. This also
	 * includes the procedures for the results of
	 * battle after both turns.
	 */
	private void buildEndTurn() {
		
		endTurn = new Timeline(new KeyFrame(Duration.seconds(0.4),
				(a -> {
				
				if (hero.isDead()) {
					
					defeat();
				} else if (enemy.isDead()) {
					
					victory();
				} else {
					hero.endTurn();
					enemy.endTurn();
					
					paintButtons();
					penta.showButtons();
					menu.mainPane();}})));	
	}
	
	
	/**
	 * Adjusts the output in the event that the 
	 * player reduces the enemy's health to
	 * zero while still being alive themselves.
	 * Increments the Scaler class's static 
	 * round parameter. Displays the
	 * UpgradeButtons of the Hero's Stats, 
	 * unless all of them are at max level, 
	 * in which case a new round is started 
	 * immediately. An accompanying message is
	 * written in the desc in either case. 
	 */
	private void victory() {
		
		penta.hideButtons();
		Scaler.upRound();
		
		if (hero.statsAtMax()) {
			
			finalScreen();
		} else {
			
			setDesc("You triumph over the " + enemy.getName() + 
					"!\nUpgrade one of the following stats:");
			
			menu.changePane("upgrade");	
		}
	}
	
	
	/**
	 * Displays a message on the Hero's 
	 * defeat, which varies based on
	 * whether a mutual kill was scored.
	 * The menu is not redrawn, effectively
	 * ending the game. I may regret that
	 * statement.
	 */
	private void defeat() {
		
		penta.hideButtons();
		
		if (enemy.isDead()) {
			
			setDesc(Formatter.capitalize(hero.getPerspectiveName() +
					" overcame " + enemy.getPerspectiveName() +
					",\n but at what cost..."));
		} else {
			
			setDesc(Formatter.capitalize(enemy.getPerspectiveName() + 
					" overtook " + hero.getPerspectiveName() + "."));
		}
	}
	
	/**
	 * Displays the screen attained after maxing
	 * all of the Hero's Stats and ending the
	 * game. 
	 */
	private void finalScreen() {
		
		menu.clear();
		setDesc("");
		penta.hideButtons();
		setConsole(Formatter.capitalize(hero.getPerspectiveName() + " lives on with some sort of fame. For now."));
	}
	
	/**
	 * Increments the level of the input
	 * Stat object, and causes the Hero
	 * to either learn a new Action or 
	 * upgrade a Gear's implement. Sets 
	 * the console with a message indicating 
	 * what new Action or implement was
	 * gained. 
	 * 
	 * @param stat Stat object to be
	 * upgraded.
	 *
	public void statUp(Stat stat) {
		
		try {
			
			if (stat instanceof Gear) {
			
				if ((stat.getLevel() % 2) == 0) {
					
					if (((Gear)stat).upItem()) {
						
						setConsole("\nYour " + stat.getName() + " is now a " 
						+ stat.levelName() + "!\n");
					} else {
						//failsafe in case someone levels higher than there are gear names.
						setConsole("\nYou further hone your " + stat.getName() + ".\n");
					}
				} else {
					
					setConsole("\nYou learn how to do a " +
							(hero.learnFromStat(stat)).getName() + "!\n");
				}	
			} else {
	
				setConsole("\nYou learn how to cast the " +
						(hero.learnFromStat(stat).getName()) + "Spell!\n");
			}
		
		stat.upLevel();
			
		} catch (IllegalArgumentException ex) {
			//this shouldn't come up once action testing is done
			setDesc("For some reason, you can't learn any new Actions...");
			
			stat.upLevel();
			
			startRound();
		}
		
		
	}*/


	/**
	 * Paints all PaintableButtons contained
	 * within the eponymous ArrayList. Should
	 * be invoked whenever the information on
	 * them may have changed. 
	 */
	public void paintButtons() {
		
		paintableButtons.forEach(e -> {
			e.paint();});			
	}
	
	private class PentaPane extends Pane {
		
		ImageView enemyImage;
		AttemptTypeButton[] buttons = new AttemptTypeButton[5];
		boolean canAttack = true;

		PentaPane() {

			build();
			showButtons();
		}
		
		/**
		 * Initializes the fixed placements
		 * of the buttons and image. Sets
		 * the OnActions for all buttons and
		 * the image. Sets the image to a defualt.
		 * 
		 */
		public void build() {
		/*
			spacer.setHgap(90);
			spacer.setVgap(spacer.getHgap());
			
			Pane[] spots = new Pane[5];
			spacer.add(spots[0], 2, 0);
			spacer.add(spots[1], 4, 2);
			spacer.add(spots[2], 0, 2);
			spacer.add(spots[3], 1, 4);
			spacer.add(spots[4], 3, 4);
			*/
			int[] exes = {2, 4, 0, 1, 3};
			int[] whys = {0, 2, 2, 4, 4};
			
			for (int b = 0; b < buttons.length; b++) {
				
				AttemptType type = Attempt.typeFromId(b);
				buttons[b] = new AttemptTypeButton(hero, type);
				paintableButtons.add(buttons[b]);
				buttons[b].setLayoutX(90 * exes[b]);
				buttons[b].setLayoutY(90 * whys[b]);
				
				buttons[b].setOnAction(e -> {
					
					hero.setAttemptPlan(type);
					
					paintPentaButtons();

					if (fastmode) {
						
						startTurn();
					} else {}
				});
			}
			
			enemyImage = new ImageView();
				
			setImage("SortedMonsters/WheelchairDrake.png");
			
			enemyImage.setOnMouseClicked(e -> {
				
				if (canAttack) {
					
					startTurn();
				} else {}
			});
			
			enemyImage.setFitWidth(220);
			enemyImage.setFitHeight(320);
			enemyImage.setX(130);
			enemyImage.setY(40);
		}
		
		/**
		 * Changes the displayed ImageView
		 * to a new Image file.
		 * 
		 * @param fileName String name of
		 * the new Image's file location.
		 */
		public void setImage(String fileName) {
			
			System.out.println(fileName);
			try {
				
				enemyImage.setImage(new Image(new FileInputStream(fileName)));
				showButtons();
			} catch (FileNotFoundException e) {

				
				System.out.print("could not find \"" + fileName + "\"");
			}
		}

		/**
		 * Hides the AttemptTypeButtons
		 * around the image and disables
		 * the ability to Basic Attempt
		 * by clicking on the image.
		 * 
		 */
		public void hideButtons() {
			
			canAttack = false;
			
			getChildren().clear();
			
			getChildren().add(enemyImage);
		}

		/**
		 * Shows the AttemptTypeButtons
		 * around the image and enables
		 * the ability to Basic Attempt
		 * by clicking on the image.

		 */
		public void showButtons() {
			
			canAttack = true;
			
			ObservableList<Node> chillins = //that's how my mom pronounces it sometimes. love you mom
					getChildren();
			
			chillins.clear();
			
			chillins.add(enemyImage);
			
			for (int b = 0; b < buttons.length; b++) {
				
				chillins.add(buttons[b]);
			}
		}
		
		
		/**
		 * Paints all buttons in the PentaPane.
		 * So named to avoid confusion with a
		 * similar outer class method. 
		 */
		public void paintPentaButtons() {
			
			for (int b = 0; b < buttons.length; b++) {
				
				buttons[b].paint();
			}
		}
		
	}
	
	/**
	 * Inner class that holds the name
	 * and health of a Fighter.
	 */
	private class FighterPane extends Pane implements PaintableButton {
		
		FormattedText name = new FormattedText(20);
		FormattedText health = new FormattedText(18);
		Fighter fighter;
		
		FighterPane(Fighter fighter) {
			
			this.fighter = fighter;
			this.setBackground(null);
			this.setWidth(130);
			this.setHeight(70);
			name.wrappingWidthProperty().bind(this.widthProperty().subtract(name.xProperty()));
		
			this.setOnMouseClicked(e -> {
				
				setConsole(fighter.statusMessage());
			});
			
			this.getChildren().addAll(name, health);
			paint();
		}

		/**
		 * Assigns the fighter parameter
		 * of this FighterPane, overwriting
		 * any previous parameter. Paints
		 * this Pane to reflect the new information.
		 * 
		 * @param fighter Fighter to be assigned
		 * to this Pane.
		 */
		public void setFighter(Fighter fighter) {
			
			this.fighter = fighter;
			paint();
		}
		
		/**
		 * Sets the text name and
		 * healthGuage of the Fighter.
		 * Adjusts fill color based on 
		 * whether the Fighter is damaged,
		 * dead, or neither. 
		 */
		public void paint() {
			
			this.name.setText(Formatter.capitalize(fighter.getName()));
			this.health.setText(fighter.healthGauge());
			name.setX(5);
			name.setY(5);
			health.setX(5);
			health.setY(50);
			
			if (fighter.isDead()) {
				
				name.setFadeColor();
				health.setFadeColor();
			} else if (fighter.isDamaged()) {
				
				name.setMainColor();
				health.setWarnColor();
			} else {
				
				name.setMainColor();
				health.setMainColor();
			}
		}
	}
	
}