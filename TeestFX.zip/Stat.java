package finalProject;

import finalProject.Attempt.AttemptType;

/**
 * Abstract class representing some quantifiable, if intangible,
 * aspect of a Fighter. Used for scaling Actions, as
 * well as various parameters and variables within the 
 * Main. Defines a static "maxLevel" parameter representing
 * the highest value that any subclass's level parameter
 * can reach. Level and maxLevel are facilitated via a Gauge
 * object within subclasses, and thus the Gauge class is necessary
 * for instantiating any subclasses.
 * 
 * @author Kayden Barlow
 */
abstract class Stat {
	
	private Entity user;
	private String name;
	private Gauge level;
	private Gauge numActions;
	private Action[] actions;
	private static int maxLevel = 5;
	
	/**
	 * Constructor for instances of the Stat
	 * class. Must be assigned to an 
	 * instance of the Entity class.
	 * Objects of this class's subclasses
	 * are necessary to define instances of
	 * Action subclasses. The name paramter will often 
	 * be fixed within a particular subclass.
	 * 
	 * @param user Entity to which the Stat
	 * is assigned.
	 * @param name String name of the Stat.
	 * @param level Integer value of the Stat's
	 * relative power.
	 * @param numActions Integer of the number of
	 * Actions built by this Stat.
	 */
	Stat(Entity user, String name, int level, int numActions) {
		
		this.user = user;
		this.name = name;
		this.level = new Gauge(Math.max(0, level), (maxLevel - 1));
		this.numActions = new Gauge(0, Math.min(maxLevel, Math.max(0, numActions)));
		this.actions = buildActions();
		this.user.addStat(this);
	}
	

	/**
	 * Returns the reference for the instance
	 * of the Entity class to which the Stat
	 * is assigned.
	 * 
	 * @return Entity user of the Stat.
	 */
	public Entity getUser() {
		
		return this.user;
	}
	
	
	/**
	 * Returns the name of the Stat.
	 * 
	 * @return String Stat name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "level" parameter
	 * of the Stat.
	 * 
	 * @return Integer level value.
	 */
	int getLevel() {
		
		return (level.getCurrent() + 1);
	}
	
	
	/**
	 * Returns a String of the current
	 * and maximum level parameters. If 
	 * these two values are equal, instead
	 * returns "MAX".
	 * 
	 * @return String indicating the current
	 * level parameter relative to its maximum value.
	 */
	String getLevelString() {
		
		if (isAtMax()) {
			
			return ("MAX");
		} else {
			
			return (getLevel() + "/" + maxLevel);
		}
	}
	
	
	/**
	 * Outputs a message containing the Strings of 
	 * the name parameter and the levelString method.
	 * The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the name and level data. 
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Stat's
	 * name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
		
			return (this.getName() + "\n(Level " + this.getLevelString() +")");
		} else {
			
			return (this.getName() + " (Level " + this.getLevelString() +")");
		}
	}

	
	/**
	 * Returns a "scaled" integer value
	 * derived from the level parameter of 
	 * both the Stat and its assigned Fighter, 
	 * equal the level of the Stat multiplied by
	 * its relative potency, plus the level of 
	 * its user.
	 * 
	 * @return Integer scaled this Stat's level 
	 * and potency, and its user's level.
	 */
	int getModdedLevel() {
		
		return (((getLevel() * potency()) + user.getLevel()));
	}
	
	
	/**
	 * Sets the level parameter to the 
	 * input integer value. Level cannot
	 * be negative or above the static 
	 * maxLevel parameter, as faciliated
	 * by the Gauge class.
	 * 
	 * @param level Integer new value of
	 * level parameter.
	 */
	void setLevel(int level) {
		
		this.level.setCurrent(level - 1);
	}
	
	
	/**
	 * Increments the level parameter and returns
	 * a message describing the effects of such 
	 * (potentially including new Actions learned).
	 * Methods within the facilitating Gauge class
	 * ensure that the new level does not exceed the 
	 * static maxLevel parameter. 
	 * 
	 * @return String message describing the effects
	 * of the level-up.
	 */
	public String upLevel()	{
		
		level.adjust(1);
		
		return getUser().formatMessage(upgrade());
	}
	
	
	/**
	 * Indicates if the Stat subclass's 
	 * level paramter has reached the 
	 * maximum allowed.
	 * 
	 * @return True if level is equal to
	 * its maximum value, False otherwise.
	 */
	boolean isAtMax() {
		
		return (level.isFull());
	}
	
	
	/**
	 * Returns the value of the maximum value
	 * allowed for any subclass's level parameter.
	 * 
	 * @return Integer of the value of the
	 * static maxLevel parameter.
	 */
	static int getMaxLevel() {
		
		return Stat.maxLevel;
	}
	
	
	/**
	 * Sends Actions built from this stat
	 * to the Entity using this Stat. 
	 * Will not send Actions to non-ActionUser
	 * Entities. 
	 */
	public void addActions() {
		
		if (user instanceof ActionUser) {
		
			for (int a = 0; a < getCurrentActions(); a++) {
				
				if (!(((ActionUser)getUser()).hasAction(actions[a].getName()))) {
					
					((ActionUser)getUser()).addAction(actions[a]);
				} else {}			
			}
		} else {}
	}
	
	
	
	/**
	 * Returns the number of Actions
	 * built by this Stat. This may not
	 * be the same as the number of 
	 * Actions that this Stat's user
	 * has access to.
	 *
	 * @return Integer representing the
	 * number of Actions built by this Stat.
	 */
	protected int getTotalActions() {
		
		return numActions.getMax();
	}
	
	/**
	 * Returns the number of Actions
	 * that this Stat currently grants
	 * its user access to. Obviously,
	 * cannot exceed the number of 
	 * Actions built by the Stat.
	 * 
	 * @return Integer value of the 
	 * number of granted Actions.
	 */
	protected int getCurrentActions() {
		
		return numActions.getCurrent();
	}
	
	/**
	 * Returns an Action built by
	 * this Stat according to an
	 * integer key.
	 * 
	 */
	public Action getAction(int key) {
		
		if (key > getTotalActions()) {
			
			throw new IllegalArgumentException(getName() + " does not build that many Actions.");
		} else if (key <= 0 ) {
			
			throw new IllegalArgumentException("Positive key required.");
		} else {
			
			return actions[key - 1];
		}
	}
	
	/**
	 * Increments the amount of 
	 * Actions from those built by
	 * this Stat that its user 
	 * has access to. Returns a 
	 * boolean indicating if a new
	 * Action was granted this way.
	 * 
	 * @return True if a new Action
	 * was granted, False otherwise.
	 */
	protected boolean upActions() {
		
		if (numActions.isFull()) {
			
			return false;
		} else {
			
			numActions.adjust(1);
			addActions();
			return true;
		}
	}
	
	
	/**
	 * Returns the integer representing
	 * the relative effect on scaling compared
	 * to other Stats (independant of level).
	 * By default, is inversly proportional
	 * to the number of Actions built by the 
	 * Stat. 
	 * 
	 * @return Integer used to compared scaling
	 * with other Stats.
	 */
	protected int potency() {
		
		return maxLevel - getTotalActions() + 1;
	}
	
	
	/**
	 * Returns a String containing information
	 * about the thing that this Stat uses to
	 * facilitate Actions. By defualt, is just the 
	 * Stat's name parameter.
	 *  
	 * @return String describing the Stat.
	 */
	public String getImplement() {
		
		return getName();
	}

	
	
	/**
	 * Constructs a list of Actions
	 * deriving from this Stat. 
	 * 
	 * @return Action[] containing all
	 * Actions scaled from this Stat.
	 */
	protected abstract Action[] buildActions();
	
	
	/**
	 * Facilitates the results of increasing the
	 * Stat's level, which may include learning
	 * Actions or changing flavor. Should not,
	 * in and of itself, increment the level
	 * parameter, as that is handled by a method
	 * which calls this one.
	 * 
	 * @return String describing the effects of 
	 * a level-up.
	 */
	abstract protected String upgrade();
	
	
	/**
	 * Interface marking that this Stat
	 * can be used to make and flavor
	 * basic Attempts.
	 */
	public interface Attacking {

		public Entity getUser();
		
		/**
		 * Integer value determining
		 * which Attacking stat has priority
		 * to create and assign its BasicAttack
		 * in the event that an Entity has
		 * more than one Attacking Stat assigned.
		 * Will typically be equal to its
		 * Scaling value (so that, in theory,
		 * the most potent BasicAttack will be
		 * created) unless otherwise noted.
		 * 
		 * @return Integer value of the relative
		 * priority of this Attacking Stat over
		 * any others.
		 *
		public int attackPriority();
		
		
		/**
		 * String used to construct the 
		 * message returned when using the
		 * BasicAttack generated from this
		 * Attacking Stat.
		 * 
		 * @return String displayed when
		 * attacking with this Attacking Stat.
		 *
		public String attackMessage();
		
		/**
		 * Gives a String describing a successful,
		 * nonadvantaged attempt using the input type.
		 * The String describing the opposing 
		 * failed Attempt will be inserted into any 
		 * "[f]" placeholders in this String. Said 
		 * opposing String will typically be in the 
		 * form of "(noun) tries (verb)", and will not
		 * dbe capitalized by default.
		 * This object may not have a String for every type, 
		 * see the documentation for the throw exception 
		 * below.
		 * 
		 * @param attemptType AttemptType of the 
		 * desired String.
		 * @return String describing a successful
		 * attempt, or Null (see below).
		 * @throws NullPointerException Thrown in order to 
		 * call for its user's default attempt 
		 * Strings (for those Stats that don't have
		 * a logical reason to use one over what their
		 * user could normaly do, usually evading).
		 */
		public String attackMessage(AttemptType attemptType) throws NullPointerException;
		
		
		/**
		 * Gives a String describing a successful,
		 * advantaged attempt using the input type.
		 * The String describing the opposing 
		 * failed Attempt will be inserted into any 
		 * "[f]" placeholders in this String. Said 
		 * opposing String will typically be in the 
		 * form of "(noun) tries (verb)", and will not 
		 * be capitalized by default.
		 * This object may not have a String for every type, 
		 * see the documentation for the throw exception 
		 * below.
		 * 
		 * 
		 * @param attemptType AttemptType of the 
		 * desired String.
		 * @return String describing a successful
		 * advantaged attempt, or Null (see below).
		 * @throws NullPointerException in order to 
		 * call for its user's default attempt 
		 * Strings (for those Stats that don't have
		 * a logical reason to use one over what their
		 * user could normaly do, usually evading).
		 */
		public String advantagedMessage(AttemptType attemptType) throws NullPointerException;
		
		/**
		 * Gives a brief String describing the user's
		 * failed attempt using the input type. This 
		 * String will be inserted into the opposing
		 * successful String in most cases. In order to
		 * fit sentences best, this String should take 
		 * the form of "(noun) tries (verb)" and shouldn't
		 * be capitalized by default.
		 * 
		 * This object may not have a String for every type, 
		 * see the documentation for the throw exception 
		 * below.
		 * 
		 * @param attemptType AttemptType of the 
		 * desired String.
		 * @return String describing a failed attempt, 
		 * or Null (see below).
		 * @throws NullPointerException in order to 
		 * call for its user's default attempt 
		 * Strings (for those Stats that don't have
		 * a logical reason to use one over what their
		 * user could normaly do, usually evading).
		 */
		public String failureMessage(AttemptType attemptType) throws NullPointerException;
		
		
		/**
		 * Returns the AttemptType that breaks
		 * ties when a basic Attempt is made 
		 * with this object. Can be set to return
		 * "Neutral" if no tiebreaking Type is
		 * desired, as basic Attempts cannot be
		 * Neutral anyway.
		 * 
		 * @return AttemptType that breaks ties
		 * when Attempting with this object.
		 */
		public AttemptType signatureType();
		
		
		/**
		 * Constructs the BasicAttack
		 * based on this Attacking Stat. 
		 * 
		 * @return BasicAttack derived from
		 * this Attacking Stat.
		 *
		public BasicAttack getBasicAttack();*/
	}
	
	/**
	 * Interface denoting Stats that
	 * can be thematically used to
	 * block incoming attacks.
	 */
	protected interface Blocking {

		/**
		 * Dummied method, currently
		 * unused.
		 * 
		 * @return
		 */
		public int blockPotency();
		
		/**
		 * Indicates the priority with
		 * which this Blocking Stat is
		 * selected for use above another
		 * possesed by its user.
		 * 
		 * @return Integer value of the 
		 * relative selection priority
		 * of this Stat.
		 */
		public int blockStringPriority();
		
		/**
		 * Returns the String used when 
		 * succeeding on a Blocking-type
		 * Attempt with this Stat. Should
		 * follow the normal formatting
		 * guidelines of Attacking Stat
		 * output Strings.
		 * 
		 * @return String describing this
		 * Stat blocking an attack.
		 */
		public String successfulBlockString();
		
		
		/**
		 * Returns a String used when failing
		 * on a Block-type Attempt while using
		 * this Stat. 
		 * 
		 * @return 
		 */
		public String failedBlockString();
	}
	
	/*
	protected abstract class MaterialUpgrader {
		
		private String mainTrait;
		private Gauge level;
		
		MaterialUpgrader(String mainTrait, int maxLevel) {
			
			this.mainTrait = mainTrait;
			this.level = new Gauge(maxLevel);
		}
		
		public int getLevel() {
			
			return level.getCurrent();
		}
		
		public boolean isFull() {
			
			return level.isFull();
		}
		
		abstract boolean addMaterial(Material material);
		
		public String getMainTrait() {
			
			return mainTrait;
		}
		
		abstract public String getSubTrait();
	}
	
	protected class QuantumSubTraitMaterialUpgrader extends MaterialUpgrader {

		
		QuantumSubTraitMaterialUpgrader(String mainTrait, int maxLevel) {
			
			super(mainTrait, maxLevel);
		}

		boolean addMaterial(Material material) {
			
			if (material.hasTrait(getMainTrait()) && (!isFull())) {
				
				level.adjust(material.getTraitPotency(getMainTrait()));
				
				return true;
			} else {
			
				return false;
			}
		}


		public String getSubTrait() {

			return null;
		}
		
		
	}*/
	
}
