package finalProject;

import java.util.Random;

import finalProject.Attempt.AttemptType;
import finalProject.Gear.GearPiece;

/**
 * Stat subclass meant to represent a Fighter's 
 * talent with some unspecified type of magic. Intended to
 * define and scale Spell objects. Implements ManaScale
 * to affect an associated Fighter's Mana parameter.
 * As with all Stat subclasses, the level parameter and 
 * the static maxLevel value are facilitated via a Gauge
 * object, and thus the Gauge class is necessary
 * for instantiating any objects of this class.
 * 
 * @author Kayden Barlow
 */
abstract public class Magic extends Stat implements ManaScale {

	
	/**
	 * Constructor for instances of the Magic
	 * class. Must be assigned to an 
	 * instance of the Caster class, and will
	 * be added to that Caster's list
	 * of stats. The name parameter will be fixed
	 * as "Magic".
	 * 
	 * @param user Caster to which the Stat
	 * is assigned.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Magic(Caster user, String name, int level, int numSkills) {
		
		super(user, name, level, numSkills);
	}
	
	
	
	
	
	/**
	 * As required by the ManaScale interface,
	 * returns a value intended to scale the 
	 * maxMana parameter of this object's associated
	 * Caster instance. Individual subclasses will
	 * affect the output differently.
	 * 
	 * @return Integer scaled from this Magic object's
	 * level.
	 */
	abstract public int manaScale();
	
	
	 /**
	  * Returns a String based on the Magic
	  * object's level parameter, indicating
	  * the number of spells known.
	  * 
	  * @return String of the number of 
	  * spells known.
	  *
	public String getImplement() {
		
		if (getLevel() == 0) {
			
			return "No Spells known.";
		} else if (getLevel() == 1) {
			
			return "1 Spell known.";
		} else {
			
			return (getLevel() + " Spells known.");
		}
	}*/
	
	
	
	/**
	 * Outputs a message containing the Strings of 
	 * the name parameter and the levelString method, which
	 * in this case should be equal to the number of spells
	 * known by the Hero. The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the name and level String.
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Magic
	 * Stat's name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
		
			return (this.getName() + "\nLevel " + this.getLevelString());
		} else {
			
			return (this.getName() + " Level " + this.getLevelString());
		}
	}

	int getModdedLevel() {
		
		return potency() + getUser().getLevel();
	}
	
	/**
	 * Returns a value equal
	 * to this Magic's manaScale
	 * value. 
	 */
	public int potency() {
		
		return manaScale();
	}
	
	//TODO: move magic buildactions into subclasses
	protected Spell[] buildActions() {
		
		Spell[] result = new Spell[getTotalActions()];
		
		int[] costs = {4, 2, 0, 8, 5};
		
		String[] name = {"Drain","Bolt","Ascend","Revert","Astra"};
			
		DamageScaler[] scalers = {(e -> {return Scaler.damage(e.getUser().getLevel());}),
				(e -> {return Scaler.damage(e.getStat().getModdedLevel());}),
				(e -> {return Scaler.damage(e.getUser().getLevel());}),
				(e -> {return Scaler.damage((e.getStat().getLevel() + e.getStat().getLevel()), 
							e.getUser().getLevel());}),
				(e -> {return Scaler.damage(1, (int)(e.getStat().getLevel() * 2.5));})};
		
		
		for (int a = 0; a < result.length; a++) {
			
			result[a] = new Spell(name[a], true, costs[a], this, AttemptType.NEUTRAL);
			
			result[a].addDamageScaler(scalers[a]);
		}
		
		return result;
	}


	
	protected String upgrade() {

		String emptyLevel = ("[u] further delve[s] into the art of " + getName() + ".\n\n");

		if ((getLevel() % 2) == 0) {
			
			try {
				
				if (upActions()) {
					
					addActions();
					
					return getUser().formatMessage(getAction(getCurrentActions()).learnMessage());
				} else {
					
					throw new IllegalArgumentException("shortcut");
				}
			} catch (IllegalArgumentException ex) {
				
				return emptyLevel;
			}
		} else {
			
			return emptyLevel;
		}
	}

}
