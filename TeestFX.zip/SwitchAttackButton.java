package finalProject;

import finalProject.Stat.Attacking;

/**
 * FormattedButton subclass designed
 * to display an Attacking Stat within 
 * the context of a Hero who can change
 * their Attacking Stat at will. 
 * 
 * @author Kayden Barlow
 */
public class SwitchAttackButton extends FormattedButton implements PaintableButton {

	private Attacking stat;
	
	/**
	 * Constructs a new 
	 * SwitchAttackButton. The 
	 * Attacking Stat assigned
	 * to this Button is the only
	 * parameter required, as 
	 * any important information
	 * can be gleaned from said
	 * Stat anyway. Button is
	 * painted on creation.
	 * 
	 * @param stat
	 */
	SwitchAttackButton(Attacking stat) {
		
		super();
		this.stat = stat;
		paint();
	}
	
	/**
	 * Displays the name of the
	 * assigned Attacking Stat,
	 * and a simple statement as 
	 * to whether it is set as its
	 * user's AttackingStat or not.
	 * Color is also set to reflect
	 * this information. 
	 */
	public void paint() {
		
		String base = (((Stat) stat).getName() + "\n");
		
		if (((Fighter)stat.getUser()).getAttackingStat().equals(stat)) {
			
			setText(base + "  (Set)");
			
			setTextFill(Formatter.getFadeColor());
		} else {
			
			setText(base + "(Not Set)");
			
			setTextFill(Formatter.getMainColor());
		}
	}
	
}
