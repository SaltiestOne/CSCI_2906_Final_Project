package finalProject;
import javafx.application.*;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
/**
 * Final Project for the course 
 * "Object-Oriented Programming II" at 
 * Southwest Technical College. Facilitates
 * a JavaFX-based implementation of a
 * text-based game I created for previous 
 * courses Most of the coding for this 
 * game is contained within the 
 * ConsolePane object, with this method 
 * simply formatting one. A list of 
 * necessary objects is found in the 
 * README, in the event that any are lost
 * from the .zip. 
 * 
 * @author Kayden Barlow
 */
public class TeestFX extends Application {

	public void start(Stage teestStage) {
		
		Formatter.setFont("Book Antiqua");
		Formatter.setSize(16);
		Formatter.setMainColor(Color.DODGERBLUE);
		Formatter.setWarnColor(Color.CRIMSON);
		Formatter.setFadeColor(Color.GRAY);

		Scene battleScene = new Scene(new ConsolePane(), 610, 710);

		battleScene.setFill(Color.WHEAT);
		
		teestStage.setScene(battleScene);

		teestStage.setResizable(false);
		
		teestStage.setTitle("TeestFX (beta?)");
		
		teestStage.show();
	}
	
	public static void main(String[] args) {
		    
		launch(args);
	}
}
