package finalProject;

import finalProject.Attempt.AttemptType;

/**
 * Interface denoting action-using
 * Entities which are intelligent
 * and humanoid in nature. 
 * 
 * @author Kayden Barlow
 */
public interface Humanoid extends ActionUser {
	
	/**
	 * Verbosely-named inner class that contains
	 * the strings describing the ways that a 
	 * humanoid might thematically make certain
	 * Attempts without the use (or need of)
	 * a special implement or skill. 
	 */
	public class HumanoidDefaultAttemptStringHolder {
		//YOU WILL MEET MY DEMANDS OR THE CLASS NAME WILL GET EEEEEEVEN LONGER MWA HA HA
		
		private String[] verbs = {("throw[s] a punch"),
				("sweep[s]"), ("grab[s] [t]"), 
				("sidestep[s]"), ("block[s]")};
		
		HumanoidDefaultAttemptStringHolder() {}
		
		/**
		 * Outputs a String describing
		 * a succesful Attempt made without
		 * the use of a special ability or
		 * implement. In most cases, 
		 * the user's AttackingStat will
		 * likely only ever need either 
		 * the EVADE or BLOCK Strings, 
		 * but ones for all non-NEUTRAL
		 * types are included for safety.
		 * 
		 * @param type AttemptType of the
		 * successful Attempt.
		 * @return String describing the
		 * successful Attempt.
		 */
		public String successString(AttemptType type) {
			
			String base = "";
			
			switch (type) {
			
			case QUICK: {
				
				base = ("before [f], [u] quickly [v]. [k]\n");
				break;
			}
			
			case WIDE: {
				
				base = ("[f], but [u] [v] with [pp] leg. [k]\n");
				break;
			}
			
			case TRICK: {

				base = ("[u] [v] while [f], and throw[s] them down. [k]\n");
				break;
			}
			
			case BLOCK: {
				
				base = ("[u] [v] with [pp] arms as [f], bracing against the attack.\n");
				break;
			}
			
			case EVADE: {
				
				base = ("[u] [v] as [f], entering a flanking position as [ps] do[es].\n");
				break;
			}
			default: {
				
				throw new IllegalArgumentException("Can't attack with a Neutral.");
			}
			}
			
			base = base.replace("[v]", verbs[Attempt.idFromType(type)]);
			
			return base.replace("[k]", "[u] then follow[s] up with a kick.");
		}
		
		/**
		 * Returns a brief String describing 
		 * a failed Attempt made without any
		 * special abilities or implements.
		 * 
		 * @param type AttemptType of the 
		 * failed String.
		 * @return String describing the
		 * failed Attempt.
		 */
		public String failureString(AttemptType type) {
			
			return ("[u] tr[ies] to " + verbs[Attempt.idFromType(type)].replace("[s]", ""));
		}		
	}
}
