package finalProject;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.*;

/**
 * Gear subclass meant to represent some type
 * of weapon weilded by a Fighter. Intended to define and 
 * scale certain Skill objects. All Weapons can make 
 * basic Attempts (via the Attacking Stat interface) 
 * using their own subclass-defined Strings, and provide
 * some basic Blocking as well.
 * As with all Stat subclasses, the level parameter and 
 * the static maxLevel value are facilitated via a Gauge
 * object, and thus the Gauge class is necessary
 * for instantiating any objects of this class.
 * 
 * @author Kayden Barlow
 */
abstract public class Weapon extends Gear implements Attacking, Blocking {

	Weapon(Entity user, String name, int level, int numSkills, int numPieces) {
		
		super(user, name, level, numSkills, numPieces);
	}

	public int blockPotency() {

		return 1;
	}

	public int blockStringPriority() {

		return 10 + potency();
	}


	public String successfulBlockString() {

		return "[u] assume[s] a defensive stance. Once [f], [u] block[s] the attack with [pp] " + getImplement() + ".\n";
	}


	public String failedBlockString() {
		
		return "[u] raise[s] [pp] " + getImplement() + " to block";
	}
		
}