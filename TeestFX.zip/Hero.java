package finalProject;

import java.util.Observable;
import java.util.Random;

import finalProject.Attempt.AttemptType;
import finalProject.Stat.Attacking;
import finalProject.Stat.Blocking;

/**
 * Fighter subclass representing the Hero
 * of Teest. 
 * 
 * The Gauge and PronounSet classes is required, as
 * with all Fighter subclasses, as are the Scaler,
 * ActionUser, Caster, and SkillUser classes.
 * 
 * @author Kayden Barlow
 */
public class Hero extends Fighter implements ActionUser, Caster, SkillUser, Humanoid {

	private ActionList actions;
	private Cooldown cooldown = new Cooldown();
	private ManaGauge mana = new ManaGauge(1);
	private int block = 0;
	private Attacking attackingStat;
	private Action preppedAction;
	private Blocking blockingStat;
	private HumanoidDefaultAttemptStringHolder defaultStrings = new HumanoidDefaultAttemptStringHolder();
	
	
	/**
	 * Constructor for new instances
	 * of the Hero class. Has a set
	 * name, "Hero", and a level 
	 * parameter based on input. Scales
	 * health and mana parameters on
	 * creation via the Scaler class.
	 * 
	 * @param level Integer initial 
	 * level of this Hero.
	 */
	Hero(int level) {
		
		super("Hero", level, 1);
		this.actions = new ActionList(this);
		setBasic();
		setMaxHealth(Scaler.maxHealth(getLevel(), scaleHealth()), true);
		this.mana = new ManaGauge(Scaler.maxMana(getLevel(), scaleMana()));
		setPronouns(PronounSet.secondPersonPronouns());
	}
	
	
	/**
	 * Constructor for new instances
	 * of the Hero class. Has a set
	 * name, "Hero", and a level 
	 * parameter based on input.  Scales
	 * health and mana parameters on
	 * creation via the Scaler class.
	 * 
	 * @param level Integer initial 
	 * level of this Hero.
	 */
	Hero(int level, Stat initialStat) {
		
		super("Hero", level, 1);
		this.actions = new ActionList(this);
		this.stats[0] = initialStat;
		setBasic();
		initialStat.addActions();
		setMaxHealth(Scaler.maxHealth(getLevel(), scaleHealth()), true);
		this.mana = new ManaGauge(Scaler.maxMana(getLevel(), scaleMana()));	
		setPronouns(PronounSet.secondPersonPronouns());
	}
	
	
	
	/**
	 * If the Hero is using second-person
	 * pronouns, returns "you." Otherwise,
	 * returns "the Hero" as is standard
	 * for other Fighters. 
	 */
	public String getPerspectiveName() {
		
		if (getPronouns().isSecondPerson()) {
			
			return ("you");
		} else {
			
			return ("the Hero");
		}
	}
	
	
	public String getPossesiveName() {
		
		if (getPronouns().isSecondPerson()) {
			
			return getPronouns().possesivePronoun();
		} else {
			
			return (getPerspectiveName() + "'s");
		}
	}
	
	
	public Attempt getAttempt(Entity target) {
		
		if (preppedAction == null) {
		
			if (hasAdvantage(target)) {
				
				return new Attempt(this, true, getCurrentType());
			} else {
				
				return new Attempt(this, getCurrentType(), getBreaker());
			}
		} else {
			
			return preppedAction.getAttempt(target);
		}
	}
	
	
	public boolean getBreaker() {
		
		if (preppedAction == null) {
			
			return (getAttackingStat().signatureType() == getType());
		} else {
			
			//TODO: implement tiebreaker actions
			return false;
		}
	}
	
	
	public String handleSuccess(Entity target, boolean advantage) {
		
		if (preppedAction == null) {
			
			return basicAction(target, advantage);
		} else {
			
			String output = preppedAction.doAction(target, advantage);
			preppedAction = null;
			return output;
		}
	}
	
	
	/*protected String normalAttack(Entity target) {
		
		throw new IllegalArgumentException("Hey implement this please");
	}
	
	
	protected String advantagedAttack(Entity target) {
		
		throw new IllegalArgumentException("Hey implement this please");
	}*/
	
	
	protected void setAttemptPlan(AttemptType type) {
		
		if (type == AttemptType.NEUTRAL) {
			
			throw new IllegalArgumentException("Cannot attack with Neutral.");
		} else {
			
			setAttemptType(type);
			preppedAction = null;
		}
	}
	
	public void prepAction(Action action) {
		
		preppedAction = getAction(action);
	}
	
	public AttemptType getCurrentType() {
		
		if (preppedAction == null) {
			
			return getType();
		} else {
			
			return preppedAction.getAttemptType();
			//return the Action's type
		}
	}
	
	public String defaultSuccessStrings(AttemptType type) {
		
		if (blockingStat == null) {
			
			setBlockingStat();
		} else {}
		
		if (type == AttemptType.BLOCK) {
			
			return blockingStat.successfulBlockString();
		} else {
					
			return defaultStrings.successString(type);
		}
	}
	
	public String handleFailure(Entity target) {
		
		if (preppedAction == null) {
			
			try {
			
				return formatMessage(attackingStat.failureMessage(getCurrentType()), target);
			} catch (NullPointerException ex) {
				
				return formatMessage(defaultFailureStrings(getCurrentType()), target);
			}
		} else {
			
			return formatMessage(preppedAction.failureString(), target);
		}
	}
	
	
	public String defaultFailureStrings(AttemptType type) {
		
		if (blockingStat == null) {
			
			setBlockingStat();
		} else {}
		
		if (type == AttemptType.BLOCK) {
			
			return blockingStat.failedBlockString();
		} else {
					
			return defaultStrings.failureString(type);
		}
	}
	
	/**
	 * Sets the Hero's designated
	 * Attacking Stat to one sharing
	 * the input name. If no Stat
	 * with such a name is found, returns
	 * false.
	 * 
	 * @param statName String name of the 
	 * Stat to be used for attacking.
	 * @return True if a Stat matching the
	 * name was found and set, False otherwise.
	 */
	public boolean switchAttackingStat(String statName) {
		
		Stat[] stats = getStats();
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s].getName() == statName) {
				
				return switchAttackingStat((Attacking)stats[s]);
			} else {}
		}
		
		return false;
	}
	
	/**
	 * Sets the Hero's designated
	 * Attacking Stat to the input object, 
	 * if valid. If the input is not
	 * actually associated with the user,
	 * it is rejected. The returned boolean
	 * reflects if the input was valid or not.
	 *  
	 * @param attackingStat Attacking Stat to be
	 * designated as the Stat used for attacking.
	 * @return True if the input Stat was valid 
	 * and set, False otherwise.
	 */
	public boolean switchAttackingStat(Attacking attackingStat) {
		
		if (attackingStat.getUser().equals(this)) {
			
			this.attackingStat = attackingStat;
			return true;
		} else {
			
			return false;
		}
	}
	
	
	private boolean emergencySetAttackingStat() {
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] instanceof Attacking) {
				
				attackingStat = (Attacking)stats[s];
				return true;
			}
		}
		
		return false;
	}
	
	protected Attacking getAttackingStat() {
		
		if (attackingStat == null) {
			
			if (emergencySetAttackingStat()) {
			
				return attackingStat;
			} else {
				
				throw new IllegalArgumentException("ey your emergency attack stat setter didn't work");
			}
		} else {
			
			return attackingStat;
		}
	}
	
	public void setBlockingStat() {
		
		int priority = 0;
		int index = -1;
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] instanceof Blocking) {
				
				if (priority < ((Blocking)(stats[s])).blockStringPriority()) {
					
					priority = ((Blocking)(stats[s])).blockStringPriority();
					index = s;
				} else {}
			} else {}
		}
		
		if (index >= 0) {
			
			if ((stats[index] instanceof Weapon) && 
					(attackingStat instanceof Weapon)) {
				
				blockingStat = (Blocking)attackingStat;
			} else {
				
				blockingStat = (Blocking)stats[index];
			}
		} else {}
	}
	
	
	protected int defaultDamageScaling() {
		
		//TODO: FIX AFTER TESTING	
		return 999;
		//return Scaler.damage(getLevel());
	}
	
	/**
	 * Adds an input Action to the Hero's
	 * ActionList, if there is room.
	 * 
	 * @param action Action to be made usable
	 * by this Hero
	 * @return True if input Action 
	 * was successfully added, False otherwise
	 */
	public boolean addAction(Action action) {
		
		return actions.add(action);
	}
	
	
	
	public Action getAction(String actionName) {
		
		return actions.get(actionName);
	}
	
	
	public Action getAction(Action action) {
		
		return getAction(action.getName());
	}
	
	public boolean hasAction(String name) {
		
		return actions.hasAction(name);
	}
	
	/**
	 * Returns the ActionList assigned 
	 * to this Hero.  
	 * 
	 * @return ActionList object assigned 
	 * to this Hero.
	 */
	public ActionList getActionList() {
		
		return actions;
	}

	
	/**
	 * Returns an array of all Actions
	 * deriving from a particular Stat,
	 * using the identically-named method
	 * from ActionList.
	 * 
	 * @param stat Stat tied to the desired 
	 * Actions.
	 * @return Action[] of all associated
	 * Actions.
	 */
	public Action[]	actionsFromStat(Stat stat) {
		
		return actions.getFromStat(stat);
	}
	
	
	/**
	 * Searches for the first instance of an
	 * unlearned Action tied to the input Stat,
	 * sets it learned, and returns it. 
	 * 
	 * @param stat Stat associated with desired
	 * Action.
	 * @return 
	 *
	public Action learnFromStat(Stat stat) {
		
		return actions.learnFromStat(stat);
	}*/
	
	/**
	 * Finds a known Action via a String equal
	 * to its name and performs its effects
	 * on a target Entity. Outputs a String
	 * describing the effect.
	 * 
	 * @param actionName String name of an
	 * Action known by this Entity.
	 * @param target Entity targeted by the 
	 * effects of the Action.
	 * @return String describing the effects
	 * of the Action.
	 *
	public String doction(String actionName, Entity target) {
		
		if (actionName.equals("Attack")) {
			
			return doBasic(target);
		} else {
			
			return actions.get(actionName).doAction(target);
		}
	}*/
	
	
	/**
	 * Finds a known Action and performs 
	 * its effects on a target Entity. 
	 * Outputs a String describing the effect.
	 * 
	 * @param actionName String name of an
	 * Action known by this Entity.
	 * @param target Entity targeted by the 
	 * effects of the Action.
	 * @return String describing the effects
	 * of the Action.
	 *
	public String doAction(Action action, Entity target) {

		return doAction(action.getName(), target);
	}*/
	

	public Cooldown cooldown() {
		
		return cooldown;
	}
	/*
	public int getCooldown() {
		
		return cooldown;
	}
	
	
	
	public boolean isOnCooldown() {
		
		if (cooldown <= 0) {
			
			return false;
		} else {
			
			return true;
		}
	}

	public void setCooldown(int cooldown) {
		//increases cooldown to a set amount
		if (cooldown >= 0) {
			
			this.cooldown = cooldown;
		} else {
			
			this.cooldown = 0;
		}
	}
	

	
	public void dropCooldown() {
		
		this.dropCooldown(1);
	}
	
	
	
	public void dropCooldown(int decrement) {
		//decreases by a set amount, not to a negative value
		if ((cooldown - decrement) >= 0) {
		
			cooldown -= decrement;
		} else {
			
			cooldown = 0;
		}
	}*/
	
	
	public ManaGauge mana() {
		
		return mana;
	}
	
	/*
	public int getMaxMana() {
		
		return mana.getMax();
	}
	
	
	
	public void setMaxMana(int maxMana, boolean maximize) {
		
		mana.setMax(maxMana, maximize);
	}
	

	
	public int getMana() {
		
		return mana.getMana();
	}
	
	
	
	public void setMana(int mana) {
		
		this.mana.setCurrent(mana);
	}*/
	

	
	/**
	 * Attempts to reduce current Mana by
	 * the input amount. Returns a Boolean
	 * indicating if Mana was spent.
	 * 
	 * @param amount Integer reduction in current Mana.
	 * @return Boolean True if Mana was sufficient and
	 * was spent, False otherwise.
	 *
	public boolean spendMana(int amount) {
		
		if (amount > getMana()) {
			
			return false;
		} else {
			
			mana.adjust(-amount);
			
			return true;
		}
	}*/
	
	
	/**
	 * Increases the current Mana by the 
	 * input amount. Will not exceed the
	 * maximum Mana value.
	 * 
	 * @param amount Integer to be added 
	 * to available Mana.
	 *
	public void adjustMana(int amount) {
		
		
		mana.adjust(amount);
	}
	
	
	/**
	 * Indicates if current Mana is less
	 * than maximum.
	 * 
	 * @return False if current and maximum
	 * Mana are equal, True otherwise.
	 *
	boolean manaSpent() {
		
		if (!(mana.isFull())) {
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns a String containing both
	 * current and maximum Mana, intended
	 * for menus and such.
	 * 
	 * @return Available and maximum Mana
	 * values, seperated by a slash.
	 *
	String manaGauge() {
		
		return mana.getGauge();
	}
	
	
	/**
	 * Outputs a message containg this
	 * Hero's name, level, and information
	 * about each of its associated Stat
	 * objects.
	 * 
	 */
	public String statusMessage() {
		
		String result =  (getName() + "'s Level: " + getLevel());
				
		for (int s = 0; s < 3; s++) {
			
			if (stats[s] != null) {
				
				result += ("\n" + stats[s].menuMessage(false));
			} else {}		
		}
		
		return result;			
	}
	
	
	/*
	public String disable(int potency) {
		
		if (new Random().nextBoolean()) {
			
			setCooldown(getCooldown() * 2);
			
			return formatMessage("saps [pp] stamina");
		} else {
			
			setMana(getMana() / 2);
			
			return "drains your Mana";
		}
	}
	*/
	
	
	public boolean afflict(Affliction affliction) {
		
		switch(affliction.name) {
		
		case ("weaken"): {
			
			//TODO: figure this out
			return false;
		}
		
		case ("stun"): {
			
			if (afflict(new Affliction("disarm", affliction.potency))) {
				
				return true;
			} else {
				
				return afflict(new Affliction("collapse", affliction.potency));
			}
		}
		
		case ("collapse"): {
			
			if (mana().getMana() > 0) {
				
				mana().adjust(- Math.min(1, affliction.potency));
				return true;
			} else {
				
				return false;
			}
		}
		
		case ("disarm"): {
			
			Affliction.disarm().afflict(this, affliction.potency);
		}
		
		default: {
			
			return false;
		}
		}
	}
	
	
	/**
	 * Searches among the Attacking Stats
	 * assigned to this Hero, and builds 
	 * a BasicAttack from the one with the 
	 * highest priority. This BasicAttack
	 * is then assigned to the eponymous
	 * parameter.
	 */
	protected void setBasic() {
	/*
		int priority = 0;
		
		int index = -1;
	
		for (int s = 0; s < stats.length; s++) {
		
			if (stats[s] instanceof Attacking) {
			
				if (((Attacking)stats[s]).attackPriority() > priority) {
				
					priority = ((Attacking)stats[s]).attackPriority();
					
					index = s;
				} else {}
			} else {}
		}
	
		if (index > -1) {
		
			basicAttack = ((Attacking)stats[index]).getBasicAttack();
		} else {}*/
	} 
	
	
	
	public String doBasic(Entity target) {
		
		return basicAttack.doAction(target, false);
	}
	
	public void endTurn() {
		
		cooldown.drop();
		//TODO: damage mitigation from Blocking Stats
	}
	

	/**
	 * Returns an integer scaled from any 
	 * HealthScale-implementing Stat objects 
	 * associated with this Hero. This
	 * integer is intended to be used to 
	 * set the Hero's maximum Health parameter.
	 * 
	 * @return Integer scaled from 
	 * HealthScale-implementing Stat objects.
	 */
	public int scaleHealth() {
		
		int scaleGetter = 0;
		
		for (int s = 0; s < 3; s++) {
			
			if (stats[s] instanceof HealthScale) {
				
				scaleGetter += ((HealthScale)(stats[s])).healthScale();
			} else {}		
		}
		
		return scaleGetter;
	}
	
	
	/**
	 * Returns an integer scaled from any 
	 * ManaScale-implementing Stat objects 
	 * associated with this Hero. This
	 * integer is intended to be used to 
	 * set the Hero's maximum Mana parameter.
	 * 
	 * @return Integer scaled from 
	 * ManaScale-implementing Stat objects.
	 */
	public int scaleMana() {
		
		int scaleGetter = 0;
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] instanceof ManaScale) {
				
				scaleGetter += ((ManaScale)(stats[s])).manaScale();
			} else {}
		}
		
		return scaleGetter;
	}
	
	
	public int magicScaler() {
		
		return getLevel() + scaleMana();
	}
	
	/**
	 * Increments the Hero's level,
	 * scales both the health and
	 * mana parameters according to
	 * scaling stats and the Scaler
	 * class, and resets the Skill
	 * cooldown.
	 */
	public void levelUp() {
		
		setLevel(getLevel() + 1);
		setMaxHealth(Scaler.maxHealth(getLevel(), scaleHealth()), true);
		mana().setMax(Scaler.maxMana(getLevel(), scaleMana()), true);
		unRust();
		setBasic();
		cooldown.set(0);
		setBlockingStat();
	}


	public void stun() {
		
		//i guess the Hero is immune for now lmao
	}
}
