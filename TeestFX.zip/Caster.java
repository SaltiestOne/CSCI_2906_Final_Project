package finalProject;

/**
 * ActionUser subinterface denoting Entities
 * that are able to use Mana-consuming Actions
 * (chiefly Spells).
 * 
 * @author Kayden Barlow
 */
public interface Caster extends ActionUser {

	/**
	 * Returns a ManaGauge,
	 * which in most cases
	 * should be the one 
	 * assigned as a parameter
	 * to this Caster.
	 * 
	 * @return ManaGauge 
	 * from this Caster.
	 */
	public ManaGauge mana();
	
	
	/**
	 * Returns an integer scaler
	 * for the relative "power"
	 * of this Caster's magic.
	 * 
	 * @return Integer used for
	 * Magic and Spell scaling.
	 */
	public int magicScaler();
	
	/**
	 * Gauge subclass used to
	 * represent a resource used
	 * for Spells and other Magicy
	 * things. Casters should typically
	 * be assigned one as a parameter.
	 * 
	 */
	public class ManaGauge extends Gauge {
		
		/**
		 * Constructs a new ManaGauge
		 * with the input integer
		 * as its initial maximum
		 * value. Available Mana
		 * will be equal to the 
		 * maximum value by default.
		 * 
		 * @param maxMana Integer amount
		 * of initial maximum Mana.
		 */
		ManaGauge(int maxMana) {
			
			super(maxMana);
		}
		

		/**
		 * Returns the integer value of the
		 * Caster's available Mana.
		 * 
		 * @return Integer of available Mana.
		 */
		public int getMana() {
			
			return getCurrent();
		}
		
		/**
		 * Sets the Caster's currently available Mana
		 * to the input amount. This cannot be
		 * negative, or exceed the maximum Mana 
		 * value.
		 * 
		 * @param mana Integer new Mana value.
		 */
		public void setMana(int mana) {
			
			setCurrent(mana);
		}
		
		/**
		 * Returns the value of the Caster's
		 * maximum Mana paramater.
		 * 
		 * @return Integer maximum Mana.
		 *
		public int getMax() {
			
			return getMax();
		}*/
		
		/**
		 * Adjusts the maximum Mana
		 * value to the input integer. 
		 * Cannot be negative.
		 * 
		 * @param maxMana Integer of the new
		 * maximum Mana value.
		 * @param maximize Boolean determining
		 * if the available Mana value is set to
		 * the new Maximum.
		 *
		public void setMax(int maxMana, boolean maximize) {
			
			setMax(maxMana, maximize);
		}*/
		
		
	}
}
