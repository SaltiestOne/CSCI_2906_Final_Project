package finalProject;

import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;


/**
 * Subclass of Button that automatically 
 * formats itself using the static parameters 
 * defined in the Formatter object, pontentially
 * including Font, font size, and color. It and 
 * its subclasses cannot be instantiated until
 * all necessary parameters have been defined
 * in Formatter.
 * 
 * @author Kayden Barlow
 */
public class FormattedButton extends Button {

	private Text mainText = new Text();
	/**
	 * Constructor for instances of the 
	 * FormattedButton class. Creates a 
	 * Button with the input text, with the
	 * Font, main Color, and default text 
	 * size defined in the Formatter object.
	 * 
	 * @param text String of the Button's text.
	 */
	FormattedButton(String text) {
		
		super(text);
		this.setFont(Formatter.getFont());
		this.setTextFill(Formatter.getMainColor());
		this.setBackground(null);
		
		//TODO: hey if you ever try shadowed text buttons again, the code is still here
		/*mainText = new Text(text);
		mainText.setFont(Formatter.getFont());
		mainText.setFill(Formatter.getMainColor());
		
		Text shadowText = new Text();
		shadowText.textProperty().bind(mainText.textProperty());
		shadowText.fontProperty().bind(mainText.fontProperty());
		shadowText.xProperty().bind(mainText.xProperty().add(1));
		shadowText.yProperty().bind(mainText.yProperty().add(1));
		shadowText.setOpacity(.2);
		
		Pane textHolder = new Pane();
		textHolder.getChildren().add(0, shadowText);
		textHolder.getChildren().add(1, mainText);
		this.setGraphic(textHolder);*/
		//this.setFont(Formatter.getFont());
		//this.setTextFill(Formatter.getMainColor());
		//this.getShape().setStrokeWidth(7);
		//this.getShape().setStroke(Formatter.getMainColor());
		
		//setTooltip();
		this.setBackground(null);
	}
	
	/**
	 * Constructor for instances of the 
	 * FormattedButton class. Creates a 
	 * Button with the input text and font size,
	 * with the Font and main Color  
	 * defined in the Formatter object.
	 * 
	 * @param text String of the Button's text.
	 * @param int Double font size of the 
	 * Button's text.
	 */
	FormattedButton(String text, double size) {
		
		super(text);
		this.setFont(Formatter.getFont(size));
		this.setTextFill(Formatter.getMainColor());
		this.setBackground(null);
		
	}
	
	
	/**
	 * No-arg Constructor for instances of the 
	 * FormattedButton class. Creates a 
	 * Button without text and with the
	 * Font, main Color, and default text 
	 * size defined in the Formatter object.	 
	 */
	FormattedButton() {
		
		super();
		this.setFont(Formatter.getFont());
		this.setTextFill(Formatter.getMainColor());
		this.setBackground(null);
	}
	
	/*public void setFont(Font value) {
		
		mainText.setFont(value);
	}*/

	/*
	protected void setTooltip() {
		TODO: tooltips
		Tooltip tip = new Tooltip();
	
		tip.setOpacity(.5);
		tip.setFont(this.getFont());
		tip.setText("Test tooltip");
		
		this.setTooltip(tip);
	}*/
}
