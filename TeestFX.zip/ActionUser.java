package finalProject;

/**
 * Interface marking that an Entity
 * is capable of performing Actions.
 * 
 *  @author Kayden Barlow
 */
interface ActionUser extends Entity {
	
	
	/**
	 * Adds the input Action to the 
	 * Entity. Typically, it will add it
	 * to a permanent list. If Entity is
	 * unable to add it, returns a False
	 * boolean.
	 * 
	 * @param action Action to be added
	 * to the Entity.
	 * @return True if the Action was 
	 * successfully added, False if not.
	 */
	public boolean addAction(Action action);
	
	
	/**
	 * Retrieves an Action that the Entity
	 * may possess, based on a String denoting
	 * its name. Returns the Action if it was 
	 * found, should throw an exception
	 * if not.
	 * 
	 * @param actionName String name of the 
	 * desired Action.
	 * @return Action possessed by this Entity.
	 */
	public Action getAction(String actionName);

	
	/**
	 * Retrieves an Action that the Entity
	 * may possess, using the reference of the
	 * Action itself. This method may unreliable
	 * for that reason if called externally from
	 * its assigned Entity. Returns the Action 
	 * if it was found, should throw an exception
	 * if not.
	 * 
	 * @param action Action instance desired.
	 * @return Action possessed by this Entity. 
	 */
	public Action getAction(Action action);
	
	
	/**
	 * Indicates if this ActionUser has an 
	 * Action with the input name.
	 * 
	 * @param actionName String name of 
	 * potential Action.
	 * @return True if this ActionUser has 
	 * it, False otherwise.
	 */
	public boolean hasAction(String actionName);
}
