package finalProject;

import finalProject.Attempt.AttemptType;

/**
 * An abstract class for the various Actions
 * that the Hero can perform. The specifics,
 * including resource costs, are left for 
 * concrete subclasses to define.
 * 
 * @author Kayden Barlow
 */
abstract class Action {
	
	private String name;
	private UseCondition condition = (a -> {return true;});
	private int cost;
	private Stat stat;
	private AttemptType attemptType;
	private ActionDoer doer = null;
	private DamageScaler scaler = null;
	private String typeName;
	
	/**
	 * The constructor for any concrete subclass instances
	 * of the abstract Action class.
	 * 
	 * @param name String of the Action's name. Should be identical
	 * to one on the AllActions list if convenience methods from that 
	 * class are to be invoked.
	 * @param cost Integer for the Action's resources cost, used 
	 * and invoked differently according to its concrete type.
	 * @param stat The Stat object from which the Action's scaling is derived.
	 * @param typeName String indication the name of the Action's subclass. Should
	 * be invoked by these subclasses, but not alterable by their constructors.
	 * @param type AttemptType of any Attempt made by this Action.
	 */
	Action (String name, int cost, Stat stat, String typeName, AttemptType type) {
		
		this.name = name;
		this.cost = cost;
		this.stat = stat;
		this.typeName = typeName;
		this.attemptType = type;
	}
	
	/**
	 * The constructor for any concrete subclass instances
	 * of the abstract Action class.
	 * 
	 * @param name String of the Action's name. Should be identical
	 * to one on the AllActions list if the addDoer parameter is set
	 * to True.
	 * @param addDoer Boolean determining if the name parameter is to
	 * be used to find and add an ActionDoer to the new Action.
	 * @param cost Integer for the Action's resources cost, used 
	 * and invoked differently according to its concrete type.
	 * @param stat The Stat object from which the Action's scaling is derived.
	 * @param typeName String indication the name of the Action's subclass. Should
	 * be invoked by these subclasses, but not alterable by their constructors.
	 * @param type AttemptType of any Attempt made by this Action.
	 */
	Action (String name, boolean addDoer, int cost, Stat stat, String typeName, AttemptType type) {
		
		this (name, cost, stat, typeName, type);
		
		if (addDoer) {
			
			try {
				
				this.setActionDoer(AllActions.getDoer(name));
			} catch (IllegalArgumentException ex) {
				//TODO: hey an actual procedure might be good here
			}
		} else {}
	}
	
	
	/**
	 * Retrieves the name of the Action
	 * subclass to which this Action belongs.
	 * 
	 * @return String indicating the name of
	 * this Action's subclass.
	 */
	public String getTypeName() {
		
		return typeName;
	}
	
	
	/**
	 * Returns the Action's name parameter.
	 * 
	 * @return String of the Action's name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "implement," or variable
	 * means by which the Action is "used." Gives
	 * the name of the Stat tied to the Action,
	 * but is itended to be overwritten in subclasses
	 * requiring Gear Stats to give the name of
	 * the specific "piece" of equipment used.
	 * 
	 * @return String of the "thing" used by the Action.
	 */
	String getImplement() {
		
		return this.stat.getImplement();
	}
	
	

	
	/**
	 * Returns the Action's resource cost. How this is used
	 * is intended to be defined by subclasses.
	 * 
	 * @return Integer value of the Action's resource cost.
	 */
	int getCost() {
		
		return cost;
	}
	
	

	
	/**
	 * Returns the reference to the Action's 
	 * associated Stat object. Only returns the 
	 * reference, further parameters and methods
	 * must be invoked afterwards.
	 * 
	 * @return Reference of the Stat object 
	 * associated with this Action.
	 */
	Stat getStat() {
		
		return this.stat;
	}
	
	
	/**
	 * Returns the reference to the ActionUser Entity
	 * associated with the Stat object associated 
	 * with this skill, which is therefore also the 
	 * "user" of the skill. Useful as a shortcut for 
	 * Actions that affect their user directly.
	 * 
	 * @return Reference of the ActionUser object 
	 * associated with the Stat 
	 * object associated with this Action.
	 */
	ActionUser getUser() {
		
		return (ActionUser)this.stat.getUser();
	}
	
	/**
	 * Returns the AttemptType enum
	 * that Attempts made by this Action
	 * will have.
	 * 
	 * @return AttemptType for Attempts
	 * made by this Action.
	 */
	public AttemptType getAttemptType() {
		
		return attemptType;
	}
	
	
	/**
	 * Assigns a DamageScaler object
	 * to this Action. This will be invoked
	 * to determine the "potency" of the 
	 * Action's effects. Lambda compatible. 
	 * 
	 * @param scaler DamageScaler object 
	 * affecting the scaling of the Action.
	 */
	public void addDamageScaler(DamageScaler scaler) {
		
		this.scaler = scaler;
	}
	
	
	/**
	 * Assigns a DamageScaler object to
	 * this Action using the default
	 * "damage" formula found in the 
	 * Scaler class.
	 * 
	 * @param scaler Integer to be used
	 * to scale from the Scaler class.
	 */
	public void addDamageScaler(int scaler) {
		
		addDamageScaler(e -> {
			
			return Scaler.damage(scaler);});
	}
	
	
	/**
	 * Returns a value scaled from this Action's
	 * assigned DamageScaler lambda. If none has
	 * been assigned, calls for the Scaler class.
	 * 
	 * @return Integer 
	 */
	public int scale() {
		
		int scale = 0;
		if (scaler == null) {
			
			scale = Scaler.damage(this.getStat());
		} else {
			
			scale = scaler.damage(this);
		}
		
		if (isRusted()) {
			
			scale = (int)(scale * .5);
		} else {}
		
		return scale;
	}

	/**
	 * Indicates if this Action is
	 * of the same AttemptType as its user's 
	 * currently Rusted AttemptType.
	 * 
	 * @return True if this Action's 
	 * AttemptType is Rusted, False otherwise.
	 */
	public boolean isRusted() {
		
		return (getAttemptType() == getUser().getRustedType());
	}
	
	
	/**
	 * Outputs a brief String describing
	 * a user failing to use this
	 * Action, called when failing an
	 * Attempt made with this Action.
	 * 
	 * @return String briefly describing
	 * a failed Attempt made with this 
	 * Action.
	 */
	public String failureString() {
		//TODO: per-action failure strings
		return ("[u] tr[ies] to use " + getName());
	}
	
	
	/**
	 * Sets this Action with an ActionDoer to 
	 * facilitate its individual effects. Will
	 * usually match the name of the Action.
	 * 
	 * @param actionDoer ActionDoer creating the 
	 * unique effects of this Action.
	 */
	public void setActionDoer(ActionDoer actionDoer) {
		
		this.doer = actionDoer;
	}
	/*
	public String doAction(Action opposingAction) {
		
		if (isUsable()) {
			
			if (doer == null) {
			
				throw new IllegalArgumentException("Action \"" + getName() + "\" not properly constructed.");
			} else {
			
				if (//type clash go here) {
						
							return formatMessage(doer.doinguAcushun(this, target), target);
						
					
			}
		} else {
			
			throw new IllegalArgumentException(errorMessage());
		}	
	}*/

	
	/**
	 * Handles the effects of this Action according
	 * to is ActionDoer, and returns a String describing
	 * the effects of such. Will throw an exception if
	 * no Doer was added.
	 * 
	 * @param target Entity targeted by this Action.
	 * @param advantaged Boolean indicating if this
	 * Action was invoked by a successful Advantaged
	 * Attempt.
	 * @return String describing the Action's effect.
	 */
	public String doAction(Entity target, boolean advantaged) {
		
		if (isUsable()) {
			
			if (doer == null) {
			
				throw new IllegalArgumentException("Action \"" + getName() + "\" not properly constructed.");
			} else {
			
				return formatMessage(doer.doinguAcushun(this, target, advantaged), target);
			}
		} else {
			
			throw new IllegalArgumentException(errorMessage());
		}	
	}
	
	
	
	
	/**
	 * Constructs and outputs an Attempt
	 * using the relevant parameters of 
	 * this Action. Resulting Attempt
	 * will have the AttemptType assigned
	 * to this Action at its creation, its
	 * attempter will be this Action's user,
	 * its target will be determined by the
	 * imput parameter, and this Action will 
	 * invoke its user's method to 
	 * determined Advantage. Cannot inherently
	 * break ties in the current release.
	 * 
	 * @param target Entity targeted to clash
	 * with the output Attempt.
	 * @return Attempt constructed by this
	 * Action, in conjuction with its user.
	 */
	public Attempt getAttempt(Entity target) {
		
		if (!isUsable()) {
			
			throw new IllegalArgumentException(errorMessage());
		} else {
			
			cost();
			
			if (getUser().hasAdvantage(target)) {
		
				return new Attempt(getUser(), true, attemptType);
			} else {
				
				return new Attempt(getUser(), attemptType, false);
			}
		}
	}
	
	/**
	 * Formats the input message, replacing certain
	 * substrings with words determined by parameters
	 * of this Action, its Stat, and its User. Should
	 * be invoked on most Strings output by an Action. 
	 * 
	 * @param message String to be modified.
	 * @return Formatted String.
	 */
	private String formatMessage(String message) {
		
		message = getUser().formatMessage(message);
		message = message.replace("[i]", getImplement());
		
		return message;
	}
	
	/**
	 * Formats the input message, replacing certain
	 * substrings with words determined by parameters
	 * of this Action, its Stat, and its User, as well
	 * as the targeted Enitity's parameters. Should
	 * be invoked on most Strings output by an Action. 
	 * 
	 * @param message String to be modified.
	 * @param target Entity targeted by this Action.
	 * @return Formatted String.
	 */
	private String formatMessage(String message, Entity target) {
		
		message = formatMessage(message).replace("[t]", target.getPerspectiveName());
		return message.replace("[tp]", target.getPossesiveName());
	}
	

	
	
	
	/**
	 * Abstract method indicating if the Action can be used.
	 * As this may involve the resource costs and other
	 * restrictions of subclasses, this is left abstract for
	 * them to define. In most cases, should return False 
	 * regardless of other considerations if the Action is 
	 * unlearned.
	 * 
	 * @return True if the Action can currently be used,
	 * False otherwise.
	 */
	abstract boolean isUsable();
	
	
	/**
	 * Abstract method returning a String with info on
	 * the specific Action, intended for use in a list of 
	 * possible Actions. Should include the name as well
	 * as resource cost and other relevant use info. As this 
	 * info will depend on the Action's subclass, the 
	 * method is left abstract.
	 * 
	 * @return String with info on the use of the Action.
	 */
	abstract String menuMessage();
	
	
	/**
	 * Abstract method used to provide String descriptions
	 * for exceptions thrown as a result of invalid Actions.
	 * As usability is a factor, this method is left abstract. 
	 * 
	 * @return String description of why this Action is
	 * unusable.
	 */
	abstract String errorMessage();
	
	
	/**
	 * Returns a message describing
	 * that the user has learned this
	 * Action, varying based on type. 
	 * 
	 * @return String describing the 
	 * attainment of this Action based
	 * on its subclass.
	 */
	abstract protected String learnMessage();
	
	
	/**
	 * Consolidation method for
	 * handling whatever procedures
	 * involve spending or using
	 * resource costs. Is not called
	 * for in the general doAction
	 * method, allowing for the 
	 * freedom to control costs within
	 * an ActionDoer.
	 * 
	 * @return True if resource was
	 * available and spent, False 
	 * otherwise.
	 */
	abstract boolean cost();
	
	/**
	 * Consolidation method for
	 * handling whatever procedures
	 * involve spending or using
	 * resource costs of a specified
	 * value. Is not called
	 * for in the general doAction
	 * method, allowing for the 
	 * freedom to control costs within
	 * an ActionDoer.
	 * 
	 * @param cost Integer value of
	 * resource to be used.
	 * @return True if resource was
	 * available and spent, False 
	 * otherwise.
	 */
	abstract boolean cost(int cost);
	
	
	/**
	 * Abstract method meant to consolidate "common" methods
	 * used by Action subclasses, such as damage protocol
	 * and resource manipulation. Returns the integer of damage
	 * used by the input.
	 * 
	 * @param damage Integer as defined by subclass.
	 * @param target Entity targeted by this Action.
	 * @return Integer as defined by subclass.
	 *
	abstract protected int quickUse(int damage, Entity target);
	
	/**
	 * Abstract method meant to consolidate "common" methods
	 * used by Action subclasses, such as damage protocol
	 * and resource manipulation. 
	 * 
	 * @param target Entity targeted by this Action.
	 * @return Integer as defined by subclass.
	 *
	abstract protected int quickUse(Entity target);
	
	/**
	 * Dummied method, currently unused.
	 * 
	 * @param condition
	 */
	public void setUseCondition(UseCondition condition) {
		
		this.condition = condition;
	}
	
	//abstract UseCondition defaultCondition();
	/**
	 * Dummied method, currently unused.
	 * 
	 * @param condition
	 */
	public boolean checkUseCondition() {
		
		return condition.isSatisfied(this);
	}
	/**
	 * Dummied interface, currently unused.
	 * 
	 * @param condition
	 */
	private interface UseCondition {
		
		public boolean isSatisfied(Action action);
	}
	
	

}