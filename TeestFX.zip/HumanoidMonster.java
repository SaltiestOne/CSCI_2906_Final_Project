package finalProject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import finalProject.Stat.Attacking;
import finalProject.Attempt.AttemptType;

public abstract class HumanoidMonster extends Monster implements Humanoid {

	private HumanoidDefaultAttemptStringHolder defaultStrings = new HumanoidDefaultAttemptStringHolder();
	
	HumanoidMonster(String name, MonsterFlavor flavor, int level) {
		
		super(name, flavor, level);
	}
	
	public String defaultSuccessStrings(AttemptType type) {
		
		return defaultStrings.successString(type);
	}
	
	public String defaultFailureStrings(AttemptType type) {
		
		return defaultStrings.failureString(type);
	}
	
	public boolean getBreaker() {

		return (getCurrentType() == getAttackingStat().signatureType());
	}
	
	protected int healthScale() {
		
		return Scaler.enemyHealth(getLevel());
	}
	
	protected class EnemyImplement extends Stat implements Attacking {
		
		private AttemptType signatureType;
		private String[] success = new String[5];
		private String[] advantaged = new String[5];
		private String[] failure = new String[5];
		
		EnemyImplement(HumanoidMonster user, String name, AttemptType signature,
				String[] success, String[] advantaged, String[] failure) {
			
			super (user, name, Stat.getMaxLevel(), 0);
			this.signatureType = signature;
			System.arraycopy(this.success, 0, success, 0, 5);
			System.arraycopy(this.failure, 0, failure, 0, 5);
			System.arraycopy(this.advantaged, 0, advantaged, 0, 5);
		}



		public String attackMessage(AttemptType attemptType) throws NullPointerException {
			
			try {
			
				return success[typeId(attemptType)];
			} catch (NullPointerException ex) {
				
				return getUser().defaultSuccessStrings(attemptType);
			}
		}


		public String advantagedMessage(AttemptType attemptType) throws NullPointerException {
		
			try {
				
				return advantaged[typeId(attemptType)];
				
			} catch (NullPointerException ex) {

				return getUser().defaultSuccessStrings(attemptType);
			}
		}


		public String failureMessage(AttemptType attemptType) throws NullPointerException {
	
			try {
				
				return failure[typeId(attemptType)];
			} catch (NullPointerException ex) {
				
				return getUser().defaultFailureStrings(attemptType);
			}
		}

		/**
		 * Convenience method so I don't
		 * need to type out the static
		 * method from the Attempt class
		 * every time.
		 * 
		 * @param type AttemptType
		 * @return Integer id corresponding
		 * to input AttemptType.
		 */
		private int typeId(AttemptType type) {
			
			return Attempt.idFromType(type);
		}

		public AttemptType signatureType() {
			
			return signatureType;
		}


		protected Action[] buildActions() {

			return null;
		}


		protected String upgrade() {

			return null;
		}
	}
			
	protected EnemyImplement fetchImplement(HumanoidMonster user, String key) {
		
		String[] success = new String[5];
		String[] advantaged = new String[5];
		String[] failure = new String[5];
		AttemptType signature = AttemptType.NEUTRAL;
		
		switch (key) {
		//poacher's implement
		case ("Poacher's tools"): {
			
			
		}
		//sharpstaff's implement
		case ("staff"): {
			//TODO: write all this crap
			return new EnemyImplement(user, key, AttemptType.QUICK, 
					new String[] {"thrust[s] [pp] [i]",
					"sweep[s]", "throw [pp] [i]",
					null, "conjure a shield"},
					new String[] {"[v]", "[v]",
							"[v]","[v]","[v]",},
					new String[] {"[v]", "[v]",
							"[v]","[v]","[v]",});
		}
		//swordist's implement
		case ("sword"): {
			
			
		}
		//catalin daerg's implement
		case ("arms"): {
			
			
		}
		//paladin's implement
		case ("shield"): {
			
			
		}
		//edge-lord's implement
		case ("edge"): {
			
			break;
		}
		
		default: {
			//placeholder
			return new EnemyImplement(user, key, AttemptType.QUICK, 
					new String[]{"thrust[s] [pp] [i]",
					"sweep[s]", "throw [pp] [i]",
					null, "conjure a shield"},
					new String[] {"[v]", "[v]",
							"[v]","[v]","[v]",},
					new String[] {"[v]", "[v]",
							"[v]","[v]","[v]",});
			//throw new IllegalArgumentException("Implement not found.");
		}
		}
		
		
		return new EnemyImplement(user, key, signature, 
				success, advantaged, failure);	
	}
	
	
	private String[][] flavorFromFile(String name) {
		
		try {
			//TODO: write implements to files
			ObjectInputStream input = new ObjectInputStream(new FileInputStream("SortedMonsters\\Implements\\" + name));
			
			String[][] test = ((String[][])input.readObject());
			
			for (int x = 0; x < test.length; x++) {
				
				for (int y = 0; y < test[x].length; y++) {
					//TODO: remove console printing after testing
					System.out.println(test[x]);
				}
			}
			
			return test;
			
		} catch (IOException | ClassNotFoundException e) {

			e.printStackTrace();
		}
		
		return null;
	}
}
