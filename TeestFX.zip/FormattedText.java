package finalProject;

import javafx.scene.text.Text;

/**
 * Subclass of Text that automatically 
 * formats itself using the static parameters 
 * defined in the Formatter object, pontentially
 * including Font, font size, and color. It 
 * cannot be instantiated until all necessary 
 * parameters have been defined in Formatter.
 * 
 * @author Kayden Barlow
 */
public class FormattedText extends Text {

	/**
	 * Constructs a new FormattedText
	 * with no initial text, and the 
	 * default text size. 
	 */
	FormattedText() {
		
		super();
		this.setFont(Formatter.getFont());
		this.setFill(Formatter.getMainColor());
	}
	
	/**
	 * Constructs a new FormattedText
	 * with no intial text, but a
	 * specified size for any text that
	 * is later set.
	 * 
	 * @param size Double size of this Text's
	 * font.
	 */
	FormattedText(double size) {
		
		super();
		this.setFont(Formatter.getFont(size));
		this.setFill(Formatter.getMainColor());
	}
	
	/**
	 * Constructs a new FormattedText
	 * with the input intial text.
	 * 
	 * @param text String text to be displayed.
	 */
	FormattedText(String text) {
		
		super(text);
		this.setFont(Formatter.getFont());
		this.setFill(Formatter.getMainColor());
	}
	
	
	/**
	 * Constructs a new FormattedText
	 * with the initial input text at
	 * the specified font size.
	 * 
	 * @param text String text to be displayed.
	 * @param size Double size of the text's
	 * font.
	 */
	FormattedText(String text, double size) {
		
		super(text);
		this.setFont(Formatter.getFont(size));
		this.setFill(Formatter.getMainColor());
	}
	
	
	/**
	 * Sets the text's font to the
	 * default weight and orientation,
	 * as well as the default text size. 
	 */
	public void setDefaultFont() {
		
		setFont(Formatter.getFont());
	}
	
	
	/**
	 * Sets the text's font TO THE 
	 * DEFAULT WEIGHT AND ORIENTAION,
	 * as the input size. If size
	 * adjustments are desired while 
	 * maintaining bold or italic
	 * formatting, use setBold(double)
	 * or setItalic(double) repectively.
	 * 
	 * @param size Double size of 
	 * the Text's font.
	 */
	public void setSize(double size) {
		
		setFont(Formatter.getFont(size));
	}
	
	/**
	 * Sets this text's font to
	 * the bold font weight, keeping
	 * its current size. Will
	 * remove any italic orientaion.
	 */
	public void setBold() {
		
		setFont(Formatter.getBoldFont(this.getFont().getSize()));
	}
	
	/**
	 * Sets this text's font to
	 * the bold font weight, at the
	 * input double size. Will
	 * remove any italic orientaion.
	 * 
	 * @param size Double value of 
	 * the text's font size.
	 */
	public void setBold(double size) {
		
		setFont(Formatter.getBoldFont(size));
	}
	
	
	/**
	 * Sets this text's font to
	 * the italic orientaion, keeping
	 * its current size. Will
	 * remove any bold weight.
	 */
	public void setItalic() {
		
		setFont(Formatter.getItalicFont(this.getFont().getSize()));
	}
	
	
	/**
	 * Sets this text's font to
	 * the italic orientaion, at the
	 * input double size. Will
	 * remove any bold weight.
	 * 
	 * @param size Double value of 
	 * the text's font size.
	 */
	public void setItalic(double size) {
		
		setFont(Formatter.getItalicFont(size));
	}
	
	
	/**
	 * Sets this Text's fill color
	 * to the "main color" as 
	 * specified by the Formatter
	 * class. 
	 */
	public void setMainColor() {
		
		setFill(Formatter.getMainColor());
	}
	
	
	/**
	 * Sets this Text's fill color
	 * to the "fade color" as 
	 * specified by the Formatter
	 * class. 
	 */
	public void setFadeColor() {
		
		setFill(Formatter.getFadeColor());
	}
	
	
	/**
	 * Sets this Text's fill color
	 * to the "warn color" as
	 * specified by the Formatter
	 * class. 
	 */
	public void setWarnColor() {
		
		setFill(Formatter.getWarnColor());
	}
}
