package finalProject;

import java.util.HashMap;
import java.util.Random;

import finalProject.Attempt.AttemptType;


/**
 * Abstract class containing a map of all
 * ActionDoers currently in the game,
 * which can be retreived via a String
 * "name" key.
 * 
 * @author Kayden Barlow
 */
public abstract class AllActions {

	static private HashMap<String, ActionDoer> allActions = new HashMap<String, ActionDoer>();
	static private HashMap<String, AttemptType> typeByName = new HashMap<String, AttemptType>();
	static private boolean set = false;
	/*
	public static Action prebuiltAction(String name, Stat stat) {
		
		Action output;
		
		switch(name) {
		
		case("Shield Bash"): {
			
			output = new Skill("Shield Bash", true, 2, stat, AttemptType.BLOCK);
			output.addDamageScaler((e -> {return Scaler.damage(stat);}));
			break;
		}
		
		case("Combo"): {
			
			output = new Skill("Combo", true, 2, stat, AttemptType.TRICK);
			output.addDamageScaler(e -> {return 1; });
			break;
		}
		}
		
	}*/
	
	/**
	 * Returns an ActionDoer lambda based on an
	 * input name. Throws an exception if no
	 * name is found in the internal map. 
	 * 
	 * @param name String name of desired ActionDoer.
	 * @return ActionDoer lambda linked with input name.
	 */
	public static ActionDoer getDoer(String name) {
	
		if (allActions.size() < 1) {
	
			set();	
		} else {}
				
		ActionDoer result = allActions.get(name);
		
		if (result == null) {
			
			throw new IllegalArgumentException("ActionDoer \"" + name + "\" not found.");
		} else {
			
			return result;
		}
	}
	
	/**
	 * Retrieves an AttemptType based
	 * on an input name, which in most
	 * cases will be the name of an
	 * ActionDoer accessible by this 
	 * class.
	 * 
	 * @param name String name of an
	 * Action that should have a particular
	 * AttemptType.
	 * @return AttemptType appropriate for
	 * a certain Action.
	 */
	public static AttemptType getType(String name) {
		
		if (allActions.size() < 1) {
			
			set();	
		} else {}
				
		AttemptType result = typeByName.get(name);
		
		if (result == null) {
			
			throw new IllegalArgumentException("\"" + name + "\" has no associated AttemptType.");
		} else {
			
			return result;
		}
	}
	
	
	/**
	 * Sets up the static map of all
	 * currently implemented ActionDoers,
	 * as well as the map of many AttemptTypes
	 * corresponding to the same names. 
	 * Entries to both from the same name
	 * are written near one another in the
	 * code to aid readability. A static 
	 * boolean is tracked to prevent 
	 * redundant calls of this method. 
	 */
	private static void set() {
		
		if (!set) {
			

			allActions.put("Lunge", ((a, t, v) -> {

				String output = ("[u] lunge[s] at [t] with [pp] [i] before [f].\n" +
				t.damageMessage(a.scale()));
						
				if ((t instanceof Monster) && t.isDead()) {
				//if target is dead, they cannot mutual-kill
					t.stun();
					
					((Monster)t).setSpecial(false);
				} else {}
				
				return output;}));
			
			typeByName.put("Lunge", AttemptType.QUICK);
			
			
			
			allActions.put("Spin Attack", ((a, t, v) -> {
				//please don't do this in an actual sword fight and then sue me when you die from a back wound
				if (!v) {
					
					return ("[u] read[ies] [pp] legs and [pp] [i]. Once [f], [ps] whirl[s] around, " + 
							"slashing in a complete circle.\n" + t.damageMessage(a.scale()));
				} else {
					
					return ("while [f], [u] already begin[s] spinning. Two full circles are completed by [pp] [i] " +
							" before [ts] can respond.\n" + t.damageMessage(2 * a.scale()));
				}
				
			}));
			
			typeByName.put("Spin Attack", AttemptType.WIDE);
			
			
			allActions.put("Mana Burst", ((a, t, v) -> {
					
				String output;
				
				int manaCost = ((int)(((Caster)a.getUser()).mana().getMax() * .5));
				
				if (((Caster)a.getUser()).mana().getMana() >= manaCost) {
					
					output = ("[u] channel[s] Mana into [pp] [i].\n" +
					t.damageMessage(a.scale()));
	
					((Caster)a.getUser()).mana().adjust(-manaCost);
					
				} else if ((a.getUser().hasAction("Ascend"))) {
				
					
					output = ("[u] sacrifice[s] " + a.getUser().harm(Scaler.damage(a.getStat())) +
					 " health to abstract [pp] " + a.getImplement() + ",\nStriking " + t.getPerspectiveName() + 
					 "for " + t.harm(a.scale()) + " damage!\n");
				} else {
					
					throw new IllegalArgumentException("No Mana to Burst.");
				}
				
				return output;}));
			
			typeByName.put("Mana Burst", AttemptType.EVADE);
			
			allActions.put("Throw", ((a, t, v) -> {
				
				if (!v) {
					
					return ("[u] put[s] some distance bewteen [pf] and [t], and hurl[s] [pp] [i]. " +
							"It makes contact as [f], and [u] quickly retrieve[s] it.\n" + 
							t.damageMessage(a.scale()));
				} else {
					
					return ("[u] launche[s] [pp] [i] upwards and stand[s] confidently. " +
							"It lands as [f], directly striking [to]. Nonchalantly, [u] retake[s] the [i].\n" + 
							t.damageMessage(2 * a.scale()));
				}	
			}));
			
			typeByName.put("Throw", AttemptType.BLOCK);
			
			
		
			allActions.put("Heavenpierce", ((a, t, v) -> {
				
				int damage = a.scale();
				
				if (t.afflict("collapse", damage)) {
					
					return ("[u] plunge[s] [pp] [i] into [tp] soul,\n" +
							" collapsing " + damage + " of [tp] Mana.");
				} else {
					
					return ("[pp] [i] pierces [tp] exposed soul.\n" + t.damageMessage(damage));
				}
			}));
			
			typeByName.put("Heavenpierce", AttemptType.TRICK);
			
			
			
			allActions.put("Counter", ((a, t, v) -> {
			
				if (v) {
					
					return ("[u] deflect as [f], bashing [pp] [i] into [to] in the same motion." +
							t.damageMessage(a.scale()));
				} else {

					a.cost();
					
					return ("[u] brace[s] [pp] [i] as [f]. "
							+ "Deflecting the attack, [u] knock[s] [to] off balance.\n" +
							a.getUser().advantageMessage(t));
				}}));
				
			typeByName.put("Counter", AttemptType.QUICK);
			
			
			
			allActions.put("Mana Burst(Sp)", ((a, t, v) -> {
				//Mana Burst but as a spell since I can't be bothered to change the original
				return ("[u] channel[s] Mana into [pp] [i] and strike[s].\n" +
						t.damageMessage(a.scale()));
			}));
			
			typeByName.put("Mana Burst(Sp)", AttemptType.EVADE);
			
			
			
			//The "Shield Bash" shield Skill
			allActions.put("Shield Bash", ((a, t, v) -> {
				
				String output = "[u] slam[s] [pp] [i] into [t].\n" + 
						t.damageMessage(a.scale());
				
				if ((new Random().nextBoolean())) {
					
					t.afflict("stun");
					
					a.cost();
				} else {}
				
				return output;}));
			
			typeByName.put("Shield Bash", AttemptType.BLOCK);
			
			
		
			allActions.put("Drain", ((a, t, v) -> {
				
				int damage = a.scale();
				a.cost();
				
				if (t.afflict("collapse", damage)) {
					
					damage = damage * 2;
					
				} else {}
				//TODO: Add a different message when damaging Mana directly
				return ("[u] drain[s] Mana from [t],\n restoring "+
						a.getUser().heal(damage * 2) + " of [pp] health!\n");}));
			
			typeByName.put("Drain", AttemptType.NEUTRAL);
			
			
			
			allActions.put("Bolt", ((a, t, v) -> {
		
				return "[u] send[s] a flare of energy towards [t].\n" +
						t.damageMessage(a.scale());}));
			
			typeByName.put("Bolt", AttemptType.QUICK);
			
			
			
			allActions.put("Ascend", ((a, t, v) -> {

				int upMana = (int)(((Caster)a.getUser()).mana().getMax() * .5);
				
				((Caster)a.getUser()).mana().adjust(upMana);
					
				//"trust no one, not even yourself"
				return ("[u] abstract[s] [pp] own lifeforce,\n exchanging " +
					a.getUser().harm(a.scale()) + " health for " +
					upMana + " Mana.\n");}));
			
			typeByName.put("Ascend", AttemptType.NEUTRAL);
			
			
			
			allActions.put("Revert", ((a, t, v) -> {
				
				a.cost();
				
				return ("[u] channel[s] Mana into [pf],\nrestoring " + 
						a.getUser().heal(a.scale()) + " health.\n");}));
			
			typeByName.put("Revert", AttemptType.EVADE);
			
			
			
			allActions.put("Astra", ((a, t, v) -> {
				
				int maxStars = ((Caster)a.getUser()).mana().getMana() / (a.getCost());
				
				int stars = 0;
				
				if (v) {
					
					stars = maxStars;
				} else {
					
					stars = new Random().nextInt(maxStars) + 1;
				}

				if (stars <= 0) {
				
					return ("The Stars cross against [u]...\nNo damage dealt.\n");
					//spell has a chance to fail.
				} else {
				
					int damage = 0;
					String output = "";
					
					for (int s = 0; s < stars; s++) {
						
						damage += (a.scale());
					
						a.cost();
					}
					
					if (v) {
						
						damage = (int)(1.2 * damage);
					} else {}
					
					if (stars == 1) {
						
						output = "A Star crosses ";
					} else {
						/*thank goodness this isnt a commercial project that required
						localization or else I'd probably need to make (or find)
						an object to dynamically handle plural conjugation lol*/
						output = (stars + " Stars cross ");
					}

					return (output + "against [t].\n " +
							t.damageMessage(damage));}}));
			
			typeByName.put("Astra", AttemptType.TRICK);
			
			
			
			allActions.put("Temperence", ((a, t, v) -> {
				//WATAH IN DA FIYA, WHY
				String output = "[u] sieze[s] a moment as [f] to channel Fire and Water to " +
						"patch [pf] up.\n";
				
				if (v) {
					
					int timesCast = 1;
					int totalHealed = a.getUser().heal(a.scale());
					
					while (a.cost() && a.getUser().isDamaged()) {
					
						totalHealed += a.getUser().heal(a.scale());
						timesCast++;
					}
						
					if (!a.getUser().isDamaged()) {
						
						output += (" [u] fully heal[s] [pf] after spending " + (timesCast * a.getCost()) + " Mana.");
					} else {
						
						output += (" [u] heal[s] " + totalHealed + " health after spending all of [pp] Mana.");
					}
				} else {
					
					a.cost();
					output += " [u] find[s] enough time to restore " + a.getUser().heal(a.scale()) + " health.";
				}
				
				return output;}));
			
			typeByName.put("Temperence", AttemptType.TRICK);
			
			
			
			allActions.put("Metabolic Aid", ((a, t, v) -> {
				
				int count = 0;
				int heal = (a.getUser().getHealth() - 1);
				while (a.cost() && a.getUser().isDamaged()) {
					
					a.getUser().heal(heal);
					count++;
				}
				
				String output;
				
				if (a.getUser().isDamaged()) {
					
					output = ("[u] restore[s] [pf] to " +
					a.getUser().getHealth() + "health,\n using ");
					
					
				} else {
					
					output = ("[u] fully restore[s] [pp] health,\n using ");
				}

				if  (count == 1) {
						
					if (((Item)a).getStock() == 0) {
						output += "[pp] very last [i].\n";
					} else {
						
						output += "a single [i].\n";
					}
				} else {
					
					output += (count + " [i]s.\n");
				}
				
				return output;
			}));
			
			
			
			allActions.put("Eviscerate", ((a, t, v) -> {
				
				if (new Random().nextBoolean()) {
					
					a.cost();
					
					return ("[u] launch[es] a reckless assualt with [pp] [i]!\n " + 
					t.damageMessage((a.scale() * 3)));
				} else {
					
					a.cost();
					
					return ("[u] attempt[s] to launch a reckless assualt,\n but [ps] just leave[s] [pf] open..."); 
				}}));
			
			typeByName.put("Eviscerate", AttemptType.QUICK);
				
				
				
				
				
				
				//allActions.put("Black Arrow", ((a, t) -> {}));
			
			set = true;
			
		} else {}
	}
}
